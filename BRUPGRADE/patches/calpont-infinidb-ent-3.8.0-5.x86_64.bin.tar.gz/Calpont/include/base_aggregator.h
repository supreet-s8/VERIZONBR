// InstaAggregator Interface

#ifndef BASEAGGREGATOR_H
#define BASEAGGREGATOR_H

#include "insta_aggregation_exception.h"
#include <string>
#include <iostream>

#define UNSUPPORTED_AGGREGATION \
throw InstaAggregationException("Unsupported aggregation datatype");

namespace InstaAggregation
{

class BaseAggregator
{
public:
	BaseAggregator()
	{
		std::cout << "Aggregator : " << this << " *CREATED*" << std::endl;
	}

	virtual ~BaseAggregator()
	{
		std::cout << "Aggregator : " << this << " *DESTROYED*" << std::endl;
	}

	// Call before new aggregation
	virtual void reset()
	{
	}

	// Simple Buffers
	virtual void addForAggregation( const std::string& given)
	{
		UNSUPPORTED_AGGREGATION
	}
	virtual void getAggregatedResult(std::string& result)
	{
		UNSUPPORTED_AGGREGATION
	}

	// Just Double
	virtual void addForAggregation( double given)
	{
		UNSUPPORTED_AGGREGATION
	}
	virtual void getAggregatedResult(double& result)
	{
		UNSUPPORTED_AGGREGATION
	}
};

} // namespace InstaAggregation

#endif //BASEAGGREGATOR_H
