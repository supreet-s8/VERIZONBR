#ifndef BLOOMFILTEREXCEPTION_H_
#define BLOOMFILTEREXCEPTION_H_

#include <exception>

namespace BloomFilter
{

  class BloomFilterException: public std::exception
    {
    private :
      std::string error_message;
      
    public:
      
      BloomFilterException(std::string& msg) throw()
      {
	  error_message = msg;
      }
      
      virtual const char* what() const throw()
      {
	if (error_message.empty()) 
	  return "Bloom Filter Exception";
	else 
	  return  error_message.c_str();
      }         
      
      virtual ~BloomFilterException() throw(){}
    };

} // namespace Bloom Filter

#endif //BLOOMFILTEREXCEPTION_H_
