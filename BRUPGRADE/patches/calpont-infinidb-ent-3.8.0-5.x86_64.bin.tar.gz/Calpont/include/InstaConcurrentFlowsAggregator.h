// Concurrent Flows Library
// Nikhil S. Ketkar, nikhil.ketkar@guavus.com

#ifndef INSTACONCURRENTFLOWSAGGREGATOR_H
#define INSTACONCURRENTFLOWSAGGREGATOR_H

#include <string>
#include <vector>

#include "base_aggregator.h"
#include "insta_aggregation_exception.h"
#include "ConcurrentFlowsAggregator.h"

namespace InstaAggregation
{

	class InstaConcurrentFlowsAggregator : public BaseAggregator
	{
		public:

			InstaConcurrentFlowsAggregator(): aggregator(3600,16,10) {}

			void reset();

			void addForAggregation( const std::string& given);

			void getAggregatedResult(std::string& result);

			//print a given buffer
			static void print(const std::string & given);

            static float getAvg(std::string &buffer);
            static float getMax(std::string &buffer);
            static float getMin(std::string &buffer);
            static float getP95(std::string &buffer);
		private:
			ConcurrentFlows::ConcurrentFlowsAggregator aggregator;
	};

} // namespace InstaAggregation

#endif //INSTACONCURRENTFLOWSAGGREGATOR_H
