/*

Copyright (C) 2009-2011 Calpont Corporation.

Use of and access to the Calpont InfiniDB Community software is subject to the
terms and conditions of the Calpont Open Source License Agreement. Use of and
access to the Calpont InfiniDB Enterprise software is subject to the terms and
conditions of the Calpont End User License Agreement.

This program is distributed in the hope that it will be useful, and unless
otherwise noted on your license agreement, WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Please refer to the Calpont Open Source License Agreement and the Calpont End
User License Agreement for more details.

You should have received a copy of either the Calpont Open Source License
Agreement or the Calpont End User License Agreement along with this program; if
not, it is your responsibility to review the terms and conditions of the proper
Calpont license agreement by visiting http://www.calpont.com for the Calpont
InfiniDB Enterprise End User License Agreement or http://www.infinidb.org for
the Calpont InfiniDB Community Calpont Open Source License Agreement.

Calpont may make changes to these license agreements from time to time. When
these changes are made, Calpont will make a new copy of the Calpont End User
License Agreement available at http://www.calpont.com and a new copy of the
Calpont Open Source License Agreement available at http:///www.infinidb.org.
You understand and agree that if you use the Program after the date on which
the license agreement authorizing your use has changed, Calpont will treat your
use as acceptance of the updated License.

*/

/***********************************************************************
*   $Id: simplecolumn_decimal.h 7409 2011-02-08 14:38:50Z rdempsey $
*
*
***********************************************************************/
/** @file */

#ifndef SIMPLECOLUMNDECIMAL_H
#define SIMPLECOLUMNDECIMAL_H
#include <string>
#include <cmath>

#include "simplecolumn.h"
#include "objectreader.h"
#include "joblisttypes.h"
#include "rowgroup.h"
#include "dataconvert.h"

/**
 * Namespace
 */
namespace execplan { 
/**
 * @brief A class to represent a simple returned column
 * 
 * This class is a specialization of class ReturnedColumn that handles
 * a column name.
 */
template <int len>
class SimpleColumn_Decimal : public SimpleColumn {

/**
 * Public stuff
 */
public:
 
	/** Constructors */ 
	SimpleColumn_Decimal();
	SimpleColumn_Decimal(const std::string& token, const u_int32_t sessionID = 0);
	SimpleColumn_Decimal(const std::string& schema, 
		               const std::string& table, 
		               const std::string& col, 
		               const u_int32_t sessionID = 0);
	SimpleColumn_Decimal(const SimpleColumn& rhs, const u_int32_t sessionID = 0);
	
	/** Destructor */
	virtual ~SimpleColumn_Decimal(){}
	
	inline virtual SimpleColumn_Decimal* clone() const
	{
	    return new SimpleColumn_Decimal<len> (*this);
	}	
	
	/** Evaluate methods */
	virtual inline std::string getStrVal(rowgroup::Row& row, bool& isNull);
	virtual inline int64_t getIntVal(rowgroup::Row& row, bool& isNull);
	virtual inline float getFloatVal(rowgroup::Row& row, bool& isNull);
	virtual inline double getDoubleVal(rowgroup::Row& row, bool& isNull);	
	virtual inline IDB_Decimal getDecimalVal(rowgroup::Row& row, bool& isNull);
		
	/** The serialize interface */
	virtual void serialize(messageqcpp::ByteStream&) const;
	virtual void unserialize(messageqcpp::ByteStream&);	
	uint64_t fNullVal;

private:
	void setNullVal();
			
};

template<int len>
SimpleColumn_Decimal<len>::SimpleColumn_Decimal():SimpleColumn() 
{
	setNullVal();
}

template<int len>
SimpleColumn_Decimal<len>::SimpleColumn_Decimal(const std::string& token, const u_int32_t sessionID):
		SimpleColumn(token, sessionID) 
{
	setNullVal();
}

template<int len>
SimpleColumn_Decimal<len>::SimpleColumn_Decimal(const std::string& schema, 
		           const std::string& table, 
		           const std::string& col, 
		           const u_int32_t sessionID) :
		           SimpleColumn(schema, table, col, sessionID) 
{
	setNullVal();
}

template<int len>
SimpleColumn_Decimal<len>::SimpleColumn_Decimal(const SimpleColumn& rhs, const u_int32_t sessionID):
		SimpleColumn(rhs,sessionID) 
{
	setNullVal();
}

template<int len>
void SimpleColumn_Decimal<len>::setNullVal()
{
	switch (len)
	{
		case 8:
			fNullVal = joblist::BIGINTNULL;
			break;
		case 4:
			fNullVal = joblist::INTNULL;
			break;
		case 2:
			fNullVal = joblist::SMALLINTNULL;
			break;
		case 1:
			fNullVal = joblist::TINYINTNULL;
			break;
		default:
			fNullVal = joblist::BIGINTNULL;
	}
}

template<int len>
inline std::string SimpleColumn_Decimal<len>:: getStrVal(rowgroup::Row& row, bool& isNull)
{ 
	dataconvert::DataConvert::decimalToString((int64_t)row.getIntField<len>(fInputIndex), fResultType.scale, tmp, 22);
	return std::string(tmp);
}

template<int len>
inline int64_t SimpleColumn_Decimal<len>:: getIntVal(rowgroup::Row& row, bool& isNull) 
{ 
	if (row.equals<len>(fNullVal, fInputIndex))
		isNull = true;
	return (int64_t)(row.getIntField<len>(fInputIndex) / pow((double)10, fResultType.scale));		
}
	
template<int len>
inline float SimpleColumn_Decimal<len>::getFloatVal(rowgroup::Row& row, bool& isNull)
{ 
	if (row.equals<len>(fNullVal, fInputIndex))
		isNull = true;
	return (row.getIntField<len>(fInputIndex) / pow((double)10, fResultType.scale));
}
	
template<int len>
inline double SimpleColumn_Decimal<len>::getDoubleVal(rowgroup::Row& row, bool& isNull) 
{ 
	if (row.equals<len>(fNullVal, fInputIndex))
		isNull = true;
	return (row.getIntField<len>(fInputIndex) / pow((double)10, fResultType.scale));
}
		
template<int len>
inline IDB_Decimal SimpleColumn_Decimal<len>::getDecimalVal(rowgroup::Row& row, bool& isNull)
{ 
	if (row.equals<len>(fNullVal, fInputIndex))
		isNull = true;
	fResult.decimalVal.value = (int64_t)row.getIntField<len>(fInputIndex);
	fResult.decimalVal.precision = fResultType.precision;
	fResult.decimalVal.scale = fResultType.scale;
	return fResult.decimalVal;	
}

template<int len>
void SimpleColumn_Decimal<len>::serialize(messageqcpp::ByteStream& b) const
{
	switch (len)
	{
		case 1:
			b << (ObjectReader::id_t) ObjectReader::SIMPLECOLUMN_DECIMAL1;
			break;
		case 2:
			b << (ObjectReader::id_t) ObjectReader::SIMPLECOLUMN_DECIMAL2;
			break;
		case 4:
			b << (ObjectReader::id_t) ObjectReader::SIMPLECOLUMN_DECIMAL4;
			break;
		case 8:
			b << (ObjectReader::id_t) ObjectReader::SIMPLECOLUMN_DECIMAL8;
			break;
	}
	SimpleColumn::serialize(b);
}

template<int len>
void SimpleColumn_Decimal<len>::unserialize(messageqcpp::ByteStream& b)
{
	switch (len)
	{
		case 1:
			ObjectReader::checkType(b, ObjectReader::SIMPLECOLUMN_DECIMAL1);
			break;
		case 2:
			ObjectReader::checkType(b, ObjectReader::SIMPLECOLUMN_DECIMAL2);
			break;
		case 4:
			ObjectReader::checkType(b, ObjectReader::SIMPLECOLUMN_DECIMAL4);
			break;
		case 8:
			ObjectReader::checkType(b, ObjectReader::SIMPLECOLUMN_DECIMAL8);
			break;
	}
	SimpleColumn::unserialize(b);
}

} 
#endif //SIMPLECOLUMN_INT_H

