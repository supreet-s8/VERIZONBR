/*

Copyright (C) 2009-2011 Calpont Corporation.

Use of and access to the Calpont InfiniDB Community software is subject to the
terms and conditions of the Calpont Open Source License Agreement. Use of and
access to the Calpont InfiniDB Enterprise software is subject to the terms and
conditions of the Calpont End User License Agreement.

This program is distributed in the hope that it will be useful, and unless
otherwise noted on your license agreement, WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Please refer to the Calpont Open Source License Agreement and the Calpont End
User License Agreement for more details.

You should have received a copy of either the Calpont Open Source License
Agreement or the Calpont End User License Agreement along with this program; if
not, it is your responsibility to review the terms and conditions of the proper
Calpont license agreement by visiting http://www.calpont.com for the Calpont
InfiniDB Enterprise End User License Agreement or http://www.infinidb.org for
the Calpont InfiniDB Community Calpont Open Source License Agreement.

Calpont may make changes to these license agreements from time to time. When
these changes are made, Calpont will make a new copy of the Calpont End User
License Agreement available at http://www.calpont.com and a new copy of the
Calpont Open Source License Agreement available at http:///www.infinidb.org.
You understand and agree that if you use the Program after the date on which
the license agreement authorizing your use has changed, Calpont will treat your
use as acceptance of the updated License.

*/

/*******************************************************************************
* $Id: we_xmlop.h 2972 2011-05-17 20:50:24Z dcathey $
*
*******************************************************************************/
/** @file */

#ifndef _WE_XMLOP_H_
#define _WE_XMLOP_H_

#include "we_xmltag.h"
#include "we_type.h"

/** Namespace WriteEngine */
namespace WriteEngine
{
   // Size of buffer used to parse node content or attribute
   const int XML_NODE_BUF_SIZE = 256;

/** @brief Class wrapper around XML2  API.  Used by XmlGenProc to save Job XML
 *  file for input into cpimport.
 *
 */
class XMLOp
{
protected:
    /** @brief XML types used in parsing XML content and attributes
     *
     */
    enum XML_DTYPE
    {
        TYPE_EMPTY    = 1,
        TYPE_CHAR     = 2,
        TYPE_DOUBLE   = 3,
        TYPE_FLOAT    = 4,
        TYPE_LONGLONG = 5,
        TYPE_INT      = 6
    };

    /**
     * @brief Constructor
     */
    XMLOp();

    /**
     * @brief Default Destructor
     */
    virtual ~XMLOp();

    /**
     * @brief Get node attribute
     */
    bool getNodeAttribute( xmlNode* pNode, const char* pTag,
                           void* pVal, XML_DTYPE dataType ) const;

    /**
     * @brief Get node content
     */
    bool getNodeContent( const xmlNode* pNode, void* pVal,
                         XML_DTYPE dataType );

    /**
     * @brief Check whether it is certain tag
     */
    bool isTag( const xmlNode* pNode, const xmlTag tag )
    { return !xmlStrcmp( pNode->name, (const xmlChar *)xmlTagTable[tag] ); }

    /**
     * @brief Parse xml document
     */
    int  parseDoc( const char* xmlFileName );

    /**
     * @brief Process node (recursion)
     */
    virtual bool processNode( xmlNode* pParentNode );

    xmlDocPtr      m_fDoc;                    // xml document pointer
    xmlNode*       m_pRoot;                   // root element

private:
    void           closeDoc();
    void           convertNodeValue( void* pVal, const char* buf,
                                     XML_DTYPE dataType ) const;
    int            readDoc( const char* xmlFileName );
};


} //end of namespace
#endif // _WE_XMLOP_H_
