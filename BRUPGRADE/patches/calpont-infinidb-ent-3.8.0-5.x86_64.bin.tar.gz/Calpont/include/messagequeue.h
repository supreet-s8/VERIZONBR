/*

Copyright (C) 2009-2011 Calpont Corporation.

Use of and access to the Calpont InfiniDB Community software is subject to the
terms and conditions of the Calpont Open Source License Agreement. Use of and
access to the Calpont InfiniDB Enterprise software is subject to the terms and
conditions of the Calpont End User License Agreement.

This program is distributed in the hope that it will be useful, and unless
otherwise noted on your license agreement, WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Please refer to the Calpont Open Source License Agreement and the Calpont End
User License Agreement for more details.

You should have received a copy of either the Calpont Open Source License
Agreement or the Calpont End User License Agreement along with this program; if
not, it is your responsibility to review the terms and conditions of the proper
Calpont license agreement by visiting http://www.calpont.com for the Calpont
InfiniDB Enterprise End User License Agreement or http://www.infinidb.org for
the Calpont InfiniDB Community Calpont Open Source License Agreement.

Calpont may make changes to these license agreements from time to time. When
these changes are made, Calpont will make a new copy of the Calpont End User
License Agreement available at http://www.calpont.com and a new copy of the
Calpont Open Source License Agreement available at http:///www.infinidb.org.
You understand and agree that if you use the Program after the date on which
the license agreement authorizing your use has changed, Calpont will treat your
use as acceptance of the updated License.

*/

/******************************************************************************************
* $Id: messagequeue.h 2394 2011-02-08 14:36:22Z rdempsey $
*
*
******************************************************************************************/
/** @file */
#ifndef MESSAGEQCPP_MESSAGEQUEUE_H
#define MESSAGEQCPP_MESSAGEQUEUE_H
#include <string>
#include <ctime>

#include <sys/types.h>
#ifdef _MSC_VER
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdio.h>
#else
#include <netinet/in.h>
#endif

#include "configcpp.h"
#include "serversocket.h"
#include "iosocket.h"
#include "clientsocket.h"
#include "bytestream.h"
#include "logger.h"

class MessageQTestSuite;

#if defined(_MSC_VER) && defined(xxxMESSAGEQUEUE_DLLEXPORT)
#define EXPORT __declspec(dllexport)
#else
#define EXPORT
#endif

namespace messageqcpp { 

/**
 * @brief a message queue server
 * This class can recieve (and send) messages
 *
 * MessageQueueServer looks in the config file specified by cfile for an entry like:
 * @code
 * <thisEnd>
 *    <IPAddr>127.0.0.1</IPAddr>
 *    <Port>7601</Port>
 * </thisEnd>
 * @endcode
 * and binds/listens/accepts on the port specified. It ignores the IPAddr setting.
 *
 * Users of this class need to decide whether they want to use it in a single-threaded-
 * compatible (message-at-a-time) mode or in a multi-threaded-compatible (connection-per-
 * thread) mode. For the former, read() and write() are available, and accept() cannot be
 * used. In the latter, the opposite applies.
 */
class MessageQueueServer
{
public:
	/**
	 * @brief construct a server queue for thisEnd
	 * 
	 * construct a server queue for thisEnd. Optionally specify a Config object to use.
	 */
	EXPORT explicit MessageQueueServer(const std::string& thisEnd, const config::Config* config=0,
		size_t blocksize=ByteStream::BlockSize, int backlog=5, bool syncProto=true);

	/**
	 * @brief construct a server queue for thisEnd
	 * 
	 * construct a server queue for thisEnd, specifying the name of a config file to use.
	 */
	EXPORT MessageQueueServer(const std::string& thisEnd, const std::string& config,
		size_t blocksize=ByteStream::BlockSize, int backlog=5, bool syncProto=true);

	/**
	 * @brief destructor
	 */
	EXPORT ~MessageQueueServer();

	/* The MQS read/write fcns are commented out b/c the normal usage is to
	   do an accept, then use the IOSocket directly.  No need to have multiple
	   ways to do the same thing */
#if 0
	/**
	 * @brief read a message from the queue
	 * 
	 * wait for and return a message from the queue. The deafult timeout waits forever. Note that
	 * eventhough struct timespec has nanosecond resolution, this method only has milisecond resolution.
	 */
	const SBS read(const struct timespec* timeout=0) const;

	/**
	 * @brief write a message to the queue
	 * 
	 * write a message to otherEnd
	 */
	void write(const ByteStream& msg, const struct timespec* timeout=0) const;
#endif

	/**
	 * @brief wait for a connection and return an IOSocket
	 *
	 * This method can be used by a main thread to wait for an incoming connection. The IOSocket
	 * that is returned can be passed to a thread to handle the socket connection. The main thread
	 * is then free to wait again for another connection. The IOSocket is already open and ready for
	 * read() and/or write(). The caller is responsible for calling close() when it is done.
	 */
	EXPORT const IOSocket accept(const struct timespec* timeout=0) const;

	/**
	 * @brief get the client IOSocket
	 */
	//inline const IOSocket& clientSock() const;

	/**
	 * @brief get a mutable pointer to the client IOSocket
	 */
	inline IOSocket& clientSock() const;

    inline ServerSocket& listenSock() const;

	/**
	 * @brief set the sync proto
	 */
	EXPORT void syncProto(bool use);

    /**
	 * allow test suite access to private data for OOB test
	 */
	friend class ::MessageQTestSuite;

private:
	/** copy ctor
	 *
	 */
	MessageQueueServer(const MessageQueueServer& rhs);

	/** assign op
	 *
	 */
	MessageQueueServer& operator=(const MessageQueueServer& rhs);

	/** ctor helper
	 *
	 */
	void setup(size_t blocksize, int backlog, bool syncProto);

	std::string fThisEnd;		/// the process name for this process
	struct sockaddr_in fServ_addr;	/// the addr of the server (may be this process)
	const config::Config* fConfig;			/// config file has the IP addrs and port numbers
	mutable ServerSocket fListenSock;	/// the socket the server listens on for new connections
	mutable IOSocket fClientSock;	/// the socket connected to a client

	mutable logging::Logger fLogger;
};

/**
 * @brief a message queue client
 * This class can send (and recieve) messages
 *
 * MessageQueueClient looks in the config file specified by cfile for an entry like:
 * @code
 * <otherEnd>
 *    <IPAddr>127.0.0.1</IPAddr>
 *    <Port>7601</Port>
 * </otherEnd>
 * @endcode
 * and connects to the ipaddr/port specified. It does a "lazy" connect in that it doesn't
 * actually connect until read() is invoked the first time.
 */
class MessageQueueClient
{
public:
	/**
	 * @brief construct a queue to otherEnd
	 * 
	 * construct a queue from this process to otherEnd. Optionally specify a Config object to use.
	 */
	EXPORT explicit MessageQueueClient(const std::string& otherEnd, const config::Config* config=0, bool syncProto=true);

	/**
	 * @brief construct a queue to otherEnd
	 * 
	 * construct a queue from this process to otherEnd, specifying the name of a config file to use.
	 */
	EXPORT explicit MessageQueueClient(const std::string& otherEnd, const std::string& config, bool syncProto=true);

	/**
	 * @brief destructor
	 *
	 * calls shutdown() method.
	 */
	EXPORT ~MessageQueueClient();

	/**
	 * @brief read a message from the queue
	 * 
	 * wait for and return a message from otherEnd. The deafult timeout waits forever. Note that
	 * eventhough struct timespec has nanosecond resolution, this method only has milisecond resolution.
	 */
	EXPORT const SBS read(const struct timespec* timeout=0, bool* isTimeOut = NULL) const;

    /**
      * @brief Used in Distribution Engine
      */
	EXPORT const SBS readDc(const struct timespec* timeout=0, bool* isTimeOut = NULL) const;

	/**
	 * @brief write a message to the queue
	 * 
	 * write a message to otherEnd. If the socket is not open, the timeout parm (in ms) will be used
	 *  to establish a sync connection w/ the server
	 */
	EXPORT void write(const ByteStream& msg, const struct timespec* timeout=0) const;
	
    /**
      * @brief Used in Distribution Engine
      */
    EXPORT void writeDc(const ByteStream& msg, const struct timespec* timeout=0) const;

	/**
	 * @brief shutdown the connection to the server
	 *
	 * indicate to the class that the user is done with the socket
	 * and the other class methods won't be used.
	 */
	EXPORT void shutdown();

	/**
	 * @brief connect to the server. Returns true if connection was successful.
	 *
	 * read() and write() automatically connect, but this method can be used to verify a server is listening
	 * before that.
	 */
	EXPORT bool connect() const;
	
	/**
	 * @brief accessors and mutators
	 */    
	EXPORT const sockaddr_in& serv_addr() const { return fServ_addr; }
	EXPORT const std::string& otherEnd() const { return fOtherEnd; }
	EXPORT const bool isAvailable() const { return fIsAvailable; }
	EXPORT void isAvailable (const bool isAvailable) { fIsAvailable = isAvailable; }
	EXPORT const std::string& moduleName() const {return fModuleName;}
	EXPORT void moduleName(const std::string& moduleName) {fModuleName = moduleName;}

	/**
	 * @brief set the sync proto
	 */
	EXPORT void syncProto(bool use);

	/*
	 * allow test suite access to private data for OOB test
	 */
	friend class ::MessageQTestSuite;

private:
	/** copy ctor
	 *
	 */
	MessageQueueClient(const MessageQueueClient& rhs);

	/** assign op
	 *
	 */
	MessageQueueClient& operator=(const MessageQueueClient& rhs);

	/** ctor helper
	 *
	 */
	void setup(bool syncProto);

	std::string fOtherEnd;		/// the process name for this process
	struct sockaddr_in fServ_addr;	/// the addr of the server (may be this process)
	const config::Config* fConfig;			/// config file has the IP addrs and port numbers
	mutable ClientSocket fClientSock;	/// the socket to communicate with the server
	mutable logging::Logger fLogger;
	bool fIsAvailable;
	std::string fModuleName;
};

//inline const IOSocket& MessageQueueServer::clientSock() const { return fClientSock; }
inline IOSocket& MessageQueueServer::clientSock() const { return fClientSock; }
inline ServerSocket& MessageQueueServer::listenSock() const { return fListenSock; }

} 

#undef EXPORT

#endif //MESSAGEQCPP_MESSAGEQUEUE_H
// vim:ts=4 sw=4:

