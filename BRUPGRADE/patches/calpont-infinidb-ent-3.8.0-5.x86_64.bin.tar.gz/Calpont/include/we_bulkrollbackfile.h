/*

Copyright (C) 2009-2011 Calpont Corporation.

Use of and access to the Calpont InfiniDB Community software is subject to the
terms and conditions of the Calpont Open Source License Agreement. Use of and
access to the Calpont InfiniDB Enterprise software is subject to the terms and
conditions of the Calpont End User License Agreement.

This program is distributed in the hope that it will be useful, and unless
otherwise noted on your license agreement, WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Please refer to the Calpont Open Source License Agreement and the Calpont End
User License Agreement for more details.

You should have received a copy of either the Calpont Open Source License
Agreement or the Calpont End User License Agreement along with this program; if
not, it is your responsibility to review the terms and conditions of the proper
Calpont license agreement by visiting http://www.calpont.com for the Calpont
InfiniDB Enterprise End User License Agreement or http://www.infinidb.org for
the Calpont InfiniDB Community Calpont Open Source License Agreement.

Calpont may make changes to these license agreements from time to time. When
these changes are made, Calpont will make a new copy of the Calpont End User
License Agreement available at http://www.calpont.com and a new copy of the
Calpont Open Source License Agreement available at http:///www.infinidb.org.
You understand and agree that if you use the Program after the date on which
the license agreement authorizing your use has changed, Calpont will treat your
use as acceptance of the updated License.

*/

/*
* $Id: we_bulkrollbackfile.h 2865 2011-02-03 17:57:16Z rdempsey $
*/

/** @file
 * Contains class to restore db files on behalf of BulkRollBackMgr.
 */

#ifndef WE_BULKROLLBACKFILE_H_
#define WE_BULKROLLBACKFILE_H_

#include "we_define.h"
#include "we_type.h"
#include "we_fileop.h"

namespace WriteEngine
{
	class BulkRollbackMgr;

//------------------------------------------------------------------------------
/** @brief Class used by BulkRollbackMgr to restore db files.
 */
//------------------------------------------------------------------------------
class BulkRollbackFile
{
public:

	/** @brief BulkRollbackFile constructor
	 * @param mgr The controlling BulkRollbackMgr object.
	 */
	BulkRollbackFile(BulkRollbackMgr* mgr);

	/** @brief BulkRollbackFile destructor
	 */
	virtual     ~BulkRollbackFile();

	/** @brief Delete a segment file
	 * @param columnOID OID of the segment file to be deleted
	 * @param fileTypeFlag file type (true->column; false->dictionary)
	 * @param dbRoot DBRoot of the segment file to be deleted
	 * @param partNum Partition number of the segment file to be deleted
	 * @param segNum Segment number of the segment file to be deleted
	 * @param segFileExisted (out) Did specified segment file exist
	 */
	        int deleteSegmentFile(OID     columnOID,
                                bool      fileTypeFlag,
                                u_int32_t dbRoot,
                                u_int32_t partNum,
                                u_int32_t segNum,
                                bool&     segFileExisted );

	/** @brief Reinitialize the specified column segment file starting at
	 * startOffsetBlk, and truncate trailing extents.
	 * @param columnOID OID of the relevant segment file
	 * @param dbRoot DBRoot of the relevant segment file
	 * @param partNum Partition number of the relevant segment file
	 * @param segNum Segment number of the relevant segment file
	 * @param startOffsetBlk Starting block offset where file is to be
     *        reinitialized
	 * @param nBlocks Number of blocks to be reinitialized
	 * @param colType Column type of the relevant segment file
	 * @param colWidth Width in bytes of column.
	 */
	virtual int reInitTruncColumnExtent(OID columnOID,
                                u_int32_t   dbRoot,
                                u_int32_t   partNum,
                                u_int32_t   segNum,
                                long long   startOffsetBlk,
                                int         nBlocks,
                                ColDataType colType,
                                u_int32_t   colWidth );

	/** @brief Reinitialize the specified dictionary store segment file starting
	 * at startOffsetBlk, and truncate trailing extents.
	 * @param columnOID OID of the relevant segment file
	 * @param dbRoot DBRoot of the relevant segment file
	 * @param partNum Partition number of the relevant segment file
	 * @param segNum Segment number of the relevant segment file
	 * @param startOffsetBlk Starting block offset where file is to be
     *        reinitialized
	 * @param nBlocks Number of blocks to be reinitialized
	 */
	virtual int reInitTruncDctnryExtent(OID columnOID,
                                u_int32_t   dbRoot,
                                u_int32_t   partNum,
                                u_int32_t   segNum,
                                long long   startOffsetBlk,
                                int         nBlocks );

	/** @brief Truncate the specified segment file to a specified num of bytes
	 * @param columnOID OID of the relevant segment file
	 * @param dbRoot DBRoot of the relevant segment file
	 * @param partNum Partition number of the relevant segment file
	 * @param segNum Segment number of the relevant segment file
	 * @param fileSizeBlocks Number of blocks to retain in the file
	 */
	virtual int truncateSegmentFile( OID    columnOID,
                                u_int32_t   dbRoot,
                                u_int32_t   partNum,
                                u_int32_t   segNum,
                                long long   filesSizeBlocks );

protected:
	BulkRollbackMgr* fMgr;                        // Bulk Rollback controller
	FileOp           fDbFile;                     // interface to DB file
	unsigned char fDctnryHdr[DCTNRY_HEADER_SIZE]; // empty dctnry store blk

private:
	// Disable unnecessary copy constructor and assignment operator
	BulkRollbackFile(const BulkRollbackFile& rhs);
	BulkRollbackFile& operator=(const BulkRollbackFile& rhs);
};

} //end of namespace

#endif // WE_BULKROLLBACKFILE_H_
