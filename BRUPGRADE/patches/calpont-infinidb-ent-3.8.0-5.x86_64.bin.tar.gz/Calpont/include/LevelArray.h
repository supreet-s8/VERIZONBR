// Concurrent Flows Library
// Nikhil S. Ketkar, nikhil.ketkar@guavus.com

#ifndef LEVELARRAY_H
#define LEVELARRAY_H

#include <string>
#include <vector>
#include <iostream>

#include <boost/shared_ptr.hpp>

#include "BitArray.h"

namespace ConcurrentFlows
{
class LevelArray
{
public:
  LevelArray(unsigned int givenLevelCount, unsigned int givenSeriesLength)
  {
    levelCount = givenLevelCount;
    seriesLength = givenSeriesLength;
    unsigned int bitsRequired = levelCount * seriesLength;
    unsigned int bytesRequired = 0;
    bytesRequired = bitsRequired/8 + (bitsRequired%8 > 0 ? 1 : 0);
    bitArray.reset(new BitArray(bytesRequired));
    writePos = 0;
    readOnly = false;
    currSeriesLength = 0;
  }

  LevelArray(unsigned int givenLevelCount, unsigned int givenSeriesLength, std::string& data)
  {
    levelCount = givenLevelCount;
    seriesLength = givenSeriesLength;
    bitArray.reset(new BitArray(data));
    readOnly = true;
  }

  void setNextLevel(unsigned int given)
  {
    if (! readOnly)
      {
        unsigned int leftOver = given;
        /* consider passing the int to the BitArray which supports functions
         * void setNextBits(uint given, int numberOfBits)
         * void setNextBits(vector<uint>& given, int numberOfBits)
         **/
        // Agreed, but this will not happen now, maybe later
        for (unsigned int i = levelCount-1; i > 0; --i)
          {
            unsigned int currPowerOf2 = LevelArray::GetPowersOf2(i);
            int currBit = leftOver/currPowerOf2;
            if (currBit == 1)
              {
                bitArray->setNextBit(true);
                leftOver = leftOver%currPowerOf2;
              }
            else
              bitArray->setNextBit(false);
          }
        if (leftOver == 1)
          bitArray->setNextBit(true);
        else
          bitArray->setNextBit(false);
        currSeriesLength++;
      }
    else
      throw ConcurrentFlowException();
  }

  void setLevelArray(const std::vector<unsigned int>& given)
  {
    for (unsigned int i = 0; i < given.size(); ++i)
      this->setNextLevel(given[i]);
  }

  unsigned int getLevel(int pos)
  {
    int result = 0;
    for (unsigned int i = 0; i < levelCount; i++)
      {
        int currPos = (pos * levelCount) + i;
        if (bitArray->getBit(currPos))
          result += GetPowersOf2(levelCount - i - 1);
      }
    return result;
  }

  void getData(std::string& result)
  {
    bitArray->getData(result);
  }

  void getBitString(std::string& result)
  {
    return bitArray->getBitString(result);
  }

private:

  int GetPowersOf2(int exponent)
  {
    return (0x0001 << exponent);
  }

  boost::shared_ptr<BitArray> bitArray;
  unsigned int levelCount;
  unsigned int seriesLength;
  unsigned int writePos;
  unsigned int currSeriesLength;
  bool readOnly;
};

} //namespace ConcurrentFlows

#ifdef TESTING_WITH_GTEST

TEST(LevelArray, SetTest)
{
  ConcurrentFlows::LevelArray la(2,4);
  la.setNextLevel(0);
  la.setNextLevel(1);
  la.setNextLevel(2);
  la.setNextLevel(3);
  std::string actualResult;
  la.getBitString(actualResult);
  ASSERT_TRUE(actualResult == std::string("00011011"));
}

TEST(LevelArray, GetTest)
{
  ConcurrentFlows::LevelArray la(2,4);
  la.setNextLevel(0);
  la.setNextLevel(1);
  la.setNextLevel(2);
  la.setNextLevel(3);
  ASSERT_TRUE(la.getLevel(0) == 0);
  ASSERT_TRUE(la.getLevel(1) == 1);
  ASSERT_TRUE(la.getLevel(2) == 2);
  ASSERT_TRUE(la.getLevel(3) == 3);
}

#endif //TESTING_WITH_GTEST

#endif // LEVELARRAY_H
