/*

Copyright (C) 2009-2011 Calpont Corporation.

Use of and access to the Calpont InfiniDB Community software is subject to the
terms and conditions of the Calpont Open Source License Agreement. Use of and
access to the Calpont InfiniDB Enterprise software is subject to the terms and
conditions of the Calpont End User License Agreement.

This program is distributed in the hope that it will be useful, and unless
otherwise noted on your license agreement, WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Please refer to the Calpont Open Source License Agreement and the Calpont End
User License Agreement for more details.

You should have received a copy of either the Calpont Open Source License
Agreement or the Calpont End User License Agreement along with this program; if
not, it is your responsibility to review the terms and conditions of the proper
Calpont license agreement by visiting http://www.calpont.com for the Calpont
InfiniDB Enterprise End User License Agreement or http://www.infinidb.org for
the Calpont InfiniDB Community Calpont Open Source License Agreement.

Calpont may make changes to these license agreements from time to time. When
these changes are made, Calpont will make a new copy of the Calpont End User
License Agreement available at http://www.calpont.com and a new copy of the
Calpont Open Source License Agreement available at http:///www.infinidb.org.
You understand and agree that if you use the Program after the date on which
the license agreement authorizing your use has changed, Calpont will treat your
use as acceptance of the updated License.

*/

/***********************************************************************
*   $Id: selectfilter.h 7409 2011-02-08 14:38:50Z rdempsey $
*
*
***********************************************************************/
/** @file */

#ifndef SELECTFILTER_H
#define SELECTFILTER_H
#include <string>

#include "filter.h"
#include "returnedcolumn.h"
#include "operator.h"
#include "calpontselectexecutionplan.h"

/**
 * Namespace
 */
namespace execplan { 
/**
 * @brief A class to represent a subselect predicate
 *
 * This class is a specialization of class Filter that handles a
 * subselect predicate like "col1 = (select col2 from table2)"
 */
class SelectFilter : public Filter {
/**
 * Public stuff
 */
public:
	
	/**
	 * Constructors / copy constructor
	 */
	SelectFilter();
	SelectFilter(const SelectFilter& rhs);

	/** Constructors
	 * 
	 * pass all parts in ctor
	 * @note SimpleFilter takes ownership of all these pointers
	 */
	SelectFilter(const std::vector<SRCP>& cols, const SOP& op, SCSEP& sub, bool correlated = false);
	
	/**
	 * Destructors
	 */
	virtual ~SelectFilter();
	
	/**
	 * Accessor Methods
	 */
	inline const std::vector<SRCP>& cols() const { return fCols; }
	
	void cols(const std::vector<SRCP>& cols) { fCols = cols; }
	
	inline const SOP& op() const { return fOp; }
	
	inline void op (const SOP& op) { fOp = op; }
	
	inline const SCSEP& sub() const {	return fSub; }
	
	inline void sub(SCSEP& sub) { fSub = sub;	}
	
	const bool correlated() const { return fCorrelated; }
	void correlated(const bool correlated) { fCorrelated = correlated; }

	virtual const std::string toString() const;
	
	virtual inline const std::string data() const {return fData;}
	virtual inline void data( const std::string data ) {fData = data;}
	
	const uint64_t returnedColPos() const { return fReturnedColPos; }
	void returnedColPos(const uint64_t returnedColPos) {fReturnedColPos = returnedColPos;}
	
	/**
	 * The serialization interface
	 */
	virtual void serialize(messageqcpp::ByteStream&) const;
	virtual void unserialize(messageqcpp::ByteStream&);
		
	/** return a copy of this pointer
	 *
	 * deep copy of this pointer and return the copy
	 */	
	inline virtual SelectFilter* clone() const
	{
	    return new SelectFilter (*this);
	}	

	/** @brief Do a deep, strict (as opposed to semantic) equivalence test
	 *
	 * Do a deep, strict (as opposed to semantic) equivalence test.
	 * @return true iff every member of t is a duplicate copy of every member of this; false otherwise
	 */
	virtual bool operator==(const TreeNode* t) const;
	
	/** @brief Do a deep, strict (as opposed to semantic) equivalence test
	 *
	 * Do a deep, strict (as opposed to semantic) equivalence test.
	 * @return true iff every member of t is a duplicate copy of every member of this; false otherwise
	 */
	bool operator==(const SelectFilter& t) const;
	
	/** @brief Do a deep, strict (as opposed to semantic) equivalence test
	 *
	 * Do a deep, strict (as opposed to semantic) equivalence test.
	 * @return false iff every member of t is a duplicate copy of every member of this; true otherwise
	 */
	virtual bool operator!=(const TreeNode* t) const;
	 
	/** @brief Do a deep, strict (as opposed to semantic) equivalence test
	 *
	 * Do a deep, strict (as opposed to semantic) equivalence test.
	 * @return false iff every member of t is a duplicate copy of every member of this; true otherwise
	 */
	bool operator!=(const SelectFilter& t) const;
	
private:
	//default okay?
	//SelectFilter& operator=(const SelectFilter& rhs);

	 std::vector<SRCP> fCols;
	 SOP fOp;
	 SCSEP fSub;
	 bool fCorrelated;
	 std::string fData;
	 uint64_t fReturnedColPos;	// offset in fSub->returnedColList to indicate the start of projection
};

std::ostream& operator<<(std::ostream& output, const SelectFilter& rhs);

} 
#endif //SELECTFILTER_H

