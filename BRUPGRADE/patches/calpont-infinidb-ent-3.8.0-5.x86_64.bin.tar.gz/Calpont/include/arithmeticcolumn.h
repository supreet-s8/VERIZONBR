/*

Copyright (C) 2009-2011 Calpont Corporation.

Use of and access to the Calpont InfiniDB Community software is subject to the
terms and conditions of the Calpont Open Source License Agreement. Use of and
access to the Calpont InfiniDB Enterprise software is subject to the terms and
conditions of the Calpont End User License Agreement.

This program is distributed in the hope that it will be useful, and unless
otherwise noted on your license agreement, WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Please refer to the Calpont Open Source License Agreement and the Calpont End
User License Agreement for more details.

You should have received a copy of either the Calpont Open Source License
Agreement or the Calpont End User License Agreement along with this program; if
not, it is your responsibility to review the terms and conditions of the proper
Calpont license agreement by visiting http://www.calpont.com for the Calpont
InfiniDB Enterprise End User License Agreement or http://www.infinidb.org for
the Calpont InfiniDB Community Calpont Open Source License Agreement.

Calpont may make changes to these license agreements from time to time. When
these changes are made, Calpont will make a new copy of the Calpont End User
License Agreement available at http://www.calpont.com and a new copy of the
Calpont Open Source License Agreement available at http:///www.infinidb.org.
You understand and agree that if you use the Program after the date on which
the license agreement authorizing your use has changed, Calpont will treat your
use as acceptance of the updated License.

*/

/***********************************************************************
*   $Id: arithmeticcolumn.h 7409 2011-02-08 14:38:50Z rdempsey $
*
*
***********************************************************************/
/** @file */

#ifndef ARITHMETICCOLUMN_H
#define ARITHMETICCOLUMN_H
#include <string>
#include <iosfwd>
#include <stack>

#include "returnedcolumn.h"
#include "expressionparser.h"

/**
 * Namespace
 */
namespace execplan { 
	class SimpleColumn;
	class AggregateColumn;

/**
 * @brief A class to represent a arithmetic expression return column
 * 
 * This class is a specialization of class ReturnedColumn that
 * handles an arithmetic expression.
 */
class ArithmeticColumn : public ReturnedColumn {
public:
	ArithmeticColumn();
	ArithmeticColumn( const std::string& sql, const u_int32_t sessionID=0 );
	ArithmeticColumn( const ArithmeticColumn& rhs, const u_int32_t sessionID=0 );
	virtual ~ArithmeticColumn();

	inline const ParseTree* expression() const
	{
	    return fExpression;
	}

	/** get table alias name
	 *
	 * get the table alias name for this arithmetic function
	 */
	inline const std::string& tableAlias () const
	{
		return fTableAlias;
	}

	/** set table alias name
	 *
	 * set the table alias name for this arithmetic function
	 */
	inline void tableAlias (const std::string& tableAlias)
	{
	    fTableAlias = tableAlias;
	}

	/** set the parse tree
	 *
	 * set the parse tree to expression.
	 * @note this object takes ownership of the tree. The supplied pointer is set to null.
	 */
	void expression (ParseTree*& expression);

	/** 
	 * get asc flag
	 */
	inline const bool asc() const { return fAsc; }

	/** 
	 * set asc flag
	 */
	inline void asc(const bool asc) { fAsc = asc; }

	/** 
	 * get SQL representation of this object
	 */
	virtual const std::string data() const { return fData; }

	/** 
	 * set SQL representation of this object
	 */
	virtual void data(const std::string data) { fData = data; }

	/**
	 * virtual stream method
	 */
	virtual const std::string toString() const;

	/** return a copy of this pointer
	 *
	 * deep copy of this pointer and return the copy
	 */
	inline virtual ArithmeticColumn* clone() const
	{
		return new ArithmeticColumn (*this);
	}

	/**
	 * The serialization interface
	 */
	virtual void serialize(messageqcpp::ByteStream&) const;
	virtual void unserialize(messageqcpp::ByteStream&);

	/** @brief Do a deep, strict (as opposed to semantic) equivalence test
	 *
	 * Do a deep, strict (as opposed to semantic) equivalence test.
	 * @return true iff every member of t is a duplicate copy of every member of this; false otherwise
		 */
	virtual bool operator==(const TreeNode* t) const;

	/** @brief Do a deep, strict (as opposed to semantic) equivalence test
	 *
	 * Do a deep, strict (as opposed to semantic) equivalence test.
	 * @return true iff every member of t is a duplicate copy of every member of this; false otherwise
	 */
	bool operator==(const ArithmeticColumn& t) const;

	/** @brief Do a deep, strict (as opposed to semantic) equivalence test
	 *
	 * Do a deep, strict (as opposed to semantic) equivalence test.
	 * @return false iff every member of t is a duplicate copy of every member of this; true otherwise
	 */
	virtual bool operator!=(const TreeNode* t) const;
	 
	/** @brief Do a deep, strict (as opposed to semantic) equivalence test
	 *
	 * Do a deep, strict (as opposed to semantic) equivalence test.
	 * @return false iff every member of t is a duplicate copy of every member of this; true otherwise
	 */
	bool operator!=(const ArithmeticColumn& t) const;

private:
	std::string fTableAlias;   // table alias for this column
	bool fAsc;                 // asc flag for order by column
	std::string fData;

	/** build expression tree
	 * 
	 * this function is called by the constructor. the incomming
	 * sql string is parsed and tokenized and built into a
	 * parse tree.
	 */
	void buildTree();

	/** get next token from expression
	 * 
	 * this is a util function used by buildTree(). next token string
	 * is retrived from expression from curPos, until end char.
	 * return the retrived token. curPos reference is updated to the
	 * new position after end char
	 */
	const std::string nextToken(std::string::size_type &curPos, char end) const;

	/***********************************************************
	 *                 F&E framework                           *
	 ***********************************************************/
public:	 
	virtual std::string getStrVal(rowgroup::Row& row, bool& isNull) 
	{ 
		return fExpression->getStrVal(row, isNull); 
	}

	virtual int64_t getIntVal(rowgroup::Row& row, bool& isNull) 
	{ 
		return fExpression->getIntVal(row, isNull);
	}

	virtual float getFloatVal(rowgroup::Row& row, bool& isNull)
	{
		return fExpression->getFloatVal(row, isNull);
	}

	virtual double getDoubleVal(rowgroup::Row& row, bool& isNull) 
	{
		return fExpression->getDoubleVal(row, isNull); 
	}

	virtual IDB_Decimal getDecimalVal(rowgroup::Row& row, bool& isNull)
	{
		return fExpression->getDecimalVal(row, isNull);
	}

	virtual int32_t getDateIntVal(rowgroup::Row& row, bool& isNull)
	{
		return fExpression->getDateIntVal(row, isNull);
	}

	virtual int64_t getDatetimeIntVal(rowgroup::Row& row, bool& isNull)
	{
		return fExpression->getDatetimeIntVal(row, isNull);
	}

	virtual bool getBoolVal(rowgroup::Row& row, bool& isNull)
	{
		return fExpression->getBoolVal(row, isNull);
	}


private:
	ParseTree* fExpression;
	void evaluate(rowgroup::Row& row) {}
};

/**
*  ostream operator
*/
std::ostream& operator<<(std::ostream& output, const ArithmeticColumn& rhs);

} 
#endif //ARITHMETICCOLUMN_H

