/*

Copyright (C) 2009-2011 Calpont Corporation.

Use of and access to the Calpont InfiniDB Community software is subject to the
terms and conditions of the Calpont Open Source License Agreement. Use of and
access to the Calpont InfiniDB Enterprise software is subject to the terms and
conditions of the Calpont End User License Agreement.

This program is distributed in the hope that it will be useful, and unless
otherwise noted on your license agreement, WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Please refer to the Calpont Open Source License Agreement and the Calpont End
User License Agreement for more details.

You should have received a copy of either the Calpont Open Source License
Agreement or the Calpont End User License Agreement along with this program; if
not, it is your responsibility to review the terms and conditions of the proper
Calpont license agreement by visiting http://www.calpont.com for the Calpont
InfiniDB Enterprise End User License Agreement or http://www.infinidb.org for
the Calpont InfiniDB Community Calpont Open Source License Agreement.

Calpont may make changes to these license agreements from time to time. When
these changes are made, Calpont will make a new copy of the Calpont End User
License Agreement available at http://www.calpont.com and a new copy of the
Calpont Open Source License Agreement available at http:///www.infinidb.org.
You understand and agree that if you use the Program after the date on which
the license agreement authorizing your use has changed, Calpont will treat your
use as acceptance of the updated License.

*/

/***********************************************************************
*   $Id: treenodeimpl.h 7409 2011-02-08 14:38:50Z rdempsey $
*
*
***********************************************************************/
/** @file */

#ifndef EXECPLAN_TREENODEIMPL_H
#define EXECPLAN_TREENODEIMPL_H
#include <string>
#include <iosfwd>

#include "treenode.h"

namespace messageqcpp {
class ByteStream;
}

/**
 * Namespace
 */
namespace execplan { 
/** @brief A class to represent a generic TreeNode
 * 
 * This class is a concrete implementation of the abstract class TreeNode. It's only used to 
 *  hold generic data long enough to parse into specific derrived classes.
 */
class TreeNodeImpl : public TreeNode {

public:

	/**
	 * Constructors
	 */
	TreeNodeImpl();
	TreeNodeImpl(const std::string& sql);
	// not needed yet
	//TreeNodeImpl(const TreeNodeImpl& rhs);
	
	/**
	 * Destructors
	 */
	virtual ~TreeNodeImpl();
	/**
	 * Accessor Methods
	 */
	
	/**
	 * Operations
	 */
	virtual const std::string toString() const;

	virtual const std::string data() const { return fData; }
	virtual void data(const std::string data) { fData = data; }
	 
    /** return a copy of this pointer
	 *
	 * deep copy of this pointer and return the copy
	 */	
	inline virtual TreeNodeImpl* clone() const
	{
	    return new TreeNodeImpl (*this);
	}
		 
	 /**
	  * The serialization interface
	  */
	 virtual void serialize(messageqcpp::ByteStream&) const;
	 virtual void unserialize(messageqcpp::ByteStream&);
	 
	 /** @brief Do a deep, strict (as opposed to semantic) equivalence test
	  *
	  * Do a deep, strict (as opposed to semantic) equivalence test.
	  * @return true iff every member of t is a duplicate copy of every member of this; false otherwise
	  */
	 virtual bool operator==(const TreeNode* t) const;
	 
	 /** @brief Do a deep, strict (as opposed to semantic) equivalence test
	  *
	  * Do a deep, strict (as opposed to semantic) equivalence test.
	  * @return true iff every member of t is a duplicate copy of every member of this; false otherwise
	  */
	 bool operator==(const TreeNodeImpl& t) const;
	 
	 /** @brief Do a deep, strict (as opposed to semantic) equivalence test
	  *
	  * Do a deep, strict (as opposed to semantic) equivalence test.
	  * @return false iff every member of t is a duplicate copy of every member of this; true otherwise
	  */
	 virtual bool operator!=(const TreeNode* t) const;
	 
	 /** @brief Do a deep, strict (as opposed to semantic) equivalence test
	  *
	  * Do a deep, strict (as opposed to semantic) equivalence test.
	  * @return false iff every member of t is a duplicate copy of every member of this; true otherwise
	  */
	 bool operator!=(const TreeNodeImpl& t) const;
	 
private:
	//default okay
	//TreeNodeImpl& operator=(const TreeNodeImpl& rhs);

	std::string fData;

};

std::ostream& operator<<(std::ostream& os, const TreeNodeImpl& rhs);

} 
#endif //EXECPLAN_TREENODEIMPL_H

