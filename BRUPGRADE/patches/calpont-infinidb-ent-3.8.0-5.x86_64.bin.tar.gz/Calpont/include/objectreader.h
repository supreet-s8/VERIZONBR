/*

Copyright (C) 2009-2011 Calpont Corporation.

Use of and access to the Calpont InfiniDB Community software is subject to the
terms and conditions of the Calpont Open Source License Agreement. Use of and
access to the Calpont InfiniDB Enterprise software is subject to the terms and
conditions of the Calpont End User License Agreement.

This program is distributed in the hope that it will be useful, and unless
otherwise noted on your license agreement, WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Please refer to the Calpont Open Source License Agreement and the Calpont End
User License Agreement for more details.

You should have received a copy of either the Calpont Open Source License
Agreement or the Calpont End User License Agreement along with this program; if
not, it is your responsibility to review the terms and conditions of the proper
Calpont license agreement by visiting http://www.calpont.com for the Calpont
InfiniDB Enterprise End User License Agreement or http://www.infinidb.org for
the Calpont InfiniDB Community Calpont Open Source License Agreement.

Calpont may make changes to these license agreements from time to time. When
these changes are made, Calpont will make a new copy of the Calpont End User
License Agreement available at http://www.calpont.com and a new copy of the
Calpont Open Source License Agreement available at http:///www.infinidb.org.
You understand and agree that if you use the Program after the date on which
the license agreement authorizing your use has changed, Calpont will treat your
use as acceptance of the updated License.

*/

/******************************************************************************
 * $Id: objectreader.h 8326 2012-02-15 18:58:10Z xlou $
 *
 *****************************************************************************/

/** @file 
 * class ObjectReader interface
 */

#ifndef EXECPLAN_OBJECTREADER_H
#define EXECPLAN_OBJECTREADER_H

#include <exception>
#include <string>
#include <stdint.h>

namespace messageqcpp {
class ByteStream;
}

namespace execplan {

	class TreeNode;
	class ParseTree;
	class CalpontExecutionPlan;
	
/** @brief A class for creating execplan classes from ByteStreams.
 *
 * A class currently used for recreating execplan polymorphic classes
 * and dynamic objects from ByteStreams.
 */

class ObjectReader {

public:

	class UnserializeException : public std::exception {
	public:
		UnserializeException(std::string) throw();
		virtual ~UnserializeException() throw();
		virtual const char* what() const throw();
	private:
		std::string fWhat;
	};

	/** @brief Enumerates classes supporting serialization
	 *
	 * This defines one constant for each class that supports
	 * serialization.
	 */
	enum CLASSID {
		ZERO,      // an appropriate initializer
		NULL_CLASS,		// to denote that some member is NULL
		
		/**** TreeNodes */
		TREENODE,
		TREENODEIMPL,
		RETURNEDCOLUMN,
		AGGREGATECOLUMN,
		GROUPCONCATCOLUMN,
		ARITHMETICCOLUMN,
		CONSTANTCOLUMN,
		FUNCTIONCOLUMN,
		ROWCOLUMN,
		
		SIMPLECOLUMN,
		SIMPLECOLUMN_INT1,
		SIMPLECOLUMN_INT2,
		SIMPLECOLUMN_INT4,
		SIMPLECOLUMN_INT8,
		SIMPLECOLUMN_DECIMAL1,
		SIMPLECOLUMN_DECIMAL2,
		SIMPLECOLUMN_DECIMAL4,
		SIMPLECOLUMN_DECIMAL8,
		JOINLIKEFILTERCOLUMN,

		FILTER,
		CONDITIONFILTER,
		EXISTSFILTER,
		SELECTFILTER,
		SIMPLEFILTER,
		SIMPLESCALARFILTER,
        EXISTSJOINLIKEFILTER,

		OPERATOR,
		ARITHMETICOPERATOR,
		PREDICATEOPERATOR,
		LOGICOPERATOR,

		/**** /TreeNodes */
		
		PARSETREE,
		CALPONTSELECTEXECUTIONPLAN,
		CONSTANTFILTER,
		OUTERJOINONFILTER,
	};

	typedef u_int8_t id_t;    //expand as necessary

	/** @brief Creates a new TreeNode object from the ByteStream
	 *
	 * @param b The ByteStream to create it from
	 * @return A newly allocated TreeNode
	 */
	static TreeNode* createTreeNode(messageqcpp::ByteStream& b);
	
	/** @brief Creates a new ParseTree from the ByteStream
	 *
	 * @note This is much faster than a version that creates a fully
	 * generalized ExpressionTree<T> but is obviously less flexible.
	 * @param b The ByteStream to create it from
	 * @return A newly allocated ParseTree
	 */
	static ParseTree* createParseTree(messageqcpp::ByteStream& b);
	
	/** @brief Creates a new CalpontExecutionPlan from the ByteStream
	 *
	 * @param b The ByteStream to create it from
	 * @return A newly allocated CalpontExecutionPlan
	 */
	static CalpontExecutionPlan* createExecutionPlan(messageqcpp::ByteStream& b);
	
	/** @brief Serialize() for ParseTrees
	 *
	 * This function effectively serializes a ParseTree.  It is not part
	 * of ExpressionTree because it cannot be easily generalized for all
	 * possible instantiations.
	 * @param tree The ParseTree to write out
	 * @param b The ByteStream to write tree to
	 */
	static void writeParseTree(const ParseTree* tree, 
							   messageqcpp::ByteStream& b);
	
	/** @brief Verify the type of the next object in the ByteStream
	 *
	 * @param b The ByteStream to read from
	 * @param type The type it should be
	 * @throw UnserializeException if the type does not match; this is a fatal error.
	 */
	static void checkType(messageqcpp::ByteStream &b, const CLASSID type);
};

}
#endif // EXECPLAN_OBJECTREADER_H

