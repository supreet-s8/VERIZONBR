/*

Copyright (C) 2009-2011 Calpont Corporation.

Use of and access to the Calpont InfiniDB Community software is subject to the
terms and conditions of the Calpont Open Source License Agreement. Use of and
access to the Calpont InfiniDB Enterprise software is subject to the terms and
conditions of the Calpont End User License Agreement.

This program is distributed in the hope that it will be useful, and unless
otherwise noted on your license agreement, WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Please refer to the Calpont Open Source License Agreement and the Calpont End
User License Agreement for more details.

You should have received a copy of either the Calpont Open Source License
Agreement or the Calpont End User License Agreement along with this program; if
not, it is your responsibility to review the terms and conditions of the proper
Calpont license agreement by visiting http://www.calpont.com for the Calpont
InfiniDB Enterprise End User License Agreement or http://www.infinidb.org for
the Calpont InfiniDB Community Calpont Open Source License Agreement.

Calpont may make changes to these license agreements from time to time. When
these changes are made, Calpont will make a new copy of the Calpont End User
License Agreement available at http://www.calpont.com and a new copy of the
Calpont Open Source License Agreement available at http:///www.infinidb.org.
You understand and agree that if you use the Program after the date on which
the license agreement authorizing your use has changed, Calpont will treat your
use as acceptance of the updated License.

*/

/***********************************************************************
 *   $Id: we_xmlgendata.h 2968 2011-05-13 19:01:26Z rdempsey $
 *
 ***********************************************************************/
/** @file */
#ifndef _WE_XMLGENDATA_H_
#define _WE_XMLGENDATA_H_

#include <iosfwd>
#include <string>
#include <vector>
#include <map>
#include "calpontsystemcatalog.h"

#if defined(_MSC_VER) && defined(WRITEENGINEXMLGENDATA_DLLEXPORT)
#define EXPORT __declspec(dllexport)
#else
#define EXPORT
#endif

namespace WriteEngine
{

/** @brief Base class for storing input data used to generate a Job XML file.
 *
 *  This class represents common code refactored out of inputmgr.h, under
 *  tools/dbloadxml.  It was moved to writeengine/xml so that this common
 *  code could be used by both colxml and cpimport.
 */
class XMLGenData
{
  public:
    typedef std::vector<execplan::CalpontSystemCatalog::TableName> TableList;
    typedef std::map<std::string, std::string> ParmList;
    typedef std::vector<std::string> LoadNames;

    // Valid parms that can be stored and retrieved from XMLGenData
    EXPORT const static std::string DELIMITER;
    EXPORT const static std::string DESCRIPTION;
#if defined(_MSC_VER) && !defined(WRITEENGINEXMLGENDATA_DLLEXPORT)
    __declspec(dllimport)
#endif
    EXPORT const static std::string ENCLOSED_BY_CHAR;
#if defined(_MSC_VER) && !defined(WRITEENGINEXMLGENDATA_DLLEXPORT)
    __declspec(dllimport)
#endif
    EXPORT const static std::string ESCAPE_CHAR;
#if defined(_MSC_VER) && !defined(WRITEENGINEXMLGENDATA_DLLEXPORT)
    __declspec(dllimport)
#endif
    EXPORT const static std::string JOBID;
    EXPORT const static std::string MAXERROR;
    EXPORT const static std::string NAME;
    EXPORT const static std::string PATH;
#if defined(_MSC_VER) && !defined(WRITEENGINEXMLGENDATA_DLLEXPORT)
    __declspec(dllimport)
#endif
    EXPORT const static std::string RPT_DEBUG;
    EXPORT const static std::string USER;
    EXPORT const static std::string NO_OF_READ_BUFFER;
    EXPORT const static std::string READ_BUFFER_CAPACITY;
    EXPORT const static std::string WRITE_BUFFER_SIZE;
    EXPORT const static std::string EXT;

    /** @brief XMLGenData constructor
     */
    EXPORT XMLGenData();

    /** @brief XMLGenData destructor
     */
    EXPORT virtual ~XMLGenData();

    /** @brief Print contents of this object to the specified stream.
     */
    EXPORT virtual void print(std::ostream& os) const;

    EXPORT std::string getParm(const std::string& key) const;
    const TableList&   getTables()    const { return fTables;    }
    const std::string& getSchema()    const { return fSchema;    }
    const LoadNames&   getLoadNames() const { return fLoadNames; }

  protected:
    TableList   fTables;
    ParmList    fParms;
    std::string fSchema;
    LoadNames   fLoadNames;

  private:
    XMLGenData(const XMLGenData&);             // disable default copy ctor
    XMLGenData& operator=(const XMLGenData&);  // disable default assignment
};

}

#undef EXPORT

#endif
