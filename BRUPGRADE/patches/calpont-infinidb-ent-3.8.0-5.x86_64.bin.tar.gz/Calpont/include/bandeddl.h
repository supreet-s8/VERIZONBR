/*

Copyright (C) 2009-2011 Calpont Corporation.

Use of and access to the Calpont InfiniDB Community software is subject to the
terms and conditions of the Calpont Open Source License Agreement. Use of and
access to the Calpont InfiniDB Enterprise software is subject to the terms and
conditions of the Calpont End User License Agreement.

This program is distributed in the hope that it will be useful, and unless
otherwise noted on your license agreement, WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Please refer to the Calpont Open Source License Agreement and the Calpont End
User License Agreement for more details.

You should have received a copy of either the Calpont Open Source License
Agreement or the Calpont End User License Agreement along with this program; if
not, it is your responsibility to review the terms and conditions of the proper
Calpont license agreement by visiting http://www.calpont.com for the Calpont
InfiniDB Enterprise End User License Agreement or http://www.infinidb.org for
the Calpont InfiniDB Community Calpont Open Source License Agreement.

Calpont may make changes to these license agreements from time to time. When
these changes are made, Calpont will make a new copy of the Calpont End User
License Agreement available at http://www.calpont.com and a new copy of the
Calpont Open Source License Agreement available at http:///www.infinidb.org.
You understand and agree that if you use the Program after the date on which
the license agreement authorizing your use has changed, Calpont will treat your
use as acceptance of the updated License.

*/

/******************************************************************************
 * $Id: bandeddl.h 7409 2011-02-08 14:38:50Z rdempsey $
 *
 *****************************************************************************/

/** @file 
 * class XXX interface
 */

#include <set>
#include <boost/thread.hpp>
#include <boost/thread/condition.hpp>

#include "largedatalist.h"
#include "bucketdl.h"

#include <time.h>

#ifndef _BANDEDDL_HPP_
#define _BANDEDDL_HPP_

namespace joblist {

/** @brief class BandedDL
 *
 */
template<typename element_t>
class BandedDL : public LargeDataList<std::vector<element_t>, element_t>
{
	typedef LargeDataList<std::vector<element_t>, element_t> base;

	public:
		BandedDL(uint numConsumers, const ResourceManager& rm);
		BandedDL(BucketDL<element_t> &, uint numConsumers, const ResourceManager& rm);
		virtual ~BandedDL();

		int64_t saveBand();
		void loadBand(uint64_t);
		int64_t bandCount();

		/// loads the first band, next() will return the first element
		void restart();

		void insert(const element_t &);
		void insert(const std::vector<element_t> &);
		uint64_t getIterator();
		bool next(uint64_t it, element_t *e);
		void endOfInput();
		using DataListImpl<std::vector<element_t>, element_t>::shrink;
		uint64_t totalSize();
		bool next(uint64_t it, element_t *e, bool *endOfBand);

	protected:

	private:
		explicit BandedDL() { };
		explicit BandedDL(const BandedDL &) { };
		BandedDL & operator=(const BandedDL &) { };
		
		// vars to support the WSDL-like next() fcn
		boost::condition nextSetLoaded;
		uint64_t waitingConsumers;
};

template<typename element_t>
  BandedDL<element_t>::BandedDL(uint nc, const ResourceManager& rm) : base(nc,  sizeof(uint64_t), sizeof(uint64_t), rm)
{
	//pthread_cond_init(&nextSetLoaded, NULL);
	waitingConsumers = 0;
}
	

template<typename element_t>
  BandedDL<element_t>::BandedDL(BucketDL<element_t> &b, uint nc, const ResourceManager& rm) : base(nc, sizeof(uint64_t), sizeof(uint64_t), rm)
{
	uint64_t i, it;
	element_t e;
	bool more;

	//pthread_cond_init(&nextSetLoaded, NULL);
	waitingConsumers = 0;

#ifdef PROFILE
	struct timespec ts1, ts2;
	clock_gettime(CLOCK_REALTIME, &ts1);
#endif

	for (i = 0; i < b.bucketCount(); i++) {
		it = b.getIterator(i);
		more = b.next(i, it, &e);
		while (more) {
 			insert(e);
			more = b.next(i, it, &e);
		}
		saveBand();
	}
	endOfInput();

#ifdef PROFILE
	clock_gettime(CLOCK_REALTIME, &ts2);
	/* What should we do with this profile info? */
#endif

}

template<typename element_t>
BandedDL<element_t>::~BandedDL()
{ 
	//pthread_cond_destroy(&nextSetLoaded);
}

template<typename element_t>
int64_t BandedDL<element_t>::saveBand()
{
	int64_t ret;
	
	if (base::multipleProducers)
	 	base::lock();
	sort(base::c->begin(), base::c->end());
	if (typeid(element_t) == typeid(ElementType) ||
		typeid(element_t) == typeid(DoubleElementType))
		ret = base::save_contiguous();
	else
		ret = base::save();
	base::registerNewSet();
	if (base::multipleProducers)
		base::unlock();
	
	return ret;
}

template<typename element_t>
void BandedDL<element_t>::loadBand(uint64_t band)
{
	
	base::lock();
	if (typeid(element_t) == typeid(ElementType) ||
		typeid(element_t) == typeid(DoubleElementType))
		base::load_contiguous(band);
	else
		base::load(band);
	if (waitingConsumers > 0)
		nextSetLoaded.notify_all(); //pthread_cond_broadcast(&nextSetLoaded);
	base::unlock();
}

template<typename element_t>
int64_t BandedDL<element_t>::bandCount()
{
	int64_t ret;

	base::lock();
	ret = base::setCount();
	base::unlock();
	return ret;	
}

template<typename element_t>
uint64_t BandedDL<element_t>::getIterator()
{
	uint64_t ret;

	base::lock();
	ret = base::getIterator();
	base::unlock();
	return ret;
}

template<typename element_t>
void BandedDL<element_t>::endOfInput()
{
	base::lock();
	sort(base::c->begin(), base::c->end());
	base::endOfInput();
  	if (base::setCount > 1) {
		if (typeid(element_t) == typeid(ElementType) ||
			typeid(element_t) == typeid(DoubleElementType)) {
			base::save_contiguous();
			base::load_contiguous(0);
		}
		else {
			base::save();
			base::load(0);
		}
  	}
	else
		base::resetIterators();
	base::unlock();
}

template<typename element_t>
bool BandedDL<element_t>::next(uint64_t it, element_t *e)
{

/* Note: this is the code for WSDL::next().  The more I think about it,
the more I think they're the same thing.  Not entirely sure yet though. */

	bool ret, locked = false;
	uint64_t nextSet;

 	if (base::numConsumers > 1 || base::phase == 0) {
 		locked = true;
		base::lock();
 	}

	ret = base::next(it, e);

	/* XXXPAT: insignificant race condition here.  Technically, there's no
	guarantee the caller will be wakened when the next set is loaded.  It could
	get skipped.  It won't happen realistically, but it exists... */

	// signifies the caller is at the end of the loaded set, 
	// but there are more sets
	if (ret == false && (base::loadedSet < base::setCount - 1)) {

 		nextSet = base::loadedSet + 1;
		waitingConsumers++;
		if (waitingConsumers < base::numConsumers)
			while (nextSet != base::loadedSet) {
// 				std::cout << "waiting on nextSetLoaded" << std::endl;
				nextSetLoaded.wait(this->mutex); //pthread_cond_wait(&nextSetLoaded, &(this->mutex));
			}
		else {
// 			std::cout << "loading set " << nextSet << std::endl;
			if (typeid(element_t) == typeid(ElementType) ||
				typeid(element_t) == typeid(DoubleElementType))
				base::load_contiguous(nextSet);
			else
				base::load(nextSet);
			nextSetLoaded.notify_all(); //pthread_cond_broadcast(&nextSetLoaded);
		}
		waitingConsumers--;
		ret = base::next(it, e);
	}

	if (ret == false && ++base::consumersFinished == base::numConsumers)
		base::shrink();
	if (locked)
		base::unlock();

	return ret;	

}

template<typename element_t>
void BandedDL<element_t>::insert(const element_t &e)
{
	if (base::multipleProducers)
		base::lock();
	base::insert(e);
	if (base::multipleProducers)
		base::unlock();
}

template<typename element_t>
void BandedDL<element_t>::insert(const std::vector<element_t> &e)
{
	throw std::logic_error("BandedDL::insert(vector) isn't implemented yet");
}

/*
template<typename element_t>
bool BandedDL<element_t>::get(const element_t &key, element_t *out)
{
	typename std::set<element_t>::iterator it;
	bool ret, locked = false;

 	if (base::numConsumers > 1 || base::phase == 0) {
 		locked = true;
		base::lock();
 	}

	it = base::c->find(key);
	if (it != base::c->end()) {
		*out = *it;
		ret = true;
	}
	else
		ret = false;

	if (locked)
		base::unlock();

	return ret;
}
*/

template<typename element_t>
void BandedDL<element_t>::restart()
{
	base::lock();
// 	base::waitForConsumePhase();

	// hack!  has it been shrunk already?
	if (base::c == NULL)
		base::c = new std::vector<element_t>();

	if (base::setCount > 1) {
		if (typeid(element_t) == typeid(ElementType) ||
			typeid(element_t) == typeid(DoubleElementType))
			base::load_contiguous(0);
		else
			base::load(0);
	}
	else
		base::resetIterators();
	base::unlock();
}

template<typename element_t>
bool BandedDL<element_t>::next(uint64_t it, element_t *e, bool *endOfBand)
{
	bool ret, locked = false;

 	if (base::numConsumers > 1 || base::phase == 0) {
 		locked = true;
		base::lock();
 	}

	base::waitForConsumePhase();
	ret = base::next(it, e);
	if (ret) {
		if (locked)
			base::unlock();
		*endOfBand = false;
		return ret;
	}
	else {
		*endOfBand = true;
		ret = base::loadedSet < (base::setCount() - 1);
		if (locked)
			base::unlock();
		return ret;
	}
}

template<typename element_t>
uint64_t BandedDL<element_t>::totalSize()
{
//std::cout << "BandedDL: c.size() = " << base::c.size() << std::endl; return base::c.size();
	uint64_t ret;

	base::lock();
	ret = base::totalSize();
	base::unlock();
	
	return ret;
}

}  // namespace

#endif

