/*

Copyright (C) 2009-2011 Calpont Corporation.

Use of and access to the Calpont InfiniDB Community software is subject to the
terms and conditions of the Calpont Open Source License Agreement. Use of and
access to the Calpont InfiniDB Enterprise software is subject to the terms and
conditions of the Calpont End User License Agreement.

This program is distributed in the hope that it will be useful, and unless
otherwise noted on your license agreement, WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Please refer to the Calpont Open Source License Agreement and the Calpont End
User License Agreement for more details.

You should have received a copy of either the Calpont Open Source License
Agreement or the Calpont End User License Agreement along with this program; if
not, it is your responsibility to review the terms and conditions of the proper
Calpont license agreement by visiting http://www.calpont.com for the Calpont
InfiniDB Enterprise End User License Agreement or http://www.infinidb.org for
the Calpont InfiniDB Community Calpont Open Source License Agreement.

Calpont may make changes to these license agreements from time to time. When
these changes are made, Calpont will make a new copy of the Calpont End User
License Agreement available at http://www.calpont.com and a new copy of the
Calpont Open Source License Agreement available at http:///www.infinidb.org.
You understand and agree that if you use the Program after the date on which
the license agreement authorizing your use has changed, Calpont will treat your
use as acceptance of the updated License.

*/

/******************************************************************************
 * $Id: tracer.h 1266 2011-02-08 14:36:09Z rdempsey $
 *
 *****************************************************************************/

/** @file 
 * class DBRM
 */

#ifndef TRACER_H_
#define TRACER_H_

#include <sys/types.h>
#include <string>
#include <vector>
#include <stdint.h>

#if defined(_MSC_VER) && defined(TRACER_DLLEXPORT)
#define EXPORT __declspec(dllexport)
#else
#define EXPORT
#endif

namespace BRM {

/** @brief Trace beginning and end of a call.
*
* When turned on, fDebug is true, Tracer writes informational messages to /var/log/Calpont/brm.log.
* It keeps track of integral, string and boolean inputs, and integral and boolean outputs.
* If it should print a message immediately from the constructor, call it with the final parameter,
* writeNow, true (default).  If input and output parameters need to be added, call it with
* writeNow false.  Then writeBegin() must be called explicitely. 
*
* Input parameters are added with addInput, output with addOutput.
* 
* On end, if debug is set, an end message is printed with the output parameters. 
*/
class Tracer {
	public:
		/** @brief Tracer Constructor
		 *
		 * @param file (in string) the file name.
		 * @param line (in int ) the line number.  
		 * @param msg (in string) the message that will be printed at the begin and end.
		 * @param debug (in bool) if information should be printed
		 * @param writeNow (in bool) whether to print the begin message from the constructor
		 * 		(printed if debug is true.)
		 */
		EXPORT Tracer(const std::string& file, int line, const std::string& msg, bool debug, bool writeNow = true);

		/** @brief Tracer destructor
		 *
		 * Prints the output message if debug is true.
		 */		
		EXPORT ~Tracer();

		/** @brief writeBegin
		 *
		 * Prints the begin message in form:
		 * file@line number begin -  followed by the input parameters:
		 * name: (value)
		 */		
		EXPORT void writeBegin();

		/** @brief writeEnd
		 *
		 * Prints the end message in form:
		 * file@line number begin -  followed by the output parameters:
		 * name: (value)
		 */		
		EXPORT void writeEnd();

		/** @brief writeDirect
		 *
		 * Prints specified string immediately (directly) to the brm log.
		 * Different than the addInput and addOutput functions that
		 * accumulate the data for later printing to the brm log.
		 * @param msg String to be printed to the brm log
		 */		
		void writeDirect(const std::string& msg);

		/** @brief addInput
		 *
		 * @param name (in string) the variable name.
		 * @param value (in int* or string* or bool* ) the variable
		 */
		EXPORT void addInput(const std::string& name, const int* value);
		EXPORT void addInput(const std::string& name, const std::string* value);
		EXPORT void addInput(const std::string& name, const bool* value);
		EXPORT void addInput(const std::string& name, const short* value);
		EXPORT void addInput(const std::string& name, const int64_t* value);

		/** @brief addOutput
		 *
		 * @param name (in string) the variable name.
		 * @param value (in int* or bool* ) the variable  
		 */
		EXPORT void addOutput(const std::string& name, const int* value);
		EXPORT void addOutput(const std::string& name, const bool* value);
		EXPORT void addOutput(const std::string& name, const short* value);
		EXPORT void addOutput(const std::string& name, const int64_t* value);

	private:
		std::string timeStamp();
		typedef std::vector<std::pair <std::string, const int*> > ValuesVec;
		typedef std::vector<std::pair <std::string, const std::string*> > ValuesStrVec;
		typedef std::vector<std::pair <std::string, const bool*> > ValuesBoolVec;
		typedef std::vector<std::pair <std::string, const short*> > ValuesShortVec;
		typedef std::vector<std::pair <std::string, const int64_t*> > ValuesInt64Vec;
		std::string fFileName;
		int fLine;
		std::string fMsg;
		bool fDebug;
		ValuesVec fInputs;
		ValuesStrVec fStrInputs;
		ValuesBoolVec fBoolInputs;
		ValuesShortVec fShortInputs;
		ValuesInt64Vec fInt64Inputs;
		ValuesVec fOutputs;
		ValuesBoolVec fBoolOutputs;
		ValuesShortVec fShortOutputs;
		ValuesInt64Vec fInt64Outputs;
		pid_t fpid;
};

/** @brief tracer macros
*
* Use the contructors if there is a bool fDebug in scope.
*/


#define TRACER_WRITENOW(a)\
 	Tracer tracer(__FILE__, __LINE__, a, fDebug); 

#define TRACER_WRITELATER(a)\
 	Tracer tracer(__FILE__, __LINE__, a, fDebug, false); 

#define TRACER_ADDINPUT(a)\
 	tracer.addInput((std::string)#a, (int*)&a); 

#define TRACER_ADDSTRINPUT(a)\
 	tracer.addInput((std::string)#a, &a); 

#define TRACER_ADDBOOLINPUT(a)\
 	tracer.addInput((std::string)#a, &a); 

#define TRACER_ADDSHORTINPUT(a)\
 	tracer.addInput((std::string)#a, (short*)&a); 

#define TRACER_ADDINT64INPUT(a)\
 	tracer.addInput((std::string)#a, (int64_t*)&a); 

#define TRACER_ADDOUTPUT(a)\
 	tracer.addOutput((std::string)#a, (int*)&a); 

#define TRACER_ADDBOOLOUTPUT(a)\
 	tracer.addOutput((std::string)#a, &a); 

#define TRACER_ADDSHORTOUTPUT(a)\
 	tracer.addOutput((std::string)#a, (short*)&a); 

#define TRACER_ADDINT64OUTPUT(a)\
 	tracer.addOutput((std::string)#a, (int64_t*)&a); 

#define TRACER_WRITE\
 	tracer.writeBegin(); 

#define TRACER_WRITEDIRECT(msg)\
 	tracer.writeDirect(msg); 
}

#undef EXPORT

#endif 

