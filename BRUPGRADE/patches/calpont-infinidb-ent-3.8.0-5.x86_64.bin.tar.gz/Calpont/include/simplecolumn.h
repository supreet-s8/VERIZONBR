/*

Copyright (C) 2009-2011 Calpont Corporation.

Use of and access to the Calpont InfiniDB Community software is subject to the
terms and conditions of the Calpont Open Source License Agreement. Use of and
access to the Calpont InfiniDB Enterprise software is subject to the terms and
conditions of the Calpont End User License Agreement.

This program is distributed in the hope that it will be useful, and unless
otherwise noted on your license agreement, WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Please refer to the Calpont Open Source License Agreement and the Calpont End
User License Agreement for more details.

You should have received a copy of either the Calpont Open Source License
Agreement or the Calpont End User License Agreement along with this program; if
not, it is your responsibility to review the terms and conditions of the proper
Calpont license agreement by visiting http://www.calpont.com for the Calpont
InfiniDB Enterprise End User License Agreement or http://www.infinidb.org for
the Calpont InfiniDB Community Calpont Open Source License Agreement.

Calpont may make changes to these license agreements from time to time. When
these changes are made, Calpont will make a new copy of the Calpont End User
License Agreement available at http://www.calpont.com and a new copy of the
Calpont Open Source License Agreement available at http:///www.infinidb.org.
You understand and agree that if you use the Program after the date on which
the license agreement authorizing your use has changed, Calpont will treat your
use as acceptance of the updated License.

*/

/***********************************************************************
*   $Id: simplecolumn.h 7409 2011-02-08 14:38:50Z rdempsey $
*
*
***********************************************************************/
/** @file */

#ifndef SIMPLECOLUMN_H
#define SIMPLECOLUMN_H
#include <string>
#include <boost/shared_ptr.hpp>

#include "returnedcolumn.h"
#include "treenode.h"
#include "calpontsystemcatalog.h"
#include "dataconvert.h"

namespace messageqcpp {
class ByteStream;
}

/**
 * Namespace
 */
namespace execplan { 

class ParseTree;
/**
 * @brief A class to represent a simple returned column
 * 
 * This class is a specialization of class ReturnedColumn that handles
 * a column name.
 */
class SimpleColumn : public ReturnedColumn {

public:
 
	/**
	 * Constructors
	 */ 
	SimpleColumn();
	SimpleColumn(const std::string& token, const u_int32_t sessionID = 0);
	SimpleColumn(const std::string& schema, const std::string& table, const std::string& col, const u_int32_t sessionID = 0);
	SimpleColumn(const SimpleColumn& rhs, const u_int32_t sessionID = 0);
	
	/**
	 * Destructor
	 */
	virtual ~SimpleColumn();
	
	/**
	 * Accessor Methods
	 */
	inline const std::string& schemaName() const
	{
	    return fSchemaName;
	}
	
	inline void schemaName(const std::string& schemaName)
	{
	    fSchemaName = schemaName;
	}
	
	inline const std::string& tableName() const
	{
		return fTableName;
	}
	
	inline void tableName(const std::string& tableName)
	{
	    fTableName = tableName;
	}
	
	inline const std::string& columnName() const
	{
		return fColumnName;
	}
	
	inline void columnName(const std::string& columnName)
	{
	    fColumnName = columnName;
	}
	
	inline const CalpontSystemCatalog::OID& oid() const
	{
	    return fOid;
	}
	
	inline void oid (const CalpontSystemCatalog::OID& oid)
	{
	    fOid = oid;
	}
	
	virtual const std::string data() const;
	virtual void data(const std::string data) { fData = data; }
	
	inline const std::string& tableAlias() const { return fTableAlias; }
	inline void tableAlias(const std::string& tableAlias) { fTableAlias = tableAlias; }
	inline const std::string& indexName() const {return fIndexName;}
	inline void indexName(const std::string& indexName) {fIndexName = indexName;}
	inline const std::string& viewName() const {return fViewName;}
	inline void viewName(const std::string& viewName) {fViewName = viewName;}
	
  /** return a copy of this pointer
	 *
	 * deep copy of this pointer and return the copy
	 */	
	inline virtual SimpleColumn* clone() const
	{
	    return new SimpleColumn (*this);
	}	
	/**
	 * Overloaded assignment operator
	 */
	SimpleColumn& operator=(const SimpleColumn& rhs);
	
	/**
	 * The serialize interface
	 */
	virtual void serialize(messageqcpp::ByteStream&) const;
	virtual void unserialize(messageqcpp::ByteStream&);

	virtual const std::string toString() const;
	
	/** @brief Do a deep, strict (as opposed to semantic) equivalence test
	 *
	 * Do a deep, strict (as opposed to semantic) equivalence test.
	 * @return true iff every member of t is a duplicate copy of every member of this; false otherwise
	 */
	virtual bool operator==(const TreeNode* t) const;
	
	/** @brief Do a deep, strict (as opposed to semantic) equivalence test
	 *
	 * Do a deep, strict (as opposed to semantic) equivalence test.
	 * @return true iff every member of t is a duplicate copy of every member of this; false otherwise
	 */
	bool operator==(const SimpleColumn& t) const;
	
	/** @brief Do a deep, strict (as opposed to semantic) equivalence test
	 *
	 * Do a deep, strict (as opposed to semantic) equivalence test.
	 * @return false iff every member of t is a duplicate copy of every member of this; true otherwise
	 */
	virtual bool operator!=(const TreeNode* t) const;
	 
	/** @brief Do a deep, strict (as opposed to semantic) equivalence test
	 *
	 * Do a deep, strict (as opposed to semantic) equivalence test.
	 * @return false iff every member of t is a duplicate copy of every member of this; true otherwise
	 */
	bool operator!=(const SimpleColumn& t) const;
	
  /** @brief check if this column is the same as the argument */
	virtual bool sameColumn(const ReturnedColumn* rc) const;

private:
	/**
	 * Fields
	 */
	std::string fSchemaName;           /// schema name
	std::string fTableName;	        /// table name
	std::string fColumnName;	        /// column name
	CalpontSystemCatalog::OID fOid;    /// column TCN number
	std::string fTableAlias;           /// table alias
	std::string fData;	
	/// index name. for oracle use. deprecated
	std::string fIndexName;   
	// if belong to view, view name is non-empty
	std::string fViewName;

	/** @brief parse SimpleColumn text
	 *  
	 * parse the incomming sql text to construct a SimpleColumn object.
	 * used by the constructor.
	 */
	void parse(const std::string& sql);
	
	/** @brief get tcn for this column */
	void setOID();

	/***********************************************************
	 *                  F&E framework                          *
	 ***********************************************************/
public:
	virtual void evaluate(rowgroup::Row& row, bool& isNull);	
	virtual bool getBoolVal(rowgroup::Row& row, bool& isNull)
	{
		evaluate(row, isNull);
		return TreeNode::getBoolVal();
	}
	virtual std::string getStrVal(rowgroup::Row& row, bool& isNull) 
	{ 
		evaluate(row, isNull);
		return TreeNode::getStrVal(); 
	}
	
	virtual int64_t getIntVal(rowgroup::Row& row, bool& isNull) 
	{ 
		evaluate(row, isNull);
		return TreeNode::getIntVal(); 
	}
	
	virtual float getFloatVal(rowgroup::Row& row, bool& isNull)
	{
		evaluate(row, isNull);
		return TreeNode::getFloatVal();
	}
	
	virtual double getDoubleVal(rowgroup::Row& row, bool& isNull) 
	{
		evaluate(row, isNull);
		return TreeNode::getDoubleVal(); 
	}
	
	virtual IDB_Decimal getDecimalVal(rowgroup::Row& row, bool& isNull)
	{
		evaluate(row, isNull);
		return TreeNode::getDecimalVal();
	}
	
	inline int32_t getDateIntVal(rowgroup::Row& row, bool& isNull)
	{
		evaluate(row, isNull);
		return TreeNode::getDateIntVal();
	}
	
  inline int64_t getDatetimeIntVal(rowgroup::Row& row, bool& isNull)
  {
  	evaluate(row, isNull);
  	return TreeNode::getDatetimeIntVal();
  }
				
};

typedef boost::shared_ptr<SimpleColumn> SSC;

/**
 * ostream operator
 */
std::ostream& operator<<(std::ostream& output, const SimpleColumn& rhs);

/**
 * utility function to extract all simple columns from a parse tree
 */
void getSimpleCols(ParseTree* n, void* obj);

}
#endif //SIMPLECOLUMN_H

