
#define DONT_USE_NLIST 1

#undef bsdlike
