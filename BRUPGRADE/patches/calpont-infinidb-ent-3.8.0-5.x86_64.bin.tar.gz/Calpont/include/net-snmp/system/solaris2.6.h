#include "solaris.h"
#define _SLASH_PROC_METHOD_ 1
