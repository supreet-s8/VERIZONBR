#ifndef EXISTSJOINLIKEFILTER_H
#define EXISTSJOINLIKEFILTER_H
#include <string>
#include <vector>
#include "filter.h"
#include "calpontselectexecutionplan.h"

using namespace std;

namespace execplan { 

class ExistsJoinLikeFilter : public Filter {

public:
	ExistsJoinLikeFilter();
	ExistsJoinLikeFilter(const SCSEP& sub, const bool existsFlag = false, const bool correlated = false);
	ExistsJoinLikeFilter(const ExistsJoinLikeFilter& rhs);
	virtual ~ExistsJoinLikeFilter();
	
	const SCSEP& sub() const { return fSub; }	
	void sub (SCSEP& sub) { fSub = sub; }
	
	const bool notExists() const { return fNotExists; }
	void notExists (const bool notExists) { fNotExists = notExists; }		
	
	const bool correlated() const { return fCorrelated; }
	void correlated(const bool correlated) { fCorrelated = correlated; }
	   
	virtual const std::string toString() const;
	
	virtual void serialize(messageqcpp::ByteStream&) const;
	virtual void unserialize(messageqcpp::ByteStream&);
	
	inline virtual ExistsJoinLikeFilter* clone() const
	{
	    return new ExistsJoinLikeFilter (*this);
	}	
	
	virtual bool operator==(const TreeNode* t) const;
	
	bool operator==(const ExistsJoinLikeFilter& t) const;
	
	virtual bool operator!=(const TreeNode* t) const;
	 
	bool operator!=(const ExistsJoinLikeFilter& t) const;

    void AddRowsBuffer(uint8_t* buffer);

    std::vector< uint8_t* >* RowGroupList();

    void RowGroupList(std::vector< uint8_t* >* pRowGroupList);

    void SetRowSize(int rowSize);

private:
	 SCSEP fSub;
	 bool fNotExists; 
	 bool fCorrelated;
	 std::string fData;
     int  mRowSize;
     std::vector< uint8_t* > *mRowGroupList;

     boost::mutex fAddLock;
};

std::ostream& operator<<(std::ostream& output, const ExistsJoinLikeFilter& rhs);

} 
#endif //EXISTSJOINLIKEFILTER_H

