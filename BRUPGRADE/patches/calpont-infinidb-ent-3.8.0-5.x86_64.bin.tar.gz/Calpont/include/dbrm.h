/*

Copyright (C) 2009-2011 Calpont Corporation.

Use of and access to the Calpont InfiniDB Community software is subject to the
terms and conditions of the Calpont Open Source License Agreement. Use of and
access to the Calpont InfiniDB Enterprise software is subject to the terms and
conditions of the Calpont End User License Agreement.

This program is distributed in the hope that it will be useful, and unless
otherwise noted on your license agreement, WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Please refer to the Calpont Open Source License Agreement and the Calpont End
User License Agreement for more details.

You should have received a copy of either the Calpont Open Source License
Agreement or the Calpont End User License Agreement along with this program; if
not, it is your responsibility to review the terms and conditions of the proper
Calpont license agreement by visiting http://www.calpont.com for the Calpont
InfiniDB Enterprise End User License Agreement or http://www.infinidb.org for
the Calpont InfiniDB Community Calpont Open Source License Agreement.

Calpont may make changes to these license agreements from time to time. When
these changes are made, Calpont will make a new copy of the Calpont End User
License Agreement available at http://www.calpont.com and a new copy of the
Calpont Open Source License Agreement available at http:///www.infinidb.org.
You understand and agree that if you use the Program after the date on which
the license agreement authorizing your use has changed, Calpont will treat your
use as acceptance of the updated License.

*/

/******************************************************************************
 * $Id: dbrm.h 1580 2012-05-31 22:10:34Z chao $
 *
 *****************************************************************************/

/** @file 
 * class DBRM
 */

#ifndef DBRM_H_
#define DBRM_H_

#include <sys/types.h>
#include <vector>
#include <set>
#include <string>
#include <boost/thread.hpp>

#include "brmtypes.h"
#include "messagequeue.h"

#include "extentmap.h"
#include "vss.h"
#include "vbbm.h"
#include "copylocks.h"
#include "calpontsystemcatalog.h"
#include "sessionmanagerserver.h"
#include "configcpp.h"
#include "mastersegmenttable.h"

#if defined(_MSC_VER) && defined(DBRM_DLLEXPORT)
#define EXPORT __declspec(dllexport)
#else
#define EXPORT
#endif

#ifdef BRM_DEBUG
#define DBRM_THROW
#else
#define DBRM_THROW throw()
#endif

namespace BRM {

/** @brief The interface to the Distributed BRM system.
 *
 * There are 3 components of the Distributed BRM (DBRM).
 * \li The interface
 * \li The Master node
 * \li Slave nodes
 *
 * The DBRM class is the interface, which is identical to the single-node
 * version, the BlockResolutionManager class.
 *
 * The DBRM components effectively implement a networking & synchronization
 * layer to the BlockResolutionManager class so that every node that needs
 * BRM data always has an up-to-date copy of it locally.  An operation that changes
 * BRM data is duplicated on all hosts that run a Slave node so that every
 * node has identical copies.  All "read" operations are satisfied locally.
 *
 * Calpont configuration file entries are necessary for the interface, Master,
 * and Slave to find each other.  Config file entries look like
 * \code
 * <DBRM_Controller>
 *	<IPAddr>
 * 	<Port>
 *	<NumWorkers>N</NumWorkers>
 * </DBRM_Controller>
 * <DBRM_Worker1>
 *	<IPAddr>
 *	<Port>
 * </DBRM_Worker1>
 *	...
 * <DBRM_WorkerN>
 *	<IPAddr>
 *	<Port>
 * </DBRM_WorkerN>
 * \endcode
 */

class DBRM {
public:
	// The param noBRMFcns suppresses init of the ExtentMap, VSS, VBBM, and CopyLocks.
	// It can speed up init if the caller only needs the other structures.
	EXPORT DBRM(bool noBRMFcns = false) throw();
	EXPORT ~DBRM() throw();
	
	// @bug 1055+ - Added functions below for multiple files per OID enhancement.

	/** @brief Get the OID, offset, db root, partition, and segment of a logical block ID.
	 *
	 * Get the OID, offset, db root, and partition of a logical block ID.
	 * @param lbid (in) The LBID to look up
	 * @param verid (in) The version of the LBID to look up
	 * @param vbFlags (in) If true, look for the block in the version buffer
	 * if false, the extent map
	 * @param oid (out) The OID of the file the LBID is allocated to
	 * @param fileBlockOffset (out) The file block offset of the LBID
	 * @param dbRoot (out) The DBRoot number that contains the file.
	 * @param partitionNum (out) The partition number for the file.
	 * @param segmentNum (out) The segement number for the file.
	 * 
	 * @return 0 on success, non-0 on error (see brmtypes.h)
	 */
	
    EXPORT bool isDictionary(LBID_t lbid) throw();

    EXPORT bool isAnyActiveTransaction();
	
    EXPORT int lookupLocal(LBID_t lbid, VER_t verid, bool vbFlag, OID_t& oid,
		uint16_t& dbRoot, uint32_t& partitionNum, uint16_t& segmentNum, uint32_t& fileBlockOffset) throw();

	/** @brief Get the LBID assigned to the given OID, block offset, partion, and segment.
	 *
	 * Get the LBID assigned to the given OID, block offset, partition, and segment.
	 * @param oid (in) The OID
	 * @param partitionNum (in) The partition number
	 * @parm segmentNum (in) The segment number
	 * @param fileBlockOffset (in) The offset in the OID to return the LBID of
	 * @param lbid (out) The LBID of the offset of the OID.
	 * @return 0 on success, non-0 on error (see brmtypes.h)
	 */
	EXPORT int lookupLocal(OID_t oid, uint32_t partitionNum, uint16_t segmentNum, uint32_t fileBlockOffset, LBID_t& lbid) throw();

	// @bug 1055-	

	/** @brief Get the starting LBID assigned to the extent containing
 *  the specified OID, block offset, partition, and segment.
	 *
	 * Get the LBID assigned to the given OID, partition, segment,
 * and block offset.
	 * @param oid (in) The OID
	 * @param partitionNum (in) The partition number
	 * @parm segmentNum (in) The segment number
	 * @param fileBlockOffset (in) The requested offset in the specified OID
	 * @param lbid (out) The starting LBID of extent with specified offset
	 * @return 0 on success, non-0 on error (see brmtypes.h)
	 */
	EXPORT int lookupLocalStartLbid(OID_t oid,
			 uint32_t partitionNum,
			 uint16_t segmentNum,
			 uint32_t fileBlockOffset,
			 LBID_t& lbid) throw();

	/**@brief Do a VSS lookup.
	 *
	 * Do a VSS lookup.  Gets the version ID of the block the caller should use
	 * and determines whether it is in the version buffer or the main database.
	 * @param lbid (in) The block number
	 * @param verID (in/out) The input value is the version requested, 
	 * the output value is the value the caller should use.
	 * @param txnID (in) If the caller has a transaction ID, put it here.  
	 * Otherwise use 0.
	 * @param vbFlag (out) If true, the block is in the version buffer; 
	 * false, the block is in the main database.
	 * @param vbOnly (in) If true, it will only consider entries in the Version Buffer
	 * (vbFlag will be true on return).  If false, it will also consider the main DB
	 * entries.  This defaults to false.
	 * @return 0 on success, non-0 on error (see brmtypes.h)
	 */
	EXPORT int vssLookup(LBID_t lbid, VER_t& verID, VER_t txnID, bool& vbFlag, 
				  bool vbOnly = false) throw();

	/** @brief Do many VSS lookups under one lock
	 *
	 * Do many VSS lookups under one lock.
	 * @param lbids (in) The LBIDs to look up
	 * @param verID (in) The input version number, equivalent to the verID param in vssLookup()
	 * @param txnID (in) The input transaction number, equivalent to the txnID param in vssLookup()
	 * @param out (out) The values equivalent to the out parameters in vssLookup() including the individual return codes, ordered as the lbid list.
	 * @return 0 on success, -1 on a fatal error.
	 */
	EXPORT int bulkVSSLookup(const std::vector<LBID_t> &lbids, VER_t verID, VER_t txnID,
		std::vector<VSSData> *out) throw();
	
	/** @brief Get a complete list of LBIDs assigned to an OID
	 *
	 * Get a complete list of LBIDs assigned to an OID.
	 */
	EXPORT int lookup(OID_t oid, LBIDRange_v& lbidList) throw();

	/** @brief Allocate an extent for a column file
	 *
	 * Allocate a column extent for the specified OID.
	 * @param OID (in) The OID requesting the extent.
	 * @param colWidth (in) Column width of the OID.
	 * @param dbRoot (in/out) If allocating OID's first extent, then
	 *        dbRoot is an input arg, else it is an output arg.
	 * @param partitionNum (in/out) Partition number in file path.
 *        If allocating OID's first extent, then
 *        partitionNum is input, else it is an output arg.
	 * @param segmentNum (out) Segment number assigned to the extent.
	 * @param lbid (out) The first LBID of the extent created.
	 * @param allocdSize (out) The total number of LBIDs allocated.
	 * @param startBlockOffset (out) The first block of the extent created.
	 * @return 0 on success, -1 on error
	 */
	 EXPORT int createColumnExtent(OID_t oid,
					u_int32_t  colWidth,
					u_int16_t& dbRoot,
					u_int32_t& partitionNum,
					u_int16_t& segmentNum,
					LBID_t&    lbid,
					int&       allocdSize,
					u_int32_t& startBlockOffset) DBRM_THROW;

	/** @brief Allocate an extent for a dictionary store file
	 *
	 * Allocate a dictionary store extent for the specified OID, dbRoot,
	 * partition number, and segment number.
	 * @param OID (in) The OID requesting the extent.
	 * @param dbRoot (in) DBRoot to assign to the extent.
	 * @param partitionNum (in) Partition number to assign to the extent.
	 * @param segmentNum (in) Segment number to assign to the extent.
	 * @param lbid (out) The first LBID of the extent created.
	 * @param allocdSize (out) The total number of LBIDs allocated.
	 * @return 0 on success, -1 on error
	 */
	 EXPORT int createDictStoreExtent(OID_t oid,
					 u_int16_t  dbRoot,
					 u_int32_t  partitionNum,
					 u_int16_t  segmentNum,
					 LBID_t&    lbid,
					 int&       allocdSize) DBRM_THROW;

	/** @brief Rollback (delete) a set of column extents for specified OID.
	 *
	 * Deletes all the extents that logically follow the specified
 * column extent; and sets the HWM for the specified extent.
	 * @param oid OID of the extents to be deleted.
	 * @param partitionNum Last partition to be kept.
	 * @param segmentNum Last segment in partitionNum to be kept.
	 * @param hwm HWM to be assigned to the last extent that is kept.
	 * @return 0 on success
	 */
	EXPORT int rollbackColumnExtents(OID_t oid,
					 u_int32_t partitionNum,
					 u_int16_t segmentNum,
					 HWM_t     hwm) DBRM_THROW;

	/** @brief Rollback (delete) a set of dict store extents for an OID.
	 *
	 * Arguments specify the last stripe.  Any extents after this are
	 * deleted.  The hwm's of the extents in the last stripe are updated
	 * based on the contents of the hwm vector.  If hwms is a partial list,
	 * (as in the first stripe of a partition), then any extents in sub-
	 * sequent segment files for that partition are deleted.
	 * @param oid OID of the extents to be deleted or updated.
	 * @param partitionNum Last partition to be kept.
	 * @param hwms Vector of hwms for the last partition to be kept.
	 * @return 0 on success
	 */
	EXPORT int rollbackDictStoreExtents(OID_t oid,
					 u_int32_t partitionNum,
					 const std::vector<HWM_t>& hwms) DBRM_THROW;
					 
	/** @brief delete of column extents for the specified extents.
	 *
	 * Deletes the extents from extent map 
	 * @param extentInfo the information for extents
	 */
	EXPORT int deleteEmptyColExtents(const std::vector<ExtentInfo>& extentsInfo) DBRM_THROW;
	
	/** @brief delete of dictionary extents for the specified extents.
	 *
	 * Deletes the extents from extent map 
	 * @param extentInfo the information for extents
	 */
	EXPORT int deleteEmptyDictStoreExtents(const std::vector<ExtentInfo>& extentsInfo) DBRM_THROW;
	
	/** @brief Delete the extents of an OID and invalidate VSS references to them
	 *
	 * Delete the extents assigned to an OID and deletes entries in the VSS
	 * that refer to the LBIDs used by it.
	 * @note The old version of this function deliberately did not delete the entries
	 * in the version buffer.
	 * @note This function is ridiculously slow right now.
	 * @param OID The OID of the object being deleted
	 * @return 0 on success, non-0 on error (see brmtypes.h)
	 */
	EXPORT int deleteOID(OID_t oid) DBRM_THROW;


	/** @brief Delete the extents of an OID and invalidate VSS references to them
	 *
	 * Delete the extents assigned to an OID and deletes entries in the VSS
	 * that refer to the LBIDs used by it.
	 * @note The old version of this function deliberately did not delete the entries
	 * in the version buffer.
	 * @note This function is ridiculously slow right now.
	 * @param OID The OID of the object being deleted
	 * @return 0 on success, non-0 on error (see brmtypes.h)
	 */
	EXPORT int deleteOIDs( const std::vector<OID_t>& oids) DBRM_THROW;
	
	/** @brief Get the "high water mark" of an OID
	 * 
	 * Get the absolute high water mark (aka, the highest numbered written
	 * block offset) of an OID.  This only applies to column OIDs.
	 * @param oid (in) The OID
	 * @param hwm (out) The high water mark of oid
	 * @return 0 on success, non-0 on error (see brmtypes.h)
	 */
	EXPORT int getHWM(OID_t oid, HWM_t& hwm) throw();

	/** @brief Get the last local "high water mark" of an OID
	 * 
	 * Get local high water mark (aka, the highest numbered written block
	 * offset) for an OID, relative to a segment file.  The DBRoot, parti-
	 * tion, and segment numbers for the pertinent segment file are also re-
	 * turned.  This function could be called to get the last local HWM for
	 * a dictionary store OID, but it's intended use is for column OIDs.
	 * @param oid (in) The OID
	 * @param dbRoot (out) Relevant DBRoot.
	 * @param partitionNum (out) Relevant partition number.
	 * @param segmentNum (out) Relevant segment number.
	 * @param hwm (out) The last local high water mark of oid
	 * @return 0 on success, non-0 on error (see brmtypes.h)
	 */
	EXPORT int getLastLocalHWM(OID_t oid, uint16_t& dbRoot, uint32_t& partitionNum,
	       uint16_t& segmentNum, HWM_t& hwm) throw();

	/** @brief Get the "high water mark" of an OID, partition, and segment
	 * 
	 * Get local high water mark (aka, the highest numbered written block
	 * offset) for an OID,partition,segment relative to the segment file.
	 * This applies to either column or dictionary store OIDs.
	 * @param oid (in) The OID
	 * @param partitionNum (in) Relevant partition number.
	 * @param segmentNum (in) Relevant segment number.
	 * @param hwm (out) The high water mark of oid
	 * @return 0 on success, non-0 on error (see brmtypes.h)
	 */
	EXPORT int getLocalHWM(OID_t oid, uint32_t partitionNum,
	       uint16_t segmentNum, HWM_t& hwm) throw();
	
	/** @brief Set the "high water mark" of an OID, partition, and segment
	 * 
	 * Set the local high water mark (aka, the highest numbered written
	 * block offset) for the segment file referenced by the specified OID,
	 * partition, and segment number.
	 * This applies to either column or dictionary store OIDs.
	 * @param oid (in) The OID
	 * @param partitionNum (in) Relevant partition number.
	 * @param segmentNum (in) Relevant segment number.
	 * @param hwm (in) The high water mark of oid
	 * @return 0 on success, non-0 on error (see brmtypes.h)
	 */
	EXPORT int setLocalHWM(OID_t oid, uint32_t partitionNum,
	       uint16_t segmentNum, HWM_t hwm) DBRM_THROW;

	/** @brief Does setLocalHWM, casual partitioning changes, & commit.  The HWM &
	 * CP changes are atomic with this fcn.  All functionality is optional.  Passing
	 * in an empty vector for any of these parms makes it do nothing for the
	 * corresponding operation.
	 *
	 * It returns 0 if all operations succeed, -1 if any operation fails.
	 * The controllernode will undo all changes made on error.
	 */
	EXPORT int bulkSetHWMAndCP(const std::vector<BulkSetHWMArg> & hwmArgs,
			const std::vector<CPInfo> & setCPDataArgs,
			const std::vector<CPInfoMerge> & mergeCPDataArgs,
			VER_t transID) DBRM_THROW;

	/** @brief Gets the extents of a given OID
	 *
	 * Gets the extents of a given OID.
	 * @param OID (in) The OID to get the extents for.
	 * @param entries (out) A snapshot of the OID's Extent Map entries
	 * sorted by starting LBID; note that The Real Entries can change at 
	 * any time.  Also, internally the size of an extent is measured in
	 * multiples of 1024 LBIDs.  So, if the size field is 10, it represents
	 * 10240 LBIDs.
	 * @param sorted (in) indicates if output is to be sorted
	 * @param notFoundErr (in) indicates if no extents is considered an err
	 * @param incOutOfService (in) include/exclude out of service extents
	 * @return 0 on success, non-0 on error (see brmtypes.h)
	 */
	EXPORT int getExtents(int OID, std::vector<struct EMEntry>& entries,
		bool sorted=true, bool notFoundErr=true,
		bool incOutOfService=false) throw();

	/** @brief Gets the number of rows in an extent
	 * 
	 * Gets the number of rows in an extent.
	 * @return The extent size
	 */
// dmc-getExtentSize() to be deprecated, replaced by getExtentRows()
	EXPORT int getExtentSize() throw();
	EXPORT unsigned getExtentRows() throw();

/** @brief Gets DBRoot and Partition number for oid's first segment file
 *
 * @param OID (in) the OID of interest
 * @param dbRoot (out) the DBRoot where segment 0 files reside for oid
 * @param partitionNum (out) the starting partition number
	 * @param incOutOfService (in) include/exclude out of service extents
	 * in the search
 * @return 0 on succcess, non-0 on error
 */
EXPORT int getStartExtent(OID_t oid, uint16_t& dbRoot,
		   uint32_t& partitionNum,
		   bool incOutOfService=false) throw();
	
	/** @brief Delete a Partition for the specified OID(s).
	 *
	 * @param OID (in) the OID of interest.
	 * @param partitionNum (in) the partition to be deleted.
	 */
	EXPORT int deletePartition(const std::vector<OID_t>& oids,
						uint32_t partitionNum) DBRM_THROW;

	/** @brief Mark a Partition for the specified OID(s) as out of service.
	 *
	 * @param OID (in) the OID of interest.
	 * @param partitionNum (in) the partition to be marked out of service.
	 */
	EXPORT int markPartitionForDeletion(const std::vector<OID_t>& oids,
						uint32_t partitionNum) DBRM_THROW;
					
	/** @brief Mark all Partition for the specified OID(s) as out of service.
	 *
	 * @param OID (in) the OID of interest.
	 */
	EXPORT int markAllPartitionForDeletion(const std::vector<OID_t>& oids) DBRM_THROW;


	/** @brief Restore a Partition for the specified OID(s).
	 *
	 * @param OID (in) the OID of interest.
	 * @param partitionNum (in) the partition to be restored.
	 */
	EXPORT int restorePartition(const std::vector<OID_t>& oids,
						uint32_t partitionNum) DBRM_THROW;

	/** @brief Get the list of out-of-service partitions for a given OID
	 *
	 * @param OID (in) the OID of interest.
	 * @param partitionNums (out) the out-of-service partitions for the oid.
	 * partitionNums will be in sorted order.
	 */
	EXPORT int getOutOfServicePartitions(OID_t oid,
						std::vector<uint32_t>& partitionNums) throw();

	/** @brief Registers a version buffer entry.
	 *
	 * Registers a version buffer entry at <vbOID, vbFBO> with
	 * values of <transID, lbid>.
	 * @note The version buffer locations must hold the 'copy' lock
	 * first.
	 * @return 0 on success, non-0 on error (see brmtypes.h)
	 */
	EXPORT int writeVBEntry(VER_t transID, LBID_t lbid, OID_t vbOID, 
					 u_int32_t vbFBO) DBRM_THROW;
	
	/** @brief Retrieves a list of uncommitted LBIDs.
	 * 
	 * Retrieves a list of uncommitted LBIDs for the given transaction ID.
	 * @param lbidList (out) On success this contains the ranges of LBIDs
	 * @return 0 on success, non-0 on error (see brmtypes.h)
	 */
	EXPORT int getUncommittedLBIDs(VER_t transID, 
							std::vector<LBID_t>& lbidList)
			throw();

	// @bug 1509.  Added getUncommittedExtentLBIDs function. 
	/** @brief Retrieves a list of uncommitted extent LBIDs.
	 *
	 * Retrieves a list of uncommitted LBIDs for the given transaction ID.
	 * This function differs from getUncommittedLBIDs in that only one LBID per
	 * extent is returned.  It is used to return a list that can be used to update
	 * casual partitioning information which is tracked at the extent level rather
	 * than the block level.
	 * @param lbidList (out) On success this contains the ranges of LBIDs
	 * @return 0 on success, non-0 on error (see brmtypes.h)
	 */
	EXPORT int getUncommittedExtentLBIDs(VER_t transID, std::vector<LBID_t>& lbidList) throw();
	
	/** @brief Atomically prepare to copy data to the version buffer
	 * 
	 * Atomically sets the copy flag on the specified LBID ranges
	 * and allocate blocks in the version buffer to copy them to.
	 * If any LBID in the range cannot be locked, none will be
	 * and this will return -1.
	 * @param transID The transaction ID doing the operation
	 * @param ranges (in) A list of LBID ranges that will be copied
	 * @param freeList (out) On success, a list of ranges of the version
	 * buffer blocks to copy the LBID range to.
	 * @note The caller must do a rollback or commit immediately after getting ERR_DEADLOCK (6).
	 * @return 0 on success, non-0 on error (see brmtypes.h)
	 */
	EXPORT int beginVBCopy(VER_t transID, const LBIDRange_v& ranges, 
				  VBRange_v& freeList) DBRM_THROW;
	
	/** @brief Atomically unset the copy lock & update the VSS.  Beware!  Read the warning!
	 * 
	 * Atomically unset the copy lock for the specified LBID ranges
	 * and add a new locked VSS entry for each LBID in the range.
	 * @note The elements of the ranges parameter <b>MUST</b> be the
	 * same elements passed to beginVBCopy().  The number and order of the
	 * elements can be different, but every element in ranges must also
	 * have been an element in beginVBCopy's ranges.
	 * @return 0 on success, non-0 on error (see brmtypes.h)
	 */
	EXPORT int endVBCopy(VER_t transID, const LBIDRange_v& ranges) 
			DBRM_THROW;
	
	/** @brief Commit the changes made for the given transaction.
	 *
	 * This unlocks the VSS entries with VerID = transID.
	 * @return 0 on success, non-0 on error (see brmtypes.h)
	 */
	EXPORT int vbCommit(VER_t transID) DBRM_THROW;
	
	/** @brief Reverse the changes made during the given transaction.
	 *
	 * Record that the given LBID was reverted to version verID.
	 * @warning This removes the copy locks held on all ranges by transID.
	 * @param transID The transaction ID
	 * @param lbidList The list of ranges to rollback.
	 * @return 0 on success, non-0 on error (see brmtypes.h)
	 */
	EXPORT int vbRollback(VER_t transID, const LBIDRange_v& lbidList) 
			DBRM_THROW;

	/** @brief Reverse the changes made during the given transaction.
	 *
	 * Record that the given LBID was reverted to version verID.
	 * @warning This removes the copy locks held on all ranges by transID.
	 * @param transID The transaction ID
	 * @param lbidList The list of singular LBIDs to rollback.
	 * @return 0 on success, non-0 on error (see brmtypes.h)
	 */
	EXPORT int vbRollback(VER_t transID, const std::vector<LBID_t>& lbidList) 
			DBRM_THROW;


	EXPORT int getUnlockedLBIDs(BlockList_t *list) DBRM_THROW;

	/** @brief Flushes the inode caches of slave nodes.
	 * 
	 * We use the DBRM as a generic RPC mechanism here.  This entry point
	 * causes the inode caches on the slave nodes to be flushed, at least
	 * on FC4 systems.  Other RH variants might not support this.
	 * @return Non-0 on a network error, 0 otherwise.  If there is no 
	 * network error the operation always "succeeds" even if it fails,
	 * for example, because one of the nodes doesn't support it.
	 */
	EXPORT int flushInodeCaches() DBRM_THROW;

	/** @brief Reinitialize the versioning data structures.
	 * 
	 * This entry point empties the VSS and VBBM structures on the
	 * slave nodes.  At system startup and after recovery, the data left in
	 * the VSS and VBBM are unnecessary.  The primary purpose of this function
	 * is to free up memory.
	 * @return 0 on success, non-0 on error (see brmtypes.h).
	 */
	EXPORT int clear() DBRM_THROW;

	/** @brief Check the consistency of each data structure
	 *
	 * Check the consistency of each data structure
	 * @return 0 on success, non-0 on error (see brmtypes.h)
	 */
	EXPORT int checkConsistency() throw();

	/** @brief Get a list of the transactions currently in progress.
	 * 
	 * Get a list of the transactions currently in progress.  This scans
	 * the copy locks & VSS for LBIDs that are locked by some transaction
	 * and stores the transaction ID.
	 * 
	 * @param txnList Caller-supplied set to store the results in.
	 * @return 0 on success, non-0 on error (see brmtypes.h)
	 */
	EXPORT int getCurrentTxnIDs(std::set<VER_t> &txnList) throw();

	/** @brief Persistence API.  Saves the local Extent Map to a file.
	 * 
	 * Persistence API.  Saves the <b>local</b> Extent Map to a file.
	 *
	 * @param filename Relative or absolute path to save to.
	 * @return 0 on success, -1 on error
	 */
	EXPORT int saveExtentMap(const std::string& filename) throw();

	/** @brief Persistence API.  Saves all BRM structures.
	 *
	 * Saves all <b>local</b> BRM structures to files.
	 *
	 * @param filename The filename prefix to use.  Saves 4 files with that prefix.
	 * @return 0 on success, -1 on error
	 */
	EXPORT int saveState(std::string filename) throw();

	/** @brief Persistence API.  Saves all BRM structures using the filenames from Calpont.xml.
	 *
	 * Saves all <b>local</b> BRM structures to files.
	 *
	 * @param filename The filename prefix to use.  Saves 4 files with that prefix.
	 * @return 0 on success, -1 on error
	 */
	EXPORT int saveState() throw();
	
	/** @brief A function that forces the BRM to write a snapshot of its data structures to disk
	 * 
	 * A function that forces the BRM to write a snapshot of its data structures to disk.
	 * This happens automatically after commits and rollbacks.  Bulk imports should call
	 * this fcn after an import.
	 * 
	 * @return 0 on success, non-0 on error (see brmtypes.h).
	 */
	EXPORT int takeSnapshot() throw();

	/* SessionManager interface */
	EXPORT const execplan::CalpontSystemCatalog::SCN verID(void);
	EXPORT const execplan::CalpontSystemCatalog::SCN sysCatVerID(void);
	EXPORT const TxnID 
		newTxnID(const SessionManagerServer::SID session, bool block, bool isDDL = false);
	EXPORT void committed(BRM::TxnID& txnid);
	EXPORT void rolledback(BRM::TxnID& txnid);
	EXPORT const BRM::TxnID getTxnID
		(const SessionManagerServer::SID session);
	EXPORT const BRM::SIDTIDEntry* SIDTIDMap(int& len);
	EXPORT char *getShmContents(int &len);
	EXPORT const uint32_t getUnique32();
	/** @brief set a table to lock/unlock state
	 * 
	 * set the table to lock/unlock state depending on lock request. error code will be returned.
	 */
	EXPORT int8_t setTableLock (  const OID_t tableOID, const u_int32_t sessionID,  const u_int32_t processID, const std::string processName, bool lock ) ;
	/** @brief set a table to lock/unlock state
	 * 
	 * set the table to lock/unlock state depending on lock request. error code will be returned.
	 */
	EXPORT int8_t updateTableLock (  const OID_t tableOID, u_int32_t & processID, std::string & processName ) ;
	/** @brief get table lock information
	 * 
	 * if the table is locked, the processID, processName will be valid. error code will be returned.
	 */
	EXPORT int8_t getTableLockInfo ( const OID_t tableOID, u_int32_t & processID,
		std::string & processName, bool & lockStatus, SessionManagerServer::SID & sid );
	
	EXPORT void getTableLocksInfo ( std::vector< BRM::SIDTIDEntry> & sidTidEntries);


	/** Casual paritioning support **/
	EXPORT int markExtentInvalid(const LBID_t lbid) DBRM_THROW;
	EXPORT int markExtentsInvalid(const std::vector<LBID_t> &lbids) DBRM_THROW;
	EXPORT int getExtentMaxMin(const LBID_t lbid, int64_t& max, int64_t& min, int32_t& seqNum) throw();

	EXPORT int setExtentMaxMin(const LBID_t lbid, const int64_t max, const int64_t min, const int32_t seqNum) DBRM_THROW;

	/** @brief Updates the max and min casual partitioning info for the passed extents.
	 *
	 * @bug 1970.
	 *
	 * @param cpInfos vector of CPInfo objects.  The firstLbid must be the first LBID in the extent.
	 * @return 0 on success, -1 on error
	 */
	EXPORT int setExtentsMaxMin(const CPInfoList_t &cpInfos) DBRM_THROW;

	/** @brief Merges max/min casual partitioning info for the specified
	 *  extents, with the current CP info.
	 *
	 * @param cpInfos vector of CPInfo objects.  The Lbids must be the
	 * starting LBID in the relevant extent.
	 * @return 0 on success, -1 on error
	 */
	EXPORT int mergeExtentsMaxMin(const CPInfoMergeList_t &cpInfos) DBRM_THROW;

    /* read-side interface for locking LBID ranges (used by PrimProc) */
	EXPORT void lockLBIDRange(LBID_t start, uint count);
	EXPORT void releaseLBIDRange(LBID_t start, uint count);

    /* write-side interface for locking LBID ranges (used by DML) */
    EXPORT int dmlLockLBIDRanges(const std::vector<LBIDRange> &ranges, int txnID);
    EXPORT int dmlReleaseLBIDRanges(const std::vector<LBIDRange> &ranges);

	/* OAM Interface */
	EXPORT int halt() DBRM_THROW;
	EXPORT int resume() DBRM_THROW;
	EXPORT int mayberesume() DBRM_THROW;
	EXPORT int forceReload() DBRM_THROW;
	EXPORT int setReadOnly(bool b) DBRM_THROW;
	EXPORT int isReadWrite() throw();

	EXPORT bool isEMEmpty() throw();

	EXPORT std::vector<InlineLBIDRange> getEMFreeListEntries() throw();

	/** @brief Check if the system is ready for updates
	 *
	 * Check is the system has completed rollback processing and is therefor ready for updates
	 */
	EXPORT bool isSystemReady() throw();

	/** @brief Mark the system as ready for updates
	 *
	 * The system has completed rollback processing and is therefor ready for updates
	 */
	EXPORT void systemIsReady(SessionManagerServer::SystemState state) throw();

    EXPORT void dumpVBBM();

	EXPORT int getStartLbidAndDbroot(OID_t oid, LBID_t lbid, uint32_t& partitionNum, uint16_t& segmentNum, 
                                     uint32_t& fileBlockOffset, LBID_t& startLbid, uint16_t& startDbRoot,
                                     bool incOutOfService=false) throw();
    
    /** @brief Check the extent map and freelist for any LBID's overlaps/holes
	 *
	 * Check 
	 * 1) if the LBIDs for any OID overlaps with the LBIDs of any other OID in the extent map
	 * 2) if the LBIDs in a freelist entry overlaps with the LBIDs in any other freelist entry
	 * 3) if the LBIDs for any OID overlaps with any other freelist entry
	 * 4) if there are any holes in the LBIDs range in the extent map and freelist
	 * 5) entire LBIDs range is covered
	 *
	 * @return true if an overlap/hole exists, returns false otherwise
	 */
	EXPORT bool checkLbidConsistency() throw();




private:
	DBRM(const DBRM& brm);
	DBRM& operator=(const DBRM& brm);
	int8_t send_recv(const messageqcpp::ByteStream& in, 
		messageqcpp::ByteStream& out) throw();

	boost::scoped_ptr<MasterSegmentTable> mst;
	boost::scoped_ptr<ExtentMap> em;
	boost::scoped_ptr<VBBM> vbbm;
	boost::scoped_ptr<VSS> vss;
	boost::scoped_ptr<CopyLocks> copylocks;
	messageqcpp::MessageQueueClient *msgClient;
	std::string masterName;
	boost::mutex mutex;
	config::Config *config;
	bool fDebug;
};

}

#undef EXPORT

#endif 
