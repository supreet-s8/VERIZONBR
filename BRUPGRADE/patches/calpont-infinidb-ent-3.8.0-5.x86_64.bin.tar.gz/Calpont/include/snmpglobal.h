/*

Copyright (C) 2009-2011 Calpont Corporation.

Use of and access to the Calpont InfiniDB Community software is subject to the
terms and conditions of the Calpont Open Source License Agreement. Use of and
access to the Calpont InfiniDB Enterprise software is subject to the terms and
conditions of the Calpont End User License Agreement.

This program is distributed in the hope that it will be useful, and unless
otherwise noted on your license agreement, WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Please refer to the Calpont Open Source License Agreement and the Calpont End
User License Agreement for more details.

You should have received a copy of either the Calpont Open Source License
Agreement or the Calpont End User License Agreement along with this program; if
not, it is your responsibility to review the terms and conditions of the proper
Calpont license agreement by visiting http://www.calpont.com for the Calpont
InfiniDB Enterprise End User License Agreement or http://www.infinidb.org for
the Calpont InfiniDB Community Calpont Open Source License Agreement.

Calpont may make changes to these license agreements from time to time. When
these changes are made, Calpont will make a new copy of the Calpont End User
License Agreement available at http://www.calpont.com and a new copy of the
Calpont Open Source License Agreement available at http:///www.infinidb.org.
You understand and agree that if you use the Program after the date on which
the license agreement authorizing your use has changed, Calpont will treat your
use as acceptance of the updated License.

*/

#ifndef SNMPGLOBAL_H
#define SNMPGLOBAL_H

//Major hack to get oam and brm to play nice.
#ifdef OAM_BRM_LEAN_AND_MEAN
#include <string>
#include <cstddef>
typedef u_long oid;
#else
#ifdef __linux__
#include <sys/file.h>
#include <linux/unistd.h>
#endif
#include <string>
#include <stdint.h>

#ifndef SKIP_SNMP
#include "net-snmp/net-snmp-config.h"
#include "net-snmp/net-snmp-includes.h"
#include "net-snmp/agent/net-snmp-agent-includes.h"
#else
typedef u_long oid;
#endif
#endif

namespace snmpmanager {

/** @brief oid type
 *1, 3, 6, 1, 4, 1, 2021, 991 
 */
typedef oid CALPONT_OID;

/** @brief constant define
 *
 */
const int SET = 1;
const int CLEAR = 0;

const std::string ACTIVE_ALARM_FILE = "/var/log/Calpont/activeAlarms";
const std::string ALARM_FILE = "/var/log/Calpont/alarm.log";
const std::string ALARM_ARCHIVE_FILE = "/var/log/Calpont/archive";

const CALPONT_OID SNMPTRAP_OID [] = { 1, 3, 6, 1, 6, 3, 1, 1, 4, 1, 0 };
const CALPONT_OID CALPONT_TRAP_OID [] = { 1, 3, 6, 1, 4, 1, 2021, 991 };
const CALPONT_OID CALALARM_DATA_OID [] =  { 1, 3, 6, 1, 4, 1, 2021, 991, 17 };
const CALPONT_OID COMPONENT_ID_OID [] = { 1, 3, 6, 1, 4, 1, 2021, 991, 18 };
const CALPONT_OID ALARM_ID_OID [] = { 1, 3, 6, 1, 4, 1, 2021, 991, 19 };
const CALPONT_OID STATE_OID [] = { 1, 3, 6, 1, 4, 1, 2021, 991, 20 };
const CALPONT_OID SNAME_OID [] = { 1, 3, 6, 1, 4, 1, 2021, 991, 21 };
const CALPONT_OID PNAME_OID [] = { 1, 3, 6, 1, 4, 1, 2021, 991, 22 };
const CALPONT_OID PID_OID [] = { 1, 3, 6, 1, 4, 1, 2021, 991, 23 };
const CALPONT_OID TID_OID [] = { 1, 3, 6, 1, 4, 1, 2021, 991, 24 };
const bool DEBUG = false;
const uint16_t INVALID_ALARM_ID = 0;
}

#endif
