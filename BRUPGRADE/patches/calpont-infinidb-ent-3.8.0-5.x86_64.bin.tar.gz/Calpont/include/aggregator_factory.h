#ifndef AGGREGATORFACTORY_H
#define AGGREGATORFACTORY_H

#include "CubeDefinitionXMLManager.h"
#include "base_aggregator.h"
#include <boost/shared_ptr.hpp>

namespace InstaAggregation
{
	typedef boost::shared_ptr<BaseAggregator> AggregatorSharedPtr;
	class AggregatorFactory
	{
	private:
		AggregatorFactory();
		static AggregatorFactory * instance;

	public:
		static void init();
		static AggregatorFactory * getInstance();

		///Returns a shared pointer to an aggregator object corresponding to the given function
		AggregatorSharedPtr getAggregator(const CubeDefinitionAPI::measureFunction & fn);
	};
}
#endif
