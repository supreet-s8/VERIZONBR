/*

Copyright (C) 2009-2011 Calpont Corporation.

Use of and access to the Calpont InfiniDB Community software is subject to the
terms and conditions of the Calpont Open Source License Agreement. Use of and
access to the Calpont InfiniDB Enterprise software is subject to the terms and
conditions of the Calpont End User License Agreement.

This program is distributed in the hope that it will be useful, and unless
otherwise noted on your license agreement, WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Please refer to the Calpont Open Source License Agreement and the Calpont End
User License Agreement for more details.

You should have received a copy of either the Calpont Open Source License
Agreement or the Calpont End User License Agreement along with this program; if
not, it is your responsibility to review the terms and conditions of the proper
Calpont license agreement by visiting http://www.calpont.com for the Calpont
InfiniDB Enterprise End User License Agreement or http://www.infinidb.org for
the Calpont InfiniDB Community Calpont Open Source License Agreement.

Calpont may make changes to these license agreements from time to time. When
these changes are made, Calpont will make a new copy of the Calpont End User
License Agreement available at http://www.calpont.com and a new copy of the
Calpont Open Source License Agreement available at http:///www.infinidb.org.
You understand and agree that if you use the Program after the date on which
the license agreement authorizing your use has changed, Calpont will treat your
use as acceptance of the updated License.

*/

// $Id$

/** @file
 *
 * File contains basic typedefs shared externally with other parts of the
 * system.  These types are placed here rather than in we_type.h in order
 * to decouple we_type.h and we_define.h from external components, so that
 * the other libraries won't have to recompile every time we change something
 * in we_type.h and/or we_define.h.
 */

#ifndef _WE_TYPEEXT_H_
#define _WE_TYPEEXT_H_
#include <stdint.h>
#include <sys/types.h>

/** Namespace WriteEngine */
namespace WriteEngine
{
   /************************************************************************
    * Type definitions
    ************************************************************************/
    typedef u_int64_t          i64; // 8 byte value
    typedef i64                RID; // Row ID

   /************************************************************************
    * the set of Calpont column data types (used for DDL/DML interface)
    ************************************************************************/
    enum ColDataType      { BIT,
                            TINYINT,
                            CHAR,
                            SMALLINT,
                            DECIMAL,
                            MEDINT,
                            INT,
                            FLOAT,
                            DATE,
                            BIGINT,
                            DOUBLE,
                            DATETIME,
                            VARCHAR,
                            VARBINARY,
                            CLOB,
                            BLOB,
                            NUM_OF_COL_DATA_TYPE };

   /************************************************************************
    * Dictionary related structure
    ************************************************************************/
    struct Token {
        i64     op       :  10;   // file block number
        i64     fbo      :  36;   // ordinal position
        i64     spare    :  18;   // spare
        Token()                   // constructor, set to null value
        {
            op  = 0x3FE;
            fbo = 0xFFFFFFFFFLL;
            spare = 0x3FFFF;
        }
   };


} //end of namespace

#endif // _WE_TYPEEXT_H_
