/*

Copyright (C) 2009-2011 Calpont Corporation.

Use of and access to the Calpont InfiniDB Community software is subject to the
terms and conditions of the Calpont Open Source License Agreement. Use of and
access to the Calpont InfiniDB Enterprise software is subject to the terms and
conditions of the Calpont End User License Agreement.

This program is distributed in the hope that it will be useful, and unless
otherwise noted on your license agreement, WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Please refer to the Calpont Open Source License Agreement and the Calpont End
User License Agreement for more details.

You should have received a copy of either the Calpont Open Source License
Agreement or the Calpont End User License Agreement along with this program; if
not, it is your responsibility to review the terms and conditions of the proper
Calpont license agreement by visiting http://www.calpont.com for the Calpont
InfiniDB Enterprise End User License Agreement or http://www.infinidb.org for
the Calpont InfiniDB Community Calpont Open Source License Agreement.

Calpont may make changes to these license agreements from time to time. When
these changes are made, Calpont will make a new copy of the Calpont End User
License Agreement available at http://www.calpont.com and a new copy of the
Calpont Open Source License Agreement available at http:///www.infinidb.org.
You understand and agree that if you use the Program after the date on which
the license agreement authorizing your use has changed, Calpont will treat your
use as acceptance of the updated License.

*/

/***********************************************************************
 *   $Id: we_xmlgenproc.h 2968 2011-05-13 19:01:26Z rdempsey $
 *
 ***********************************************************************/
/** @file */
#ifndef WE_XMLGENPROC_H
#define WE_XMLGENPROC_H

#include <libxml/parser.h>
#include <libxml/xmlwriter.h>
#include <string>
#include <vector>

#include "calpontsystemcatalog.h"
#include "we_log.h"
#include "we_xmlgendata.h"

#if defined(_MSC_VER) && defined(WRITEENGINEXMLGENPROC_DLLEXPORT)
#define EXPORT __declspec(dllexport)
#else
#define EXPORT
#endif

namespace WriteEngine
{
struct SysCatColumn
{
    execplan::CalpontSystemCatalog::OID          oid;
    execplan::CalpontSystemCatalog::ColType      colType;
    execplan::CalpontSystemCatalog::TableColName tableColName;
};
typedef std::vector<SysCatColumn> SysCatColumnList;

class XMLGenData;

/** @brief Processes/generates job_xxx.xml file (for cpimport) using XMLGenData
 *  as input.
 *
 *  This class was moved from XMLProc, formerly in tools/dbloadxml.  It was
 *  moved to writeengine/xml so that both colxml and cpimport could use it.
 */
class XMLGenProc
{
public:

    /** @brief XMLGenProc constructor
     *
     * @param mgr The input data used to generate a Job XML file.
     * @param bUseXmlLogFile Log info/errors to Job XML log file.
     * @param bSysCatRpt Generating SysCat report (true) or XML file (false)
     */
    EXPORT XMLGenProc(XMLGenData* mgr, bool bUseXmlLogFile, bool bSysCatRpt);
    EXPORT ~XMLGenProc();

    /** @brief start constructing XML file document.
     */
    EXPORT void  startXMLFile( );
    
     /** @brief Creates table tag for the specified table.
     *
     * @param table Name of table for which the table tag is to be generated.
     */ 
    EXPORT void  makeTableData(
        const execplan::CalpontSystemCatalog::TableName& table);

    /** @brief Creates column tags for the specified table.
     *
     * @param table Name of table for which the column tags are to be generated.
     * @return true means column tags created; else false is returned
     */  
    EXPORT bool  makeColumnData(
        const execplan::CalpontSystemCatalog::TableName& table, const std::vector<std::string> &cols = std::vector<std::string>());
    
    /** @brief Generate Job XML file name
     */   
    EXPORT std::string genJobXMLFileName( ) const;

    /** @brief Write xml file document to the destination Job XML file.
     *
     * @param xmlFileName Name of XML file to be generated.
     */   
    EXPORT void  writeXMLFile( const std::string& xmlFileName );

    /** @brief log a message.
     *
     * @param msg The message to be logged to the error log file.
     */
    EXPORT void logErrorMessage(const std::string& msg);
    std::string errorString() { return fErrorString; }

    /** @brief set debug level
     */
    void setDebugLevel( int dbg ) { fDebugLevel = dbg; }

protected:

private:
    XMLGenProc(const XMLGenProc&);             // disable default copy ctor
    XMLGenProc& operator=(const XMLGenProc&);  // disable default assignment
    void getColumnsForTable(const std::string& schema,
        const std::string& table, SysCatColumnList& colList);
    void sortColumnsByPosition(SysCatColumnList &columns);
    void orderColumnsByPosition(SysCatColumnList &columns, const std::vector<std::string> &cols);

    Log               fLog;
    xmlDocPtr         fDoc;
    xmlTextWriterPtr  fWriter;
    std::string       fErrorString;
    int               fDebugLevel;
    XMLGenData*       fInputMgr;    // Input data used to generate Job XML file
    bool              fSysCatRpt;   // True colxml output or a syscat report
    bool              fUseXmlLogFile;//Log info/errors to Job XML log file
};

}                                                 // namespace WriteEngine

#undef EXPORT

#endif                                            
