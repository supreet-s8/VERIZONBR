#ifndef JOINLIKEFILTERCOLUMN_H
#define JOINLIKEFILTERCOLUMN_H
#include <string>
#include <boost/shared_ptr.hpp>

#include "returnedcolumn.h"
#include "treenode.h"
#include "calpontsystemcatalog.h"
#include "dataconvert.h"

namespace messageqcpp {
class ByteStream;
}

namespace execplan { 

class JoinLikeFilterColumn : public ReturnedColumn {

public:
 
	JoinLikeFilterColumn();
	
	virtual ~JoinLikeFilterColumn();

    inline virtual JoinLikeFilterColumn* clone() const
    {
        return new JoinLikeFilterColumn (*this);
    }

    JoinLikeFilterColumn(const JoinLikeFilterColumn& rhs, const u_int32_t sessionID = 0);

    virtual void serialize(messageqcpp::ByteStream&) const;
    virtual void unserialize(messageqcpp::ByteStream&);

    virtual const std::string toString() const;

    JoinLikeFilterColumn& operator=(const JoinLikeFilterColumn& rhs);

    virtual bool operator==(const TreeNode* t) const;
    virtual bool operator!=(const TreeNode* t) const;

    bool operator==(const JoinLikeFilterColumn& t) const;
    bool operator!=(const JoinLikeFilterColumn& t) const;


};

std::ostream& operator<<(std::ostream& output, const JoinLikeFilterColumn& rhs);

}
#endif //JOINLIKEFILTERCOLUMN_H

