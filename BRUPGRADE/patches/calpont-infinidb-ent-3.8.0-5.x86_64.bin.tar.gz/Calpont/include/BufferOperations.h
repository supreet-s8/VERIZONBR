#ifndef BUFFEROPERATIONS_H
#define BUFFEROPERATIONS_H

#include "avs_ByteBuffer.h"
#include "avs_Configuration.h"
#include "avs_HalfPrecisionFloat.h"

namespace ATS
{

  class BufferOperations
  {
  public:
    static int8_t getVersion(const std::string& buf) {
      return ByteBuffer::ByteBuffer::getByte(buf, Configuration::VERSION_POS);
    }
    
    static int16_t getSize(const std::string& buf) {
      return ByteBuffer::ByteBuffer::getShort(buf, Configuration::V1_SIZE_POS);
    }
    
    static int16_t getMaxSize(const std::string& buf) {
      return ByteBuffer::ByteBuffer::getShort(buf, Configuration::V1_MAX_SIZE_POS);
    }
    
    static int8_t getFloatSize(const std::string& buf) {
      return ByteBuffer::ByteBuffer::getByte(buf, Configuration::V1_FLOAT_SIZE_POS);
    }
    
    static int16_t getKey(const std::string& buf, const unsigned int position) {
      unsigned int pos = position << 2;
      if(getFloatSize(buf) == 4)
	pos += (pos >> 1);
      return ByteBuffer::ByteBuffer::getShort(buf, Configuration::HEADER_SIZE+pos);
    }
    
    static float getVal(const std::string& buf, const unsigned int position) {
      unsigned int pos = position << 2;
      if(getFloatSize(buf) == 2) {
	return HalfPrecisionFloat::shortBitsToFloat(ByteBuffer::ByteBuffer::getShort(buf, Configuration::HEADER_SIZE + pos + 2));
      } else {
	pos += (pos >> 1);
	return ByteBuffer::ByteBuffer::getFloat(buf, Configuration::HEADER_SIZE + pos + 2);
      }
    }
    
    static void putVersion(std::string& buf, const int8_t version) {
      ByteBuffer::ByteBuffer::putByte(buf, Configuration::VERSION_POS, version);
    }
    
    static void putType(std::string& buf, const int8_t type) {
      ByteBuffer::ByteBuffer::putByte(buf, Configuration::V1_TYPE_POS, type);
    }
    
    static void putSize(std::string& buf, const int16_t size) {
      ByteBuffer::ByteBuffer::putShort(buf, Configuration::V1_SIZE_POS, size);
    }
    
    static void putMaxSize(std::string& buf, const int16_t maxsize) {
      ByteBuffer::ByteBuffer::putShort(buf, Configuration::V1_MAX_SIZE_POS, maxsize);
    }
    
    static void putFloatSize(std::string& buf, const int8_t floatsize) {
      ByteBuffer::ByteBuffer::putByte(buf, Configuration::V1_FLOAT_SIZE_POS, floatsize);
    }
    
    static void putKey(std::string& buf, const unsigned int position, const int16_t key) {
      unsigned int pos = position << 2;
      if(getFloatSize(buf) == 4)
	pos += (pos >> 1);
      ByteBuffer::ByteBuffer::putShort(buf, Configuration::HEADER_SIZE + pos, key);
    }
    
    static void putVal(std::string& buf, const unsigned int position, const float val) {
      unsigned int pos = position << 2;
      if(getFloatSize(buf) == 2) {
	int16_t v = HalfPrecisionFloat::floatToShortBits(val);
	ByteBuffer::ByteBuffer::putShort(buf, Configuration::HEADER_SIZE + pos + 2, v);
      } else {
	pos += (pos >> 1);
	ByteBuffer::ByteBuffer::putFloat(buf, Configuration::HEADER_SIZE + pos + 2, val);
      }
    }
        
  };

}

#endif // BUFFEROPERATIONS_H
