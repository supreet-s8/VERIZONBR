// Concurrent Flows Library
// Nikhil S. Ketkar, nikhil.ketkar@guavus.com

#ifndef BITARRAY_H
#define BITARRAY_H

#include <string>
#include <iostream>

#include "ConcurrentFlowException.h"
namespace ConcurrentFlows
{

class BitArray
{
public:
  BitArray(unsigned int givenBufferSize)
  {
    sizeInBytes = givenBufferSize;
    data.resize(givenBufferSize);
    for (unsigned int i = 0; i < givenBufferSize; ++i)
      data[i] = 0;
    writePos = 0;
    readOnly = false;
  }

  BitArray(std::string& givenData)
  {
    data = givenData;
    sizeInBytes = data.size();
    readOnly = true;
  }

  void getData(std::string& result)
  {
    result = data;
  }

  bool getBit(unsigned int pos)
  {
    unsigned int bytePosition = pos/8;
    unsigned int bitPosition = pos%8;
    if ((bytePosition > sizeInBytes) || (bitPosition > 8))
      throw ConcurrentFlowException();

    unsigned char byteValue = data[bytePosition];
    if ( (byteValue >> (8 - (bitPosition+1))) & 0x0001 )
      return true;
    else
      return false;
  }

  void setNextBit(bool bit)
  {
    if (! readOnly)
      {
        unsigned int bytePosition = writePos/8;
        unsigned int bitPosition = writePos%8;
        if ((bytePosition > sizeInBytes) || (bitPosition > 8))
          throw ConcurrentFlowException();

        unsigned char oldByte = data[bytePosition];
        unsigned int val;
        if (bit)
          val = 1;
        else
          val = 0;

        oldByte = (unsigned char) (((0xFF7F>>bitPosition) & oldByte) & 0x00FF);
        unsigned char newByte = (unsigned char) ((val<<(8-(bitPosition+1))) | oldByte);
        data[bytePosition] = newByte;
        writePos++;
      }
    else
      throw ConcurrentFlowException();
  }

  void getBitString(std::string& result)
  {
    result.resize(sizeInBytes * 8);
    for (unsigned int i = 0; i < sizeInBytes * 8; ++i)
      {
        if (getBit(i) == 0)
          result[i] = '0';
        else
          result[i] = '1';
      }
  }

private:
  std::string data;
  unsigned int sizeInBytes;
  unsigned int writePos;
  bool readOnly;
};

} //namespace ConcurrentFlows

#ifdef TESTING_WITH_GTEST

TEST(BitArray, InitEmptyTest)
{
  ConcurrentFlows::BitArray ba(2);
  std::string actualResult;
  ba.getBitString(actualResult);
  ASSERT_TRUE(actualResult == std::string("0000000000000000"));
}

TEST(BitArray, InitAndGetTest)
{
  ConcurrentFlows::BitArray ba(2);
  ba.setNextBit(true);
  ba.setNextBit(false);
  ba.setNextBit(false);
  ba.setNextBit(true);
  std::string intermediateResult;
  ba.getData(intermediateResult);

  ConcurrentFlows::BitArray baNext(intermediateResult);
  ASSERT_TRUE(baNext.getBit(0));
  ASSERT_FALSE(baNext.getBit(1));
  ASSERT_FALSE(baNext.getBit(2));
  ASSERT_TRUE(baNext.getBit(3));
  ASSERT_FALSE(baNext.getBit(4));
  ASSERT_FALSE(baNext.getBit(5));
  ASSERT_FALSE(baNext.getBit(6));
  ASSERT_FALSE(baNext.getBit(7));
  ASSERT_FALSE(baNext.getBit(8));
  ASSERT_FALSE(baNext.getBit(9));
  ASSERT_FALSE(baNext.getBit(10));
  ASSERT_FALSE(baNext.getBit(11));
  ASSERT_FALSE(baNext.getBit(12));
  ASSERT_FALSE(baNext.getBit(13));
  ASSERT_FALSE(baNext.getBit(14));
  ASSERT_FALSE(baNext.getBit(15));
}

TEST(BitArray, ExceptionTest)
{
  ConcurrentFlows::BitArray ba(1);
  for (unsigned int i = 0; i < 100; ++i)
    {
      try
        {
          ba.setNextBit(true);
        }
      catch (std::exception& e)
        {
          ASSERT_TRUE(e.what() == "Concurrent Flow Exception");
        }
    }

  for (unsigned int i = 0; i < 100; ++i)
    {
      try
        {
          ba.getBit(i);
        }
      catch (std::exception& e)
        {
          ASSERT_TRUE(e.what() == "Concurrent Flow Exception");
        }
    }
}

TEST(BitArray, GetSetTest)
{
  ConcurrentFlows::BitArray ba(2);
  ba.setNextBit(true);
  ba.setNextBit(false);
  ba.setNextBit(false);
  ba.setNextBit(true);
  std::string actualResult;
  ba.getBitString(actualResult);
  ASSERT_TRUE(actualResult == std::string("1001000000000000"));
}

#endif //TESTING_WITH_GTEST

#endif // BITARRAY_H
