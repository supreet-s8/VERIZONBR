/*

Copyright (C) 2009-2011 Calpont Corporation.

Use of and access to the Calpont InfiniDB Community software is subject to the
terms and conditions of the Calpont Open Source License Agreement. Use of and
access to the Calpont InfiniDB Enterprise software is subject to the terms and
conditions of the Calpont End User License Agreement.

This program is distributed in the hope that it will be useful, and unless
otherwise noted on your license agreement, WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Please refer to the Calpont Open Source License Agreement and the Calpont End
User License Agreement for more details.

You should have received a copy of either the Calpont Open Source License
Agreement or the Calpont End User License Agreement along with this program; if
not, it is your responsibility to review the terms and conditions of the proper
Calpont license agreement by visiting http://www.calpont.com for the Calpont
InfiniDB Enterprise End User License Agreement or http://www.infinidb.org for
the Calpont InfiniDB Community Calpont Open Source License Agreement.

Calpont may make changes to these license agreements from time to time. When
these changes are made, Calpont will make a new copy of the Calpont End User
License Agreement available at http://www.calpont.com and a new copy of the
Calpont Open Source License Agreement available at http:///www.infinidb.org.
You understand and agree that if you use the Program after the date on which
the license agreement authorizing your use has changed, Calpont will treat your
use as acceptance of the updated License.

*/

/***********************************************************************
*   $Id: rowcolumn.h 6309 2010-03-04 19:33:12Z zzhu $
*
*
***********************************************************************/
/** @file */

#ifndef ROWCOLUMN_H
#define ROWCOLUMN_H
#include <string>
#include <vector>
#include <boost/shared_ptr.hpp>

#include "returnedcolumn.h"
#include "treenode.h"
#include "calpontsystemcatalog.h"
#include "dataconvert.h"

namespace messageqcpp {
class ByteStream;
}

/**
 * Namespace
 */
namespace execplan { 

class ParseTree;
/**
 * @brief A class to represent a simple returned column
 * 
 * This class is a specialization of class ReturnedColumn that handles
 * a group of columns. Mostly used in subquery context. This class is
 * internal to the connector. No serialization interface is provided. 
 * The joblist factory will not recognize this class.
 */
class RowColumn : public ReturnedColumn {

public:
 
	/**
	 * Constructors
	 */ 
	RowColumn(const uint32_t sessionID = 0);
	RowColumn(const RowColumn& rhs, const uint32_t sessionID = 0);
	
	/**
	 * Destructor
	 */
	virtual ~RowColumn();
	
	/**
	 * Accessor Methods
	 */
	const std::vector<SRCP>& columnVec() const { return fColumnVec; }
	void columnVec( const std::vector<SRCP>& columnVec ) { fColumnVec = columnVec; }
	 
	/** return a copy of this pointer
	 *
	 * deep copy of this pointer and return the copy
	 */	
	inline virtual RowColumn* clone() const
	{
	    return new RowColumn (*this);
	}	
	/**
	 * Overloaded assignment operator
	 */
	RowColumn& operator=(const RowColumn& rhs);
	
	/**
	 * The serialize interface
	 */
	//virtual void serialize(messageqcpp::ByteStream&) const;
	//virtual void unserialize(messageqcpp::ByteStream&);

	virtual const std::string toString() const;

	/**
	 * Serialization interface
	 */
	virtual void serialize(messageqcpp::ByteStream&) const;
	virtual void unserialize(messageqcpp::ByteStream&);

	
	/** @brief Do a deep, strict (as opposed to semantic) equivalence test
	 *
	 * Do a deep, strict (as opposed to semantic) equivalence test.
	 * @return true iff every member of t is a duplicate copy of every member of this; false otherwise
	 */
	virtual bool operator==(const TreeNode* t) const;
	
	/** @brief Do a deep, strict (as opposed to semantic) equivalence test
	 *
	 * Do a deep, strict (as opposed to semantic) equivalence test.
	 * @return true iff every member of t is a duplicate copy of every member of this; false otherwise
	 */
	bool operator==(const RowColumn& t) const;
	
	/** @brief Do a deep, strict (as opposed to semantic) equivalence test
	 *
	 * Do a deep, strict (as opposed to semantic) equivalence test.
	 * @return false iff every member of t is a duplicate copy of every member of this; true otherwise
	 */
	virtual bool operator!=(const TreeNode* t) const;
	 
	/** @brief Do a deep, strict (as opposed to semantic) equivalence test
	 *
	 * Do a deep, strict (as opposed to semantic) equivalence test.
	 * @return false iff every member of t is a duplicate copy of every member of this; true otherwise
	 */
	bool operator!=(const RowColumn& t) const;

private:
	/**
	 * Fields
	 */
	std::vector<SRCP> fColumnVec;
			
};

/** dummy class. For the connector to use in gp_walk*/
class SubSelect : public ReturnedColumn
{
public:
	SubSelect(): ReturnedColumn() {}
	~SubSelect() {}
	SubSelect* clone() const { return new SubSelect(); }
};


/**
 * ostream operator
 */
std::ostream& operator<<(std::ostream& output, const RowColumn& rhs);

}
#endif //SIMPLECOLUMN_H

