// Concurrent Flows Library
// Nikhil S. Ketkar, nikhil.ketkar@guavus.com

#ifndef PCMCOMPRESSEDLOOKUP_H
#define PCMCOMPRESSEDLOOKUP_H

#include <string>
#include <vector>
#include <cmath>

#include "boost/shared_ptr.hpp"

#include "FloatArraySerialize.h"
#include "LevelArray.h"

#define BYTES_REQUIRED_PER_LEVEL 4
namespace ConcurrentFlows
{

class PCMCompressedLookup
{
public:
  PCMCompressedLookup(unsigned int givenLevelCount, unsigned int givenSeriesLength, 
		  unsigned int givenFloatSize, const std::string& data)
  {
    levelCount = givenLevelCount;
    floatSize = givenFloatSize;
    seriesLength = givenSeriesLength;
    unsigned int bitsPerLevel = PCMCompressedLookup::computeRequiredBits(levelCount);
    int bitsRequired = bitsPerLevel * seriesLength;
    int bytesRequired = bitsRequired/8 + (bitsRequired % 8 > 0 ? 1 : 0);
    std::string levels = data.substr(0, bytesRequired);    
    std::string levelValueBytes = data.substr(bytesRequired, bytesRequired+floatSize*levelCount);
    FloatArraySerialize::byteArrayToFloatArray(levelValueBytes, levelValues, floatSize);
    levelArray.reset(new LevelArray(bitsPerLevel, seriesLength, levels));
  }

  float getValue(unsigned int pos)
  {
    int currLevel = levelArray->getLevel(pos);
    return levelValues[currLevel];
  }
  
  void debug(){
	std::cout << "Levels=>";
	for(int i=0; i<levelCount; i++){
		std::cout << "\t" << i << ":" << levelValues[i];
	}
	std::cout << "\nValues=>";
	for(int i=0; i<seriesLength; i++){
		std::cout << "\t" << i << ":" << getValue(i);
	}
	std::cout << std::endl;
  }

private:
  static unsigned int computeRequiredBits(unsigned int uniqueValues)
  {
    if (uniqueValues == 1)
      return 1;
    else
      return static_cast<unsigned int>(ceil(log(uniqueValues)/log(2)));
  }

  unsigned int floatSize;
  unsigned int levelCount;
  unsigned int seriesLength;
  std::vector<float> levelValues;
  boost::shared_ptr<LevelArray> levelArray;
};

} // namespace ConcurrentFlows

#ifdef TESTING_WITH_GTEST




#endif //TESTING_WITH_GTEST

#endif // PCMCOMPRESSEDLOOKUP_H
