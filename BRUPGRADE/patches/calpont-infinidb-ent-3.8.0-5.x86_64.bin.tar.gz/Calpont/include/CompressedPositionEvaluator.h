#ifndef COMPRESSEDPOSITIONEVALUATOR_H_
#define COMPRESSEDPOSITIONEVALUATOR_H_

#ifdef TESTING_WITH_GTEST
#include "gtest/gtest.h"

#endif //TESTING_WITH_GTEST

#include "Configuration.h"
#include "Murmur3Hash.h"

namespace CompressedSet
{
  class CompressedPositionEvaluator
  {
  private:
    static inline int64_t powOf2(int power) {
      long exp = 1;
      return exp << power;
    }

  public:
    static int64_t getHash(const int64_t data) {
      int64_t temp = data;
      int64_t result[2];
      Murmur3Hash::MurmurHash3_x64_128m(reinterpret_cast<int8_t *>(&temp), 8, 0, result);
      return result[0];
    }

    static int64_t getHashOld(const int64_t data) {
      int64_t temp = data;
      int64_t result[2];
      Murmur3Hash::MurmurHash3_x64_128(reinterpret_cast<int8_t *>(&temp), 8, 0, result);
      return result[0];
    }

    static int32_t getPCSABitPosition(const int64_t hashInput) {
      const int64_t ONE = 1;
      int32_t pcsaSize = Configuration::totalSize - Configuration::HEADER_SIZE - Configuration::linearCounterSize;
      pcsaSize *= 8;
      if(pcsaSize < 0) return -1;
      int32_t mapSize = Configuration::pcsaMapSize;
      int32_t nMaps = pcsaSize / mapSize;
      int64_t mod = powOf2(mapSize);
      int64_t hash = hashInput % mod;
      hash = hash < 0 ? -hash : hash;
      int64_t hashCopy = hash;
      hash /= nMaps;
      int32_t rank = 0;
      while (hash != 0 && (hash & ONE) == 0) {
        hash >>= 1;
        rank++;
      }
      int32_t map = (int32_t) (hashCopy % nMaps);
      int32_t pos = (map * mapSize + rank);
      return pos;
    }

    static int32_t getLCBitPosition(const int64_t hash) {
      int32_t lcSize = Configuration::linearCounterSize * 8;
      if(lcSize <= 0) return -1;
      int32_t pos = (int32_t) (hash % lcSize);
      if(pos < 0) pos *= -1;
      return pos;
    }

    static int32_t getLCBitPositionV3(const int64_t hash, int16_t lc_size) {
      int32_t lcSize = lc_size * 8;
      if(lcSize <= 0) return -1;
      int32_t pos = (int32_t) (hash % lcSize);
      if(pos < 0) pos *= -1;
      return pos;
    }

    static void getHLLCPos(const int64_t hash, int32_t *vals) {
      const int64_t ONE = 1;
      int64_t posFinder = hash / Configuration::V2_HLLC_NMAPS;
      int32_t mapFinder = (int32_t) (hash % Configuration::V2_HLLC_NMAPS);
      if(mapFinder < 0) mapFinder *= -1;
      int32_t rank = 1;
      while(posFinder != 0 && (posFinder & ONE) == 0) {
	posFinder >>= 1;
	rank++;
      }
      if(rank > 128) {
	// throw exception here
      }
      vals[0] = rank;
      vals[1] = mapFinder;
    }

    static void getHLLCPosV3(const int64_t hash, int32_t *vals, int16_t nMaps) {
      const int64_t ONE = 1;
      if(nMaps <= 0) {
	vals[0] = -1;
	vals[1] = -1;
	return;
      }
      int64_t posFinder = hash / nMaps;
      int32_t mapFinder = (int32_t) (hash % nMaps);
      if(mapFinder < 0) mapFinder *= -1;
      int32_t rank = 1;
      while(posFinder != 0 && (posFinder & ONE) == 0) {
	posFinder >>= 1;
	rank++;
      }
      if(rank > 128) {
	// throw exception here
      }
      vals[0] = rank;
      vals[1] = mapFinder;
    }
  };

}
#ifdef TESTING_WITH_GTEST

TEST(CompressedPositionEvaluator, CombinedTest)
{
  int64_t input;
  int64_t hash;
  int32_t pcsaPosition;
  int32_t linearCounterPosition;

  input = 42;
  hash = CompressedSet::CompressedPositionEvaluator::getHashOld(input);
  linearCounterPosition = CompressedSet::CompressedPositionEvaluator::getLCBitPosition(hash);
  pcsaPosition = CompressedSet::CompressedPositionEvaluator::getPCSABitPosition(hash);
  ASSERT_TRUE(hash == 6680639807124125198);
  ASSERT_TRUE(linearCounterPosition == 1198);
  ASSERT_TRUE(pcsaPosition == 19969);

  input = 10;
  hash = CompressedSet::CompressedPositionEvaluator::getHashOld(input);
  linearCounterPosition = CompressedSet::CompressedPositionEvaluator::getLCBitPosition(hash);
  pcsaPosition = CompressedSet::CompressedPositionEvaluator::getPCSABitPosition(hash);
  ASSERT_TRUE(hash == 3287854368493403577);
  ASSERT_TRUE(linearCounterPosition == 3577);
  ASSERT_TRUE(pcsaPosition == 13504);

  input = 1988;
  hash = CompressedSet::CompressedPositionEvaluator::getHashOld(input);
  linearCounterPosition = CompressedSet::CompressedPositionEvaluator::getLCBitPosition(hash);
  pcsaPosition = CompressedSet::CompressedPositionEvaluator::getPCSABitPosition(hash);
  ASSERT_TRUE(hash == 8433270747776506067);
  ASSERT_TRUE(linearCounterPosition == 2067);
  ASSERT_TRUE(pcsaPosition == 16192);

  input = 42;
  hash = CompressedSet::CompressedPositionEvaluator::getHash(input);
  linearCounterPosition = CompressedSet::CompressedPositionEvaluator::getLCBitPosition(hash);
  pcsaPosition = CompressedSet::CompressedPositionEvaluator::getPCSABitPosition(hash);
  ASSERT_TRUE(hash == 6680639807124125198);
  ASSERT_TRUE(linearCounterPosition == 1198);
  ASSERT_TRUE(pcsaPosition == 19969);

  input = 10;
  hash = CompressedSet::CompressedPositionEvaluator::getHash(input);
  linearCounterPosition = CompressedSet::CompressedPositionEvaluator::getLCBitPosition(hash);
  pcsaPosition = CompressedSet::CompressedPositionEvaluator::getPCSABitPosition(hash);
  ASSERT_TRUE(hash == 3287854368493403577);
  ASSERT_TRUE(linearCounterPosition == 3577);
  ASSERT_TRUE(pcsaPosition == 13504);

  input = 1988;
  hash = CompressedSet::CompressedPositionEvaluator::getHash(input);
  linearCounterPosition = CompressedSet::CompressedPositionEvaluator::getLCBitPosition(hash);
  pcsaPosition = CompressedSet::CompressedPositionEvaluator::getPCSABitPosition(hash);
  ASSERT_TRUE(hash == 8433270747776506067);
  ASSERT_TRUE(linearCounterPosition == 2067);
  ASSERT_TRUE(pcsaPosition == 16192);
}


TEST(CompressedPositionEvaluator, HashCorrectnessTest)
{
  	int64_t input;
  	int64_t hashUsing128;
  	int64_t hashUsing128m;
	for(input = 0; input < 100000000L;++input)
	{
		hashUsing128 = CompressedSet::CompressedPositionEvaluator::getHashOld(input);
		hashUsing128m = CompressedSet::CompressedPositionEvaluator::getHash(input);
		ASSERT_TRUE(hashUsing128 == hashUsing128m);
	}
}

#endif //TESTING_WITH_GTEST

#endif // COMPRESSEDPOSITIONEVALUATOR_H_
