#ifndef GETCONFIG_H
#define GETCONFIG_H

#include <iostream>
#include <cassert>
#include <unistd.h>
using namespace std;

string GetConfig(const string& arg1, const string& arg2, bool vflg=false, const string& configFile="");

#endif

