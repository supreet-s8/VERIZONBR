/*

Copyright (C) 2009-2011 Calpont Corporation.

Use of and access to the Calpont InfiniDB Community software is subject to the
terms and conditions of the Calpont Open Source License Agreement. Use of and
access to the Calpont InfiniDB Enterprise software is subject to the terms and
conditions of the Calpont End User License Agreement.

This program is distributed in the hope that it will be useful, and unless
otherwise noted on your license agreement, WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Please refer to the Calpont Open Source License Agreement and the Calpont End
User License Agreement for more details.

You should have received a copy of either the Calpont Open Source License
Agreement or the Calpont End User License Agreement along with this program; if
not, it is your responsibility to review the terms and conditions of the proper
Calpont license agreement by visiting http://www.calpont.com for the Calpont
InfiniDB Enterprise End User License Agreement or http://www.infinidb.org for
the Calpont InfiniDB Community Calpont Open Source License Agreement.

Calpont may make changes to these license agreements from time to time. When
these changes are made, Calpont will make a new copy of the Calpont End User
License Agreement available at http://www.calpont.com and a new copy of the
Calpont Open Source License Agreement available at http:///www.infinidb.org.
You understand and agree that if you use the Program after the date on which
the license agreement authorizing your use has changed, Calpont will treat your
use as acceptance of the updated License.

*/

/***********************************************************************
 *   $Id: dmlparser.h 7409 2011-02-08 14:38:50Z rdempsey $
 *
 *
 ***********************************************************************/
/** @file */

#ifndef DMLPARSER_H
#define DMLPARSER_H

#include <stdexcept>
#include "dmlpkg.h"

namespace dmlpackage
{
	typedef std::vector<char*> valbuf_t;

	
    typedef SqlStatementList ParseTree;

    /** @brief BISON parser wrapper class
     */
    class DMLParser
    {
        public:
            /** @brief ctor
             */
            DMLParser();

            /** @brief dtor
             */
            virtual ~DMLParser();

            /** @brief parse the supplied dml statement
             *
             * @param dmltext the dml statement to parse
             */
            int parse(const char* dmltext);

            /** @brief get the parse tree
             */
            const ParseTree& getParseTree();

			void setDefaultSchema(std::string schema);

            /** @brief was the parse successful
             */
            bool good();

            /** @brief put the parser in debug mode so as to dump
             * diagnostic information
             */
            void setDebug(bool debug);

        protected:
            ParseTree fParseTree;
            int fStatus;
            bool fDebug;

        private:

    };

    /** @brief specialization of the DMLParser class
     * specifically for reading the dml statement
     * from a file
     */
    class DMLFileParser : public DMLParser
    {
        public:
            /** @brief ctor
             */
            DMLFileParser();

            /** @brief parse the dml statement contained in the
             *	supplied file
             *
             * @param fileName the fully qualified file name to open
             * and parse the contents of
             */
            int parse(const std::string& fileName);

        protected:

        private:
    };

}
#endif                                            // DMLPARSER_H
