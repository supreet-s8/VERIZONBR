/*

Copyright (C) 2009-2011 Calpont Corporation.

Use of and access to the Calpont InfiniDB Community software is subject to the
terms and conditions of the Calpont Open Source License Agreement. Use of and
access to the Calpont InfiniDB Enterprise software is subject to the terms and
conditions of the Calpont End User License Agreement.

This program is distributed in the hope that it will be useful, and unless
otherwise noted on your license agreement, WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Please refer to the Calpont Open Source License Agreement and the Calpont End
User License Agreement for more details.

You should have received a copy of either the Calpont Open Source License
Agreement or the Calpont End User License Agreement along with this program; if
not, it is your responsibility to review the terms and conditions of the proper
Calpont license agreement by visiting http://www.calpont.com for the Calpont
InfiniDB Enterprise End User License Agreement or http://www.infinidb.org for
the Calpont InfiniDB Community Calpont Open Source License Agreement.

Calpont may make changes to these license agreements from time to time. When
these changes are made, Calpont will make a new copy of the Calpont End User
License Agreement available at http://www.calpont.com and a new copy of the
Calpont Open Source License Agreement available at http:///www.infinidb.org.
You understand and agree that if you use the Program after the date on which
the license agreement authorizing your use has changed, Calpont will treat your
use as acceptance of the updated License.

*/

//  $Id: we_dbfileop.h 2961 2011-05-09 14:45:57Z chao $

/** @file */

#ifndef _WE_DBFILEOP_H_
#define _WE_DBFILEOP_H_

#include "we_type.h"
#include "we_fileop.h"
#include "we_blockop.h"
#include "we_cache.h"


#if defined(_MSC_VER) && defined(WRITEENGINEDBFILEOP_DLLEXPORT)
#define EXPORT __declspec(dllexport)
#else
#define EXPORT
#endif

/** Namespace WriteEngine */
namespace WriteEngine
{

// forward reference
class ChunkManager;


/** Class DbFileOp */
class DbFileOp : public FileOp
{
public:
   /**
    * @brief Constructor
    */
    EXPORT DbFileOp();

   /**
    * @brief Default Destructor
    */
    EXPORT virtual ~DbFileOp();

    EXPORT virtual int   flushCache();

   /**
    * @brief Get an entry within a subblock
    */
    EXPORT void          getSubBlockEntry( unsigned char* blockBuf,
                                           const int sbid,
                                           const int entryNo,
                                           const int width,
                                           void* pStruct ) ;

   /**
    * @brief Get an entry within a subblock using block information
    */
    void                 getSubBlockEntry( DataBlock* block,
                                           const int sbid,
                                           const int entryNo,
                                           const int width,
                                           void* pStruct )
    { getSubBlockEntry( block->data, sbid, entryNo, width, pStruct );}

   /**
    * @brief Read DB file to a buffer
    */
    EXPORT virtual int   readDBFile(       FILE* pFile,
                                           unsigned char* readBuf,
                                           const i64 lbid,
                                           const bool isFbo = false );
    EXPORT int           readDBFile(       CommBlock& cb,
                                           unsigned char* readBuf,
                                           const i64 lbid );

    EXPORT int           readDBFile(       FILE* pFile,
                                           DataBlock* block,
                                           const i64 lbid,
                                           const bool isFbo = false );
    int                  readDBFile(       CommBlock& cb,
                                           DataBlock* block,
                                           const i64 lbid )
    { return readDBFile( cb, block->data, lbid );}

   /**
    * @brief Get an entry within a subblock and also populate block buffer
    *
    */
    EXPORT const int     readSubBlockEntry(FILE* pFile,
                                           DataBlock* block,
                                           const i64 lbid,
                                           const int sbid,
                                           const int entryNo,
                                           const int width,
                                           void* pStruct ) ;

    EXPORT const int     readSubBlockEntry(CommBlock& cb,
                                           DataBlock* block,
                                           const i64 lbid,
                                           const int sbid,
                                           const int entryNo,
                                           const int width,
                                           void* pStruct );

   /**
    * @brief Set an entry within a subblock
    */
    EXPORT void          setSubBlockEntry( unsigned char* blockBuf,
                                           const int sbid,
                                           const int entryNo,
                                           const int width,
                                           const void* pStruct ) ;

   /**
    * @brief Set an entry within a subblock using block information
    */
    void                 setSubBlockEntry( DataBlock* block,
                                           const int sbid,
                                           const int entryNo,
                                           const int width,
                                           const void* pStruct )
    { block->dirty = true;
      setSubBlockEntry( block->data, sbid, entryNo, width, pStruct ); }

   /**
    * @brief Lbid Write a buffer to a DB file
    */
    EXPORT virtual int   writeDBFile(      FILE* pFile,
                                           const unsigned char* writeBuf,
                                           const i64 lbid,
                                           const int numOfBlock = 1 );
    EXPORT int           writeDBFile(      CommBlock& cb,
                                           const unsigned char* writeBuf,
                                           const i64 lbid,
                                           const int numOfBlock = 1 );

   /**
    * @brief Write designated block(s) w/o writing to Version Buffer or cache.
    */
    EXPORT  int          writeDBFileNoVBCache(CommBlock & cb,
                                           const unsigned char * writeBuf,
                                           const int fbo,
                                           const int numOfBlock = 1);
    EXPORT virtual int   writeDBFileNoVBCache(FILE *pFile,
                                           const unsigned char * writeBuf,
                                           const int fbo,
                                           const int numOfBlock = 1);

    int                  writeDBFile(      FILE* pFile,
                                           DataBlock* block,
                                           const i64 lbid )
    { block->dirty=false; return writeDBFile( pFile, block->data, lbid ); }
    int                  writeDBFile(      CommBlock& cb,
                                           DataBlock* block,
                                           const i64 lbid )
    { return writeDBFile( cb, block->data, lbid ); }

    EXPORT virtual int   writeDBFileFbo(   FILE* pFile,
                                           const unsigned char* writeBuf,
                                           const i64 fbo,
                                           const int numOfBlock  );

    int                  writeDBFileNoVBCache(CommBlock & cb,
                                           DataBlock * block,
                                           const int fbo)
    { return writeDBFileNoVBCache(cb, block->data, fbo); }

   /**
    * @brief Write a sub block entry directly to a DB file
    */
    EXPORT const int     writeSubBlockEntry(FILE* pFile,
                                           DataBlock* block,
                                           const i64 lbid,
                                           const int sbid,
                                           const int entryNo,
                                           const int width,
                                           void* pStruct );

    EXPORT const int     writeSubBlockEntry(CommBlock& cb,
                                           DataBlock* block,
                                           const i64 lbid,
                                           const int sbid,
                                           const int entryNo,
                                           const int width,
                                           void* pStruct ) ;

   /**
    * @brief Write to version buffer
    */
    EXPORT const int     writeVB(          FILE* pFile,
                                           const OID oid,
                                           const i64 lbid );

    EXPORT virtual int   readDbBlocks(     FILE* pFile,
                                           unsigned char* readBuf,
                                           i64 fbo,
                                           size_t n);

    EXPORT virtual int   restoreBlock(     FILE* pFile,
                                           const unsigned char* writeBuf,
                                           i64 fbo);

    EXPORT virtual FILE* getFilePtr(       const Column& column);

    virtual void chunkManager(ChunkManager* ptr) { m_chunkManager = ptr;  }
    virtual ChunkManager* chunkManager()         { return m_chunkManager; }

protected:
    ChunkManager*        m_chunkManager;

private:

};

} //end of namespace

#undef EXPORT

#endif // _WE_DBFILEOP_H_
