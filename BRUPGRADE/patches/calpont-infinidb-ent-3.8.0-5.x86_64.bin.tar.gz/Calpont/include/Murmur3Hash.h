#ifndef MURMUR_3_HASH_H
#define MURMUR_3_HASH_H
#include <inttypes.h>
#include <iostream>

#ifdef TESTING_WITH_GTEST
#include "gtest/gtest.h"
#endif //TESTING_WITH_GTEST

inline uint32_t rotl32 ( uint32_t x, int8_t r )
{
  return (x << r) | (x >> (32 - r));
}

inline uint64_t rotl64 ( uint64_t x, int8_t r )
{
  return (x << r) | (x >> (64 - r));
}

#define ROTL32(x,y) rotl32(x,y)
#define ROTL64(x,y) rotl64(x,y)

namespace Murmur3Hash
{
  struct State
  {
          int64_t h1;
          int64_t h2;
          int64_t k1;
          int64_t k2;
          int64_t c1;
          int64_t c2;
  };

  typedef int8_t byte;

  static long getblock(byte key[], int i) {
          return
                  (((long) key[i + 0] & 0x00000000000000FF) << 0)
                  | (((long) key[i + 1] & 0x00000000000000FF) << 8)
                  | (((long) key[i + 2] & 0x00000000000000FF) << 16)
                  | (((long) key[i + 3] & 0x00000000000000FF) << 24)
                  | (((long) key[i + 4] & 0x00000000000000FF) << 32)
                  | (((long) key[i + 5] & 0x00000000000000FF) << 40)
                  | (((long) key[i + 6] & 0x00000000000000FF) << 48)
                  | (((long) key[i + 7] & 0x00000000000000FF) << 56);
  }

  static void bmix(State & state) {
          state.k1 *= state.c1;
          state.k1 = (state.k1 << 23) | ((uint64_t)state.k1 >> 64 - 23);
          state.k1 *= state.c2;
          state.h1 ^= state.k1;
          state.h1 += state.h2;
          state.h2 = (state.h2 << 41) | ((uint64_t)state.h2 >> 64 - 41);
          state.k2 *= state.c2;
          state.k2 = (state.k2 << 23) | ((uint64_t)state.k2 >> 64 - 23);
          state.k2 *= state.c1;
          state.h2 ^= state.k2;
          state.h2 += state.h1;
          state.h1 = state.h1 * 3 + 0x52dce729;
          state.h2 = state.h2 * 3 + 0x38495ab5;
          state.c1 = state.c1 * 5 + 0x7b7d159c;
          state.c2 = state.c2 * 5 + 0x6bce6396;
  }

  static long fmix(long k) {
          k ^= (uint64_t)k >> 33;
          k *= 0xff51afd7ed558ccd;
          k ^= (uint64_t)k >> 33;
          k *= 0xc4ceb9fe1a85ec53;
          k ^= (uint64_t)k >> 33;
          return k;
  }

  static void MurmurHash3_x64_128(byte key[], const int len, const int32_t seed, int64_t * out)
  {
	  State state;
	  state.h1 = 0x9368e53c2f6af274 ^ seed;
	  state.h2 = 0x586dcd208f7cd3fd ^ seed;
	  state.c1 = 0x87c37b91114253d5;
	  state.c2 = 0x4cf5ad432745937f;
	  for (int i = 0; i < len / 16; i++) {
		  state.k1 = getblock(key, i * 2 * 8);
		  state.k2 = getblock(key, (i * 2 + 1) * 8);
		  bmix(state);
	  }
	  state.k1 = 0;
	  state.k2 = 0;
	  int tail = ((uint32_t)len >> 4) << 4;
	  switch (len & 15) {
		  case 15: state.k2 ^= (long) key[tail + 14] << 48;
		  case 14: state.k2 ^= (long) key[tail + 13] << 40;
		  case 13: state.k2 ^= (long) key[tail + 12] << 32;
		  case 12: state.k2 ^= (long) key[tail + 11] << 24;
		  case 11: state.k2 ^= (long) key[tail + 10] << 16;
		  case 10: state.k2 ^= (long) key[tail + 9] << 8;
		  case 9:  state.k2 ^= (long) key[tail + 8] << 0;
		  case 8:  state.k1 ^= (long) key[tail + 7] << 56;
		  case 7:  state.k1 ^= (long) key[tail + 6] << 48;
		  case 6:  state.k1 ^= (long) key[tail + 5] << 40;
		  case 5:  state.k1 ^= (long) key[tail + 4] << 32;
		  case 4:  state.k1 ^= (long) key[tail + 3] << 24;
		  case 3:  state.k1 ^= (long) key[tail + 2] << 16;
		  case 2:  state.k1 ^= (long) key[tail + 1] << 8;
		  case 1:  state.k1 ^= (long) key[tail + 0] << 0;
			   bmix(state);
	  }
	  state.h2 ^= len;
	  state.h1 += state.h2;
	  state.h2 += state.h1;
	  state.h1 = fmix(state.h1);
	  state.h2 = fmix(state.h2);
	  state.h1 += state.h2;
	  state.h2 += state.h1;

	  out[0] = state.h1;
	  out[1] = state.h2;
  }

  static void MurmurHash3_x64_128m(byte key[], const int len, const int32_t seed, int64_t * out)
  {
	  State state;
	  const uint8_t * data = (const uint8_t*)key;
	  const int nblocks = len / 16;
	  state.h1 = 0x9368e53c2f6af274 ^ seed;
	  state.h2 = 0x586dcd208f7cd3fd ^ seed;

	  state.c1 = 0x87c37b91114253d5;
	  state.c2 = 0x4cf5ad432745937f;

	  //----------
	  // body
	  for(int i = 0; i < nblocks; i++)
	  {
		  state.k1 = getblock(key,i * 2 * 8);
		  state.k2 = getblock(key,(i * 2 + 1) * 8);

		  state.k1 *= state.c1;
		  state.k1  = ROTL64(state.k1,23);
		  state.k1 *= state.c2;

		  state.k2 *= state.c2;
		  state.k2  = ROTL64(state.k2,23);
		  state.k2 *= state.c1;


		  state.h1 ^= state.k1;
		  state.h1 += state.h2;
		  state.h2 = ROTL64(state.h2,41);
		  state.h2 ^= state.k2;

		  state.h2 += state.h1;

		  state.h1 = state.h1 * 3 + 0x52dce729;
		  state.h2 = state.h2 * 3 + 0x38495ab5;
		  state.c1 = state.c1 * 5 + 0x7b7d159c;
		  state.c2 = state.c2 * 5 + 0x6bce6396;
	  }

	  //----------
	  // tail

	  const int8_t * tail = (const int8_t*)(data + nblocks*16);

	  state.k1 = 0;
	  state.k2 = 0;

	  switch(len & 15)
	  {
		  case 15: state.k2 ^= (int64_t)tail[14] << 48;
		  case 14: state.k2 ^= (int64_t)tail[13] << 40;
		  case 13: state.k2 ^= (int64_t)tail[12] << 32;
		  case 12: state.k2 ^= (int64_t)tail[11] << 24;
		  case 11: state.k2 ^= (int64_t)tail[10] << 16;
		  case 10: state.k2 ^= (int64_t)tail[ 9] << 8;
		  case  9: state.k2 ^= (int64_t)tail[ 8] << 0;
			   state.k2 *= state.c2;
			   state.k2  = ROTL64(state.k2,23);
			   state.k2 *= state.c1;

		  case  8: state.k1 ^= (int64_t)tail[ 7] << 56;
		  case  7: state.k1 ^= (int64_t)tail[ 6] << 48;
		  case  6: state.k1 ^= (int64_t)tail[ 5] << 40;
		  case  5: state.k1 ^= (int64_t)tail[ 4] << 32;
		  case  4: state.k1 ^= (int64_t)tail[ 3] << 24;
		  case  3: state.k1 ^= (int64_t)tail[ 2] << 16;
		  case  2: state.k1 ^= (int64_t)tail[ 1] << 8;
		  case  1: state.k1 ^= (int64_t)tail[ 0] << 0;
			   state.k1 *= state.c1;
			   state.k1  = ROTL64(state.k1,23);
			   state.k1 *= state.c2;

			   state.h1 ^= state.k1;
			   state.h1 += state.h2;
			   state.h2 = ROTL64(state.h2,41);
			   state.h2 ^= state.k2;

			   state.h2 += state.h1;
			   state.h1 = state.h1 * 3 + 0x52dce729;
			   state.h2 = state.h2 * 3 + 0x38495ab5;
	  };

	  //----------
	  // finalization

	  state.h2 ^= len;
	  state.h1 += state.h2;
	  state.h2 += state.h1;

	  state.h1 = fmix(state.h1);
	  state.h2 = fmix(state.h2);

	  state.h1 += state.h2;
	  state.h2 += state.h1;

	  ((uint64_t*)out)[0] = state.h1;
	  ((uint64_t*)out)[1] = state.h2;

  }


}

#ifdef TESTING_WITH_GTEST
TEST(Murmur3Hash, HashCorrectnessTest)
{
	int64_t input;
	int64_t hashUsing128[2];
	int64_t hashUsing128m[2];
	for(input = 0; input < 100000000L;++input)
	{
		Murmur3Hash::MurmurHash3_x64_128(reinterpret_cast<int8_t *>(&input), 8, 0, hashUsing128);
		Murmur3Hash::MurmurHash3_x64_128m(reinterpret_cast<int8_t *>(&input), 8, 0, hashUsing128m);
		ASSERT_TRUE(hashUsing128[0] == hashUsing128m[0]);
	}
}
#endif //TESTING_WITH_GTEST
#endif //MURMUR_3_HASH_H
