/*

Copyright (C) 2009-2011 Calpont Corporation.

Use of and access to the Calpont InfiniDB Community software is subject to the
terms and conditions of the Calpont Open Source License Agreement. Use of and
access to the Calpont InfiniDB Enterprise software is subject to the terms and
conditions of the Calpont End User License Agreement.

This program is distributed in the hope that it will be useful, and unless
otherwise noted on your license agreement, WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Please refer to the Calpont Open Source License Agreement and the Calpont End
User License Agreement for more details.

You should have received a copy of either the Calpont Open Source License
Agreement or the Calpont End User License Agreement along with this program; if
not, it is your responsibility to review the terms and conditions of the proper
Calpont license agreement by visiting http://www.calpont.com for the Calpont
InfiniDB Enterprise End User License Agreement or http://www.infinidb.org for
the Calpont InfiniDB Community Calpont Open Source License Agreement.

Calpont may make changes to these license agreements from time to time. When
these changes are made, Calpont will make a new copy of the Calpont End User
License Agreement available at http://www.calpont.com and a new copy of the
Calpont Open Source License Agreement available at http:///www.infinidb.org.
You understand and agree that if you use the Program after the date on which
the license agreement authorizing your use has changed, Calpont will treat your
use as acceptance of the updated License.

*/

//
// $Id: deliverywsdl.h 7396 2011-02-03 17:54:36Z rdempsey $
// C++ Interface: deliverywsdl
//
// Description: 
//
//
// Author: Patrick LeBlanc <pleblanc@calpont.com>, (C) 2008
//
// Copyright: See COPYING file that comes with this distribution
//
//

#include "elementtype.h"
#include "calpontsystemcatalog.h"
#include <boost/shared_ptr.hpp>
#include <vector>

#ifndef _DELIVERYWSDL_H_
#define _DELIVERYWSDL_H_

namespace joblist
{

/* What should the element type be?  Might be a benefit to using rowgroups */

class DeliveryWSDL : public DataList<ElementType>
{
	public:
		enum ElementMode {
			RID_ONLY,
			RID_VALUE
		};

		DeliveryWSDL(uint numConsumers, uint FIFOMaxElements, uint WSDLMaxElements,
			uint32_t elementSaveSize1st, uint32_t elementSaveSize2nd,
			ResourceManager& rm, execplan::CalpontSystemCatalog::OID tOID,
			execplan::CalpontSystemCatalog::OID *projectingTable);
		virtual ~DeliveryWSDL();

		inline void insert(const ElementType &);
		inline void insert(const std::vector<ElementType> &v);
		uint64_t getIterator();
		inline bool next(uint64_t it, ElementType *e);
		void endOfInput();
		void setMultipleProducers(bool);
		uint32_t getNumConsumers();

		/* Element mode is not currently implemented by DeliveryWSDL. The   */
		/* internal WSDL is always created using ElementType (rid/value).   */
		/* But the mode should still be set in a DeliveryWSDL datalist, in  */
		/* case the datalist is later converted to a ZDL. In that case the  */
		/* element mode may be copied over and used by the ZDL.             */
		void setElementMode(uint mode);
		uint getElementMode() const;

		/* disk I/O accessors */
		bool useDisk();
		void setDiskElemSize(uint32_t size1st,uint32_t size2nd);
		uint32_t getDiskElemSize1st() const;
		uint32_t getDiskElemSize2nd() const;
		uint64_t numberOfTempFiles() const;
		void traceOn(bool b);
        std::list<DiskIoInfo>& diskIoList();
		bool totalDiskIoTime(uint64_t& w, uint64_t& r);
		void totalFileCounts(uint64_t& numFiles, uint64_t& numBytes) const;
		uint64_t totalSize();


	private:
		DeliveryWSDL();
		DeliveryWSDL(const DeliveryWSDL &);
		DeliveryWSDL & operator=(const DeliveryWSDL &);

		boost::shared_ptr<WSDL<ElementType> > wsdl;
		boost::shared_ptr<FIFO<ElementType> > fifo;

		bool doneInsertingIntoWSDL;
		bool deliveringWSDL;
		execplan::CalpontSystemCatalog::OID *projectingTableOID;
		execplan::CalpontSystemCatalog::OID tableOID;

		uint fElementMode;
};

inline void DeliveryWSDL::insert(const ElementType &e)
{
	if (*projectingTableOID == tableOID) {
		if (!doneInsertingIntoWSDL) {
			wsdl->endOfInput();
			doneInsertingIntoWSDL = true;
		}
		fifo->insert(e);
	}
	else
		wsdl->insert(e);
}

inline void DeliveryWSDL::insert(const std::vector<ElementType> &v)
{
	if (*projectingTableOID == tableOID) {
		if (!doneInsertingIntoWSDL) {
			wsdl->endOfInput();
			doneInsertingIntoWSDL = true;
		}
		fifo->insert(v);
	}
	else
		wsdl->insert(v);
}

inline bool DeliveryWSDL::next(uint64_t it, ElementType *e)
{
	bool ret;

	if (deliveringWSDL) {
		ret = wsdl->next(it, e);
		if (!ret)
			deliveringWSDL = false;
		else
			return true;
	}
	return fifo->next(it, e);
}


};

#endif
