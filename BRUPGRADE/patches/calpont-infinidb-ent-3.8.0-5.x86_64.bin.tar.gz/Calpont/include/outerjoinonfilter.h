/*

Copyright (C) 2009-2011 Calpont Corporation.

Use of and access to the Calpont InfiniDB Community software is subject to the
terms and conditions of the Calpont Open Source License Agreement. Use of and
access to the Calpont InfiniDB Enterprise software is subject to the terms and
conditions of the Calpont End User License Agreement.

This program is distributed in the hope that it will be useful, and unless
otherwise noted on your license agreement, WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Please refer to the Calpont Open Source License Agreement and the Calpont End
User License Agreement for more details.

You should have received a copy of either the Calpont Open Source License
Agreement or the Calpont End User License Agreement along with this program; if
not, it is your responsibility to review the terms and conditions of the proper
Calpont license agreement by visiting http://www.calpont.com for the Calpont
InfiniDB Enterprise End User License Agreement or http://www.infinidb.org for
the Calpont InfiniDB Community Calpont Open Source License Agreement.

Calpont may make changes to these license agreements from time to time. When
these changes are made, Calpont will make a new copy of the Calpont End User
License Agreement available at http://www.calpont.com and a new copy of the
Calpont Open Source License Agreement available at http:///www.infinidb.org.
You understand and agree that if you use the Program after the date on which
the license agreement authorizing your use has changed, Calpont will treat your
use as acceptance of the updated License.

*/

/***********************************************************************
*   $Id: outerjoinonfilter.h 8326 2012-02-15 18:58:10Z xlou $
*
*
***********************************************************************/
/** @file */

#ifndef OUTERJOINONFILTER_H
#define OUTERJOINONFILTER_H
#include <string>

#include "filter.h"
#include "calpontselectexecutionplan.h"

/**
 * Namespace
 */
namespace execplan { 
/**
 * @brief A class to represent a outer join on clause
 *
 * This class is a specialization of class Filter that handles a
 * outer join on clause like t1 left join t2 on (t1.c1=t2.c1 and t1.c2 < t2.c2)
 */
class OuterJoinOnFilter : public Filter {
/**
 * Public stuff
 */
public:
	/**
	 * Constructors
	 */
	OuterJoinOnFilter();
	OuterJoinOnFilter(const SPTP& pt);
	OuterJoinOnFilter(const OuterJoinOnFilter& rhs);
	virtual ~OuterJoinOnFilter();
	
	/**
	 * Accessor Methods
	 */
	const SPTP& pt() const { return fPt; }	
	void pt (SPTP& pt) { fPt = pt; }

	/**
	 * Overloaded stream operator
	 */
	//virtual std::ostream& operator<< (std::ostream& output);
	virtual const std::string toString() const;
	
	/**
	 * The serialization interface
	 */
	virtual void serialize(messageqcpp::ByteStream&) const;
	virtual void unserialize(messageqcpp::ByteStream&);
	
	/** return a copy of this pointer
	 *
	 * deep copy of this pointer and return the copy
	 */	
	inline virtual OuterJoinOnFilter* clone() const
	{
	    return new OuterJoinOnFilter (*this);
	}	
	
	/** @brief Do a deep, strict (as opposed to semantic) equivalence test
	 *
	 * Do a deep, strict (as opposed to semantic) equivalence test.
	 * @return true iff every member of t is a duplicate copy of every member of this; false otherwise
	 */
	virtual bool operator==(const TreeNode* t) const;
	
	/** @brief Do a deep, strict (as opposed to semantic) equivalence test
	 *
	 * Do a deep, strict (as opposed to semantic) equivalence test.
	 * @return true iff every member of t is a duplicate copy of every member of this; false otherwise
	 */
	bool operator==(const OuterJoinOnFilter& t) const;
	
	/** @brief Do a deep, strict (as opposed to semantic) equivalence test
	 *
	 * Do a deep, strict (as opposed to semantic) equivalence test.
	 * @return false iff every member of t is a duplicate copy of every member of this; true otherwise
	 */
	virtual bool operator!=(const TreeNode* t) const;
	 
	/** @brief Do a deep, strict (as opposed to semantic) equivalence test
	 *
	 * Do a deep, strict (as opposed to semantic) equivalence test.
	 * @return false iff every member of t is a duplicate copy of every member of this; true otherwise
	 */
	bool operator!=(const OuterJoinOnFilter& t) const;

private:
	//default okay?
	//OuterJoinOnFilter& operator=(const OuterJoinOnFilter& rhs);
	SPTP fPt;
	std::string fData;
};

std::ostream& operator<<(std::ostream& output, const OuterJoinOnFilter& rhs);

} 
#endif //OUTERJOINONFILTER_H

