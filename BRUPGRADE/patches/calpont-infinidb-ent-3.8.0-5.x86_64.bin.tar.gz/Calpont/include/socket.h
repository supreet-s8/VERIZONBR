/*

Copyright (C) 2009-2011 Calpont Corporation.

Use of and access to the Calpont InfiniDB Community software is subject to the
terms and conditions of the Calpont Open Source License Agreement. Use of and
access to the Calpont InfiniDB Enterprise software is subject to the terms and
conditions of the Calpont End User License Agreement.

This program is distributed in the hope that it will be useful, and unless
otherwise noted on your license agreement, WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Please refer to the Calpont Open Source License Agreement and the Calpont End
User License Agreement for more details.

You should have received a copy of either the Calpont Open Source License
Agreement or the Calpont End User License Agreement along with this program; if
not, it is your responsibility to review the terms and conditions of the proper
Calpont license agreement by visiting http://www.calpont.com for the Calpont
InfiniDB Enterprise End User License Agreement or http://www.infinidb.org for
the Calpont InfiniDB Community Calpont Open Source License Agreement.

Calpont may make changes to these license agreements from time to time. When
these changes are made, Calpont will make a new copy of the Calpont End User
License Agreement available at http://www.calpont.com and a new copy of the
Calpont Open Source License Agreement available at http:///www.infinidb.org.
You understand and agree that if you use the Program after the date on which
the license agreement authorizing your use has changed, Calpont will treat your
use as acceptance of the updated License.

*/

/***********************************************************************
*   $Id: socket.h 2436 2011-03-07 17:48:38Z pleblanc $
*
*
***********************************************************************/
/** @file */
#ifndef MESSAGEQCPP_SOCKET_H
#define MESSAGEQCPP_SOCKET_H

#include <ctime>
#include <unistd.h>
#include <sys/types.h>
#include <boost/shared_ptr.hpp>

class MessageQTestSuite;

namespace messageqcpp { 
class ByteStream;
class IOSocket;
class SocketParms;

typedef boost::shared_ptr<ByteStream> SBS;

/** an abstract socket class interface
 *
 */
class Socket
{
public:
	/** dtor
	 *
	 */
	virtual ~Socket() {}

	/** open the socket
	 *
	 */
	virtual void open() = 0;

	/** read a message from the socket
	 * 
	 * wait for and return a message from the socket. The deafult timeout waits forever. Note that
	 * eventhough struct timespec has nanosecond resolution, this method only has milisecond resolution.
	 */
	virtual const SBS read(const struct timespec* timeout=0, bool* isTimeOut = NULL) const = 0;

	/** write a message to the socket
	 * 
	 * write a message to the socket
	 */
	virtual void write(const ByteStream& msg) const = 0;
	virtual void write_raw(const ByteStream& msg) const = 0;

	/** close the socket
	 *
	 */
	virtual void close() = 0;

	/** bind to a port
	 *
	 */
	virtual void bind(const struct sockaddr_in* serv_addr) = 0;

	/** listen for connections
	 *
	 */
	virtual void listen(int backlog=5) = 0;

	/** return an (accepted) IOSocket ready for I/O
	 *
	 */
	virtual const IOSocket accept(const struct timespec* timeout=0) = 0;

	/** connect to a server socket
	 *
	 */
	virtual void connect(const struct sockaddr_in* serv_addr) = 0;

	/** test if this socket is open
	 *
	 */
	virtual bool isOpen() const = 0;

	/** get the SocketParms
	 *
	 */
	virtual const SocketParms& socketParms() const = 0;

	/** set the SocketParms
	 *
	 */
	virtual void socketParms(const SocketParms& socketParms) = 0;

	/** set the sockaddr struct
	 *
	 */
	virtual void sa(const sockaddr_in& sa) = 0;

	/** dynamically allocate a copy of this object
	 *
	 */
	virtual Socket* clone() const = 0;

	/** set the connection timeout (in ms)
	 *
	 */
	virtual void connectionTimeout(const struct ::timespec* timeout) = 0;

	/** set the connection protocol to be synchronous
	 *
	 */
	virtual void syncProto(bool use) = 0;

	virtual int getConnectionNum() const = 0;

	/*
	 * allow test suite access to private data for OOB test
	 */
	friend class ::MessageQTestSuite;

};

} //namespace messageqcpp

#endif //MESSAGEQCPP_SOCKET_H

