// Concurrent Flows Library
// Nikhil S. Ketkar, nikhil.ketkar@guavus.com

#ifndef KMEANS_H
#define KMEANS_H

#include <string>
#include <set>
#include <vector>
#include <set>
#include <iostream>
#include <cmath>
#include <limits>

#include "boost/shared_ptr.hpp"
#include "boost/unordered_map.hpp"
#include "boost/unordered_set.hpp"

#include "ConcurrentFlowException.h"
namespace ConcurrentFlows
{

#define MIN_VALUE_CHANGE 0.0000001f

class KMeans
{
public:
	KMeans(const std::vector<float>& givenInput, unsigned int givenLevelCount, 
			unsigned int givenMaxIterations, bool givenWeighted){
		input = givenInput;
		levelCount = givenLevelCount;
		maxIterations = givenMaxIterations;
		computationDone = false;
		weighted = givenWeighted;
	}
	
	void compute(){
		if (computationDone){
			return;
		}else{
			levels.resize(levelCount);
			computeUniqueCountAndMax();
			if (isKMeansNeeded()){
				KMeansComputation();
			}else{
				noKMeansComputation();
			}
			computationDone = true;
		}
	}

	void getOutput(std::vector<unsigned int>& result){
		result = output;
	}

	void getLevels(std::vector<float>& result){
		result = levels;
	}

private:
	std::vector<float> levels;
	std::vector<unsigned int> output;
	std::vector<float> input;
	unsigned int levelCount;
	unsigned int maxIterations;
	unsigned int uniqueCount;
	float maxInputValue;
	float minInputValue;
	bool computationDone;
	bool weighted;
	std::set<unsigned int> uniqueValue;
	boost::unordered_map<unsigned int, unsigned int> levelAssignment;


	/**
	 * This function just pick the unique values as levels and fills any remaining with zeros
	 * */
	void noKMeansComputation(){
		unsigned int pos = 0;
		for (std::set<unsigned int>::const_iterator i = uniqueValue.begin(); i!= uniqueValue.end(); ++i){
			levels[pos] = *i;
			pos++;
		}

		while (pos < levelCount){
			levels[pos] = 0;
			pos++;
		}
		assignToLevels();
		generateResult();
	}

	void KMeansComputation(){
		computeInitialLevels();
		assignToLevels();
		for (unsigned int i = 0; i < maxIterations; i++){
			std::vector<float> oldLevels;
			getLevelsCopy(oldLevels);
			computeNewLevels();
			assignToLevels();
			if(!changeInLevels(oldLevels)){
				break;
			}
			if(getDiffWithOldLevels(oldLevels) < MIN_VALUE_CHANGE){
				break;
			}
		}
		generateResult();
	}

	bool changeInLevels(std::vector<float> oldLevels){
		for(int i = 0; i < levels.size(); i++){
			if(fabs(oldLevels[i]-levels[i])>MIN_VALUE_CHANGE){
				return true;
			}   
		}
		return false;
	}

	float getDiffWithOldLevels(const std::vector<float> oldLevels){
		float diff = 0;
		for (unsigned int i = 0; i < levels.size(); ++i){
			diff += fabs(oldLevels[i]-levels[i]);
		}
		return diff/levels.size();
	}

	void assignToLevels(){
		// sort the series
		std::sort(levels.begin(), levels.end());
		for (unsigned int i = 0; i < input.size(); i++){
			float leastDifference = std::numeric_limits<float>::max();
			unsigned int leastDifferencePosition = 0;
			/* as far as I can make out, levels array is sorted, use binary
			 * search to find the closest level, after all this is a heavily used
			 * function */
			for (unsigned int j = 0; j < levels.size(); j++){
				float currDifference = fabs(input[i] - levels[j]);
				if (currDifference < leastDifference){
					leastDifference = currDifference;
					leastDifferencePosition = j;
				}
			}
			std::pair<boost::unordered_map<unsigned int,unsigned int>::iterator,bool> ret = levelAssignment.insert(std::make_pair(i, leastDifferencePosition));
			if (ret.second == false){
				/* if we need to force the pair <i, leastDifferencePosition> in
				 * the map anyways, why not use the operator[] in the first
				 * place instead of the insert() ?? */
				levelAssignment[i] = leastDifferencePosition;
			}
		}
	}

	/* intial levels are spread linearly */
	void computeInitialLevels(){
		float increment = (maxInputValue-minInputValue)/levelCount;
		for (unsigned int i = 0; i < levelCount; ++i)
		  levels[i] = minInputValue+(i*increment);
	}

	void computeDefaultCentroids(std::vector<float> &centroids){
		std::vector<float> uniqueArray;
		uniqueArray.resize(uniqueValue.size());
		unsigned int pos = 0;
		for (std::set<unsigned int>::const_iterator i = uniqueValue.begin(); i!= uniqueValue.end(); ++i){
			uniqueArray[pos] = *i;
			pos++;
		}
		std::sort(uniqueArray.begin(), uniqueArray.end());
		/*increment has to be greater than 1.0*/
		float increment = (float) (uniqueArray.size()*1.0/centroids.size()); 

		unsigned startIndex = 0, endIndex=0, index = 0;
		for (unsigned int i = 0; i < centroids.size(); i++){
			endIndex = (unsigned int)ceil(startIndex+increment);
			index=(startIndex+endIndex)/2;
			if (index >= uniqueValue.size()){
				centroids[i] = 0;
			}else{
				centroids[i] = uniqueArray[index];
			}
			startIndex=endIndex;
		}
	}



	void generateResult(){
		output.resize(input.size());
		for (unsigned int i = 0; i < input.size(); ++i){
			output[i] = levelAssignment[i];
		}
	}

	void getLevelsCopy(std::vector<float>& result){
		result.resize(levels.size());
		for (unsigned int i = 0; i < levels.size(); ++i){
			result[i] = levels[i];
		}
	}

	void computeNewLevels(){
		std::vector<float> levelAssignmentCount;
		levelAssignmentCount.resize(levels.size());
		/* why not use the assign function available in the std::vector? it is
		 * ideal for this but might do it more optimally.
		 * for levelAssignmentCount, you can use the second (optional) argument
		 * in resize to fill it in. By default the elements get set to zero
		 * anyways. Save the memory writes if you can */
		for (unsigned int i = 0; i < levels.size(); i++){
			levels[i] = 0;
			levelAssignmentCount[i] = 0;
		}

		for (unsigned int i = 0; i < input.size(); i++){
			int pos = levelAssignment[i];
			if(weighted){
				levels[pos] += input[i]*input[i];
				levelAssignmentCount[pos] += input[i];
			}else{
				levels[pos] += input[i];
				levelAssignmentCount[pos] += 1;
			}
		}

		/*If two centroids have same value; only one centroid will get all points assigned to it*/
		int nonZeroClusters = 0;
		for (unsigned int i = 0; i < levels.size(); i++){
			if (levelAssignmentCount[i] !=0){
				levels[i] /= levelAssignmentCount[i];
				nonZeroClusters++;
			}
		}

		if (nonZeroClusters < levelCount){
			std::vector<float> newCentroids;
			newCentroids.resize(levelCount-nonZeroClusters);
			computeDefaultCentroids(newCentroids);
			for (int i = 0, index = 0; i < levels.size(); i++){
				if (levelAssignmentCount[i]==0){
					levels[i] = newCentroids[index++];
					nonZeroClusters++;
				}
			}
		}
		
		if (nonZeroClusters  < levelCount){
			throw ConcurrentFlowException(" Some error occurred while doing kMeans.");
		}
	}

	bool isKMeansNeeded(){
		return (uniqueCount > levelCount);
	}

	void computeUniqueCountAndMax(){
		maxInputValue = std::numeric_limits<float>::min();
		minInputValue = std::numeric_limits<float>::max();
		for (unsigned int i = 0; i < input.size(); ++i){
			unsigned int roundedValue = round(input[i]);
			uniqueValue.insert(roundedValue);
			if (maxInputValue < roundedValue)
				maxInputValue = roundedValue;
			if (minInputValue > roundedValue)
				minInputValue = roundedValue;
		}
		uniqueCount = uniqueValue.size();
	}

};

} // namespace ConcurrentFlows

#ifdef TESTING_WITH_GTEST

TEST(KMeans, NoKMeans)
{
	std::vector<float> input;
	input.push_back(1);
	input.push_back(2);
	input.push_back(3);
	input.push_back(4);
	input.push_back(5);
	input.push_back(1);
	input.push_back(2);
	input.push_back(3);
	input.push_back(4);
	input.push_back(5);

	ConcurrentFlows::KMeans kMeans(input, 16, 10, false);
	kMeans.compute();

	std::vector<float >resultLevels;
	kMeans.getLevels(resultLevels);
	std::vector<unsigned int> resultSeries;
	kMeans.getOutput(resultSeries);

	ASSERT_TRUE(fabs(resultLevels[0]) == 0 );
	ASSERT_TRUE(fabs(resultLevels[1]) == 0 );
	ASSERT_TRUE(fabs(resultLevels[2]) == 0 );
	ASSERT_TRUE(fabs(resultLevels[3]) == 0 );
	ASSERT_TRUE(fabs(resultLevels[4]) == 0 );
	ASSERT_TRUE(fabs(resultLevels[5]) == 0);
	ASSERT_TRUE(fabs(resultLevels[6]) == 0);
	ASSERT_TRUE(fabs(resultLevels[7]) == 0);
	ASSERT_TRUE(fabs(resultLevels[8]) == 0);
	ASSERT_TRUE(fabs(resultLevels[9]) == 0);
	ASSERT_TRUE(fabs(resultLevels[10]) == 0);
	ASSERT_TRUE(fabs(resultLevels[11] - 1.0) < 0.001);
	ASSERT_TRUE(fabs(resultLevels[12] - 2.0) < 0.001);
	ASSERT_TRUE(fabs(resultLevels[13] - 3.0) < 0.001);
	ASSERT_TRUE(fabs(resultLevels[14] - 4.0) < 0.001);
	ASSERT_TRUE(fabs(resultLevels[15] - 5.0) < 0.001);

	ASSERT_TRUE(resultSeries[0] == 11);
	ASSERT_TRUE(resultSeries[1] == 12);
	ASSERT_TRUE(resultSeries[2] == 13);
	ASSERT_TRUE(resultSeries[3] == 14);
	ASSERT_TRUE(resultSeries[4] == 15);
	ASSERT_TRUE(resultSeries[5] == 11);
	ASSERT_TRUE(resultSeries[6] == 12);
	ASSERT_TRUE(resultSeries[7] == 13);
	ASSERT_TRUE(resultSeries[8] == 14);
	ASSERT_TRUE(resultSeries[9] == 15);
}

TEST(KMeans, WithKMeans2)
{
	std::vector<float> input;
	input.push_back(1);
	input.push_back(2);
	input.push_back(3);
	input.push_back(4);
	input.push_back(5);
	input.push_back(6);
	input.push_back(50);
	input.push_back(51);
	input.push_back(52);
	input.push_back(53);
	input.push_back(54);

	ConcurrentFlows::KMeans kMeans(input, 5, 11, false);
	kMeans.compute();

	std::vector<unsigned int> resultSeries;
	kMeans.getOutput(resultSeries);
	std::vector<float> resultLevels;
	kMeans.getLevels(resultLevels);

	ASSERT_TRUE(fabs(resultLevels[0] - 2.0) < 0.001);
	ASSERT_TRUE(fabs(resultLevels[1] - 5.0) < 0.001);
	ASSERT_TRUE(fabs(resultLevels[2] - 50.50) < 0.001);
	ASSERT_TRUE(fabs(resultLevels[3] - 52.50) < 0.001);
	ASSERT_TRUE(fabs(resultLevels[4] - 54.00) < 0.001);

	ASSERT_TRUE(resultSeries[0] == 0);
	ASSERT_TRUE(resultSeries[1] == 0);
	ASSERT_TRUE(resultSeries[2] == 0);
	ASSERT_TRUE(resultSeries[3] == 1);
	ASSERT_TRUE(resultSeries[4] == 1);
	ASSERT_TRUE(resultSeries[5] == 1);
	ASSERT_TRUE(resultSeries[6] == 2);
	ASSERT_TRUE(resultSeries[7] == 2);
	ASSERT_TRUE(resultSeries[8] == 3);
	ASSERT_TRUE(resultSeries[9] == 3);
	ASSERT_TRUE(resultSeries[10] == 4);
}



TEST(KMeans, WithKMeans)
{
	std::vector<float> input;
	input.push_back(1);
	input.push_back(2);
	input.push_back(3);
	input.push_back(4);
	input.push_back(5);
	input.push_back(50);
	input.push_back(51);
	input.push_back(52);
	input.push_back(53);
	input.push_back(54);

	ConcurrentFlows::KMeans kMeans(input, 3, 10, false);
	kMeans.compute();

	std::vector<unsigned int> resultSeries;
	kMeans.getOutput(resultSeries);
	std::vector<float> resultLevels;
	kMeans.getLevels(resultLevels);

	ASSERT_TRUE(fabs(resultLevels[0] - 3.0) < 0.001);
	ASSERT_TRUE(fabs(resultLevels[1] - 50.50) < 0.001);
	ASSERT_TRUE(fabs(resultLevels[2] - 53.0) < 0.001);

	ASSERT_TRUE(resultSeries[0] == 0);
	ASSERT_TRUE(resultSeries[1] == 0);
	ASSERT_TRUE(resultSeries[2] == 0);
	ASSERT_TRUE(resultSeries[3] == 0);
	ASSERT_TRUE(resultSeries[4] == 0);
	ASSERT_TRUE(resultSeries[5] == 1);
	ASSERT_TRUE(resultSeries[6] == 1);
	ASSERT_TRUE(resultSeries[7] == 2);
	ASSERT_TRUE(resultSeries[8] == 2);
	ASSERT_TRUE(resultSeries[9] == 2);
}

TEST(KMeans, WeightedKMeansTest)
{
	std::vector<float> input;
	input.push_back(1);
	input.push_back(2);
	input.push_back(3);
	input.push_back(4);
	input.push_back(5);
	input.push_back(50);
	input.push_back(51);
	input.push_back(52);
	input.push_back(53);
	input.push_back(54);

	ConcurrentFlows::KMeans kMeans(input, 3, 10, true);
	kMeans.compute();

	std::vector<unsigned int> resultSeries;
	kMeans.getOutput(resultSeries);
	std::vector<float> resultLevels;
	kMeans.getLevels(resultLevels);

	ASSERT_TRUE(fabs(resultLevels[0] - 3.6666667) < 0.001);
	ASSERT_TRUE(fabs(resultLevels[1] - 50.50495) < 0.001);
	ASSERT_TRUE(fabs(resultLevels[2] - 53.012577) < 0.001);

	ASSERT_TRUE(resultSeries[0] == 0);
	ASSERT_TRUE(resultSeries[1] == 0);
	ASSERT_TRUE(resultSeries[2] == 0);
	ASSERT_TRUE(resultSeries[3] == 0);
	ASSERT_TRUE(resultSeries[4] == 0);
	ASSERT_TRUE(resultSeries[5] == 1);
	ASSERT_TRUE(resultSeries[6] == 1);
	ASSERT_TRUE(resultSeries[7] == 2);
	ASSERT_TRUE(resultSeries[8] == 2);
	ASSERT_TRUE(resultSeries[9] == 2);
}




#endif //TESTING_WITH_GTEST

#endif // KMEANS_H
