#ifndef OPTIMIZEDKMEANS_H
#define OPTIMIZEDKMEANS_H

#include <vector>
#include <cmath>
#include <algorithm>

#define LEVELS 16
#define ITERATIONS 10

namespace ConcurrentFlows
{
  class OptimizedKMeans
  {    

  public:

  OptimizedKMeans(unsigned int seriesLength): _seriesLength(seriesLength) 
      {
        assignment.resize(_seriesLength);
      }
    
    void compute(const std::vector<unsigned int>&  input, std::vector<unsigned int>&  output, std::vector<float>&  outputLevels)
    {
      wipeout();
      if (init(input))
        {
          unsigned int counter = 0;
          do
            {
              if (! assignToLevels(input))
                  break;
              computeLevels(input);
              counter++;
            } while (counter < ITERATIONS);
        }
      else
        assignToLevelsExact(input);

      copyOutput(output);
      copyLevels(outputLevels);
    }

    inline bool init(const std::vector<unsigned int>& input)
    {
      unsigned int uniqueValuesSeen = 0;
      float min = input[0];
      float max = input[0];
      for(unsigned int i = 0; i < _seriesLength; i++)
        {
          if (uniqueValuesSeen < LEVELS)
            uniqueValuesSeen = exactMatchAndInsertIfAbsent(input[i], uniqueValuesSeen);
            
          if(max < input[i]) max = input[i];
          if(min > input[i]) min = input[i];
        }

      if (uniqueValuesSeen < LEVELS)
        {
          return false;
        }
      else
        {
          float increment = (max - min)/(LEVELS - 2);
          levels[0] = min;
          levels[1] = min + (increment * 1);
          levels[2] = min + (increment * 2);
          levels[3] = min + (increment * 3);
          levels[4] = min + (increment * 4);
          levels[5] = min + (increment * 5);
          levels[6] = min + (increment * 6);
          levels[7] = min + (increment * 7);
          levels[8] = min + (increment * 8);
          levels[9] = min + (increment * 9);
          levels[10] = min + (increment * 10);
          levels[11] = min + (increment * 11);
          levels[12] = min + (increment * 12);
          levels[13] = min + (increment * 13);
          levels[14] = min + (increment * 14);
          levels[15] = max;
          return true;
        }      
    }

    inline void computeLevels(const std::vector<unsigned int>& input)
    {
      for(unsigned int i = 0; i < _seriesLength; i++)
        {
          accumulator[assignment[i]] += input[i];
          (counts[assignment[i]])++;
        }
      
        if(counts[0] > 0) levels[0] = accumulator[0]/counts[0];      
        if(counts[1] > 0) levels[1] = accumulator[1]/counts[1];      
        if(counts[2] > 0) levels[2] = accumulator[2]/counts[2];      
        if(counts[3] > 0) levels[3] = accumulator[3]/counts[3];      
        if(counts[4] > 0) levels[4] = accumulator[4]/counts[4];      
        if(counts[5] > 0) levels[5] = accumulator[5]/counts[5];      
        if(counts[6] > 0) levels[6] = accumulator[6]/counts[6];      
        if(counts[7] > 0) levels[7] = accumulator[7]/counts[7];      
        if(counts[8] > 0) levels[8] = accumulator[8]/counts[8];      
        if(counts[9] > 0) levels[9] = accumulator[9]/counts[9];      
        if(counts[10] > 0) levels[10] = accumulator[10]/counts[10];      
        if(counts[11] > 0) levels[11] = accumulator[11]/counts[11];      
        if(counts[12] > 0) levels[12] = accumulator[12]/counts[12];      
        if(counts[13] > 0) levels[13] = accumulator[13]/counts[13];      
        if(counts[14] > 0) levels[14] = accumulator[14]/counts[14];      
        if(counts[15] > 0) levels[15] = accumulator[15]/counts[15];      

    }

    inline bool assignToLevels(const std::vector<unsigned int>& input)
    {
      std::sort(levels, levels + LEVELS);
      bool assignmentChanged = false;
      for(unsigned int i = 0; i < _seriesLength; ++i)
        {
          unsigned int currClosestMatch = closestMatch(input[i]); 
          if (assignment[i] != currClosestMatch)
            {
              assignment[i] = currClosestMatch;
              assignmentChanged = true;
            }            
        }
      return true;
    }

    inline void assignToLevelsExact(const std::vector<unsigned int>& input)
    {
      std::sort(levels, levels + LEVELS);
      for(unsigned int i = 0; i < _seriesLength; ++i)
          assignment[i] = exactMatch(input[i]);
    }

    // Modification of binary search to do closest match instead of exact match
    inline unsigned int closestMatch(unsigned int key)
    {
    if(levels[0] > key)
      return 0;
    else if(levels[LEVELS - 1] < key)
      return (LEVELS - 1);

      unsigned int begin = 0;
      unsigned int end = LEVELS - 1;
    
      while(begin <= end)
        {
        unsigned int mid = (begin + end)/2;
        if(key > levels[mid])
          begin = mid + 1;
        else if(key < levels[mid])
          end = mid - 1;
        else 
          return mid;
      }
    
      if (fabs(levels[begin] - key) < fabs(levels[end] - key))
        return begin;
      else
        return end;
    }
    
    // Binary Search
    inline unsigned int exactMatch(unsigned int key) 
    {
      unsigned int first = 0;
      unsigned int last = LEVELS - 1;

      while (first <= last) 
        {
          unsigned int mid = (first + last) / 2;           
          if (key > levels[mid]) 
            first = mid + 1;  
          else if (key < levels[mid]) 
            last = mid - 1;
          else
            return mid; 
        }
      return -1; 
    }

    // Binary search followed by insersion if absent and sorting
    inline unsigned int exactMatchAndInsertIfAbsent(unsigned int key, unsigned int upto) 
    {
      unsigned int first = 0;
      unsigned int last = upto;

      while (first <= last) 
        {
          unsigned int mid = (first + last) / 2;           
          if (key > levels[mid]) 
            first = mid + 1;  
          else if (key < levels[mid]) 
            last = mid - 1;
          else
            return upto; 
        }
      
      // If the key is not found, the appropriate place to insert it is at first
      // Before we do that we move elements one place ahead one by one starting
      // with the last one
      for(unsigned int i = upto + 1; i > first; --i)
        levels[i] = levels[i - 1];
      levels[first] = key; 
      return upto + 1; 
    }

    inline void wipeout() 
    {
      levels[0] = 0; accumulator[0] = 0; counts[0] = 0;
      levels[1] = 0; accumulator[1] = 0; counts[1] = 0;
      levels[2] = 0; accumulator[2] = 0; counts[2] = 0;
      levels[3] = 0; accumulator[3] = 0; counts[3] = 0;
      levels[4] = 0; accumulator[4] = 0; counts[4] = 0;
      levels[5] = 0; accumulator[5] = 0; counts[5] = 0;
      levels[6] = 0; accumulator[6] = 0; counts[6] = 0;
      levels[7] = 0; accumulator[7] = 0; counts[7] = 0;
      levels[8] = 0; accumulator[8] = 0; counts[8] = 0;
      levels[9] = 0; accumulator[9] = 0; counts[9] = 0;
      levels[10] = 0; accumulator[10] = 0; counts[10] = 0;
      levels[11] = 0; accumulator[11] = 0; counts[11] = 0;
      levels[12] = 0; accumulator[12] = 0; counts[12] = 0;
      levels[13] = 0; accumulator[13] = 0; counts[13] = 0;
      levels[14] = 0; accumulator[14] = 0; counts[14] = 0;
      levels[15] = 0; accumulator[15] = 0; counts[15] = 0;
     }

    inline void copyOutput(std::vector<unsigned int>& output)
    {
      for(unsigned int i = 0; i < _seriesLength; ++i)
          output[i] = assignment[i];
    }

    inline void copyLevels(std::vector<float>& outputLevels)
    {
      outputLevels[0] = levels[0];
      outputLevels[1] = levels[1];
      outputLevels[2] = levels[2];
      outputLevels[3] = levels[3];
      outputLevels[4] = levels[4];
      outputLevels[5] = levels[5];
      outputLevels[6] = levels[6];
      outputLevels[7] = levels[7];
      outputLevels[8] = levels[8];
      outputLevels[9] = levels[9];
      outputLevels[10] = levels[10];
      outputLevels[11] = levels[11];
      outputLevels[12] = levels[12];
      outputLevels[13] = levels[13];
      outputLevels[14] = levels[14];
      outputLevels[15] = levels[15];
    }

    // To be used only through GDB
    void __attribute__ ((used)) debugPrint() const
    {
      std::cout << "Optimized KMeans Levels: ";
      for(unsigned int i = 0; i < LEVELS; i++)
        std::cout << levels[i] << " ";
      std::cout << "\n";
      for(unsigned int i = 0; i < _seriesLength; i++)
        std::cout << assignment[i] << " ";
      std::cout << "\n";
    }

  public:
    unsigned int counts[LEVELS];
    float accumulator[LEVELS];
    std::vector<unsigned int> assignment;
    unsigned int _seriesLength;
    float levels[LEVELS];
  };
} // namespace ConcurrentFlows


#ifdef TESTING_WITH_GTEST

TEST(OptimizedKMeans, NoKMeans)
{
  std::vector<unsigned int> input;
  input.push_back(1);
  input.push_back(2);
  input.push_back(3);
  input.push_back(4);
  input.push_back(5);
  input.push_back(1);
  input.push_back(2);
  input.push_back(3);
  input.push_back(4);
  input.push_back(5);

  std::vector<float >resultLevels;
  resultLevels.resize(16);
  std::vector<unsigned int> resultSeries;
  resultSeries.resize(10);

  ConcurrentFlows::OptimizedKMeans kMeans(10);
  kMeans.compute(input, resultSeries, resultLevels);

  ASSERT_TRUE(fabs(resultLevels[0] - 0.0) < 0.001);
  ASSERT_TRUE(fabs(resultLevels[1] - 0.0) < 0.001);
  ASSERT_TRUE(fabs(resultLevels[2] - 0.0) < 0.001);
  ASSERT_TRUE(fabs(resultLevels[3] - 0.0) < 0.001);
  ASSERT_TRUE(fabs(resultLevels[4] - 0.0) < 0.001);
  ASSERT_TRUE(fabs(resultLevels[5] - 0.0) < 0.001);
  ASSERT_TRUE(fabs(resultLevels[6] - 0.0) < 0.001);
  ASSERT_TRUE(fabs(resultLevels[7] - 0.0) < 0.001);
  ASSERT_TRUE(fabs(resultLevels[8] - 0.0) < 0.001);
  ASSERT_TRUE(fabs(resultLevels[9] - 0.0) < 0.001);
  ASSERT_TRUE(fabs(resultLevels[10] - 0.0) < 0.001);
  ASSERT_TRUE(fabs(resultLevels[11] - 1.0) < 0.001);
  ASSERT_TRUE(fabs(resultLevels[12] - 2.0) < 0.001);
  ASSERT_TRUE(fabs(resultLevels[13] - 3.0) < 0.001);
  ASSERT_TRUE(fabs(resultLevels[14] - 4.0) < 0.001);
  ASSERT_TRUE(fabs(resultLevels[15] - 5.0) < 0.001);

  ASSERT_TRUE(resultSeries[0] == 11);
  ASSERT_TRUE(resultSeries[1] == 12);
  ASSERT_TRUE(resultSeries[2] == 13);
  ASSERT_TRUE(resultSeries[3] == 14);
  ASSERT_TRUE(resultSeries[4] == 15);
  ASSERT_TRUE(resultSeries[5] == 11);
  ASSERT_TRUE(resultSeries[6] == 12);
  ASSERT_TRUE(resultSeries[7] == 13);
  ASSERT_TRUE(resultSeries[8] == 14);
  ASSERT_TRUE(resultSeries[9] == 15);
}

TEST(OptimizedKMeans, WithKMeans)
{
  std::vector<unsigned int> input;
  for(unsigned int i = 0; i < 16; i++)
    {
      input.push_back((10 * (i + 1)) - 1);
      input.push_back((10 * (i + 1)));
      input.push_back((10 * (i + 1)) + 1);
    }

  std::vector<float >resultLevels;
  resultLevels.resize(16);
  std::vector<unsigned int> resultSeries;
  resultSeries.resize(48);

  ConcurrentFlows::OptimizedKMeans kMeans(48);
  kMeans.compute(input, resultSeries, resultLevels);
       
  for(unsigned int i = 0; i < 48; i++)
    ASSERT_TRUE(fabs(input[i] - resultLevels[resultSeries[i]]) < 10);
}


#endif //TESTING_WITH_GTEST

#endif // OPTIMIZEDKMEANS_H
