#ifndef AVS_HALFPRECISIONFLOAT_H
#define AVS_HALFPRECISIONFLOAT_H

#include <string>
#include <vector>
#include <cmath>

namespace ATS
{

  class HPFConstants{

  public:
    static HPFConstants& getInstance(){
      // Guaranteed to be destroyed.
      // Instantiated on first use.
      static HPFConstants    instance;
      return instance;
    }
    int NUM_SIGNIFICAND_BITS;
    int SIGNIFICAND_MASK; 
    int MAX_SIGNIFICAND_NUM;
    double LOG10_MAX_SIGNIFICAND;
    int NUM_EXPONENT_BITS;
    int EXPONENT_MASK;
    int EXPONENT_BIAS;
    int MIN_EXPONENT_NUM;
    int MAX_EXPONENT_NUM;
    int SIGNBIT_MASK;
    int BASE;

    float MIN_FLOAT_VALUE;
    float MAX_FLOAT_VALUE;
    float MIN_NORMAL_VALUE;
    std::vector<float> POWER_OF_TENS;

  private:
    
    // Constructor? (the {} brackets) are needed here.
    HPFConstants() {
      NUM_SIGNIFICAND_BITS = 10;
      SIGNIFICAND_MASK = (1 <<NUM_SIGNIFICAND_BITS) - 1; 
      MAX_SIGNIFICAND_NUM =  SIGNIFICAND_MASK;
      LOG10_MAX_SIGNIFICAND = log10(SIGNIFICAND_MASK);
      NUM_EXPONENT_BITS = 5;
      EXPONENT_MASK = ((1 << NUM_EXPONENT_BITS) -1) << NUM_SIGNIFICAND_BITS;
      EXPONENT_BIAS = 1 << (NUM_EXPONENT_BITS -1);
      MIN_EXPONENT_NUM =  -EXPONENT_BIAS;
      MAX_EXPONENT_NUM =  EXPONENT_BIAS-1;
      SIGNBIT_MASK = 1 << (NUM_SIGNIFICAND_BITS+NUM_EXPONENT_BITS);
      BASE = 10;
      MIN_FLOAT_VALUE = (float)(-MAX_SIGNIFICAND_NUM*pow(float(BASE), float(MAX_EXPONENT_NUM)));
      MAX_FLOAT_VALUE = (float)(MAX_SIGNIFICAND_NUM*pow(float(BASE), float(MAX_EXPONENT_NUM)));
      MIN_NORMAL_VALUE = (float)(pow(float(BASE), float(MIN_EXPONENT_NUM)));
      POWER_OF_TENS.resize(MAX_EXPONENT_NUM-MIN_EXPONENT_NUM+2);

      for(int i=0; i<POWER_OF_TENS.size(); i++){
	POWER_OF_TENS[i] = (float) pow(float(10), float(-16+i));
      }
    };
    // Dont forget to declare these two. You want to make sure they
    // are unaccessable otherwise you may accidently get copies of
    // your singleton appearing.
    HPFConstants(HPFConstants const&);// Don't Implement
    void operator=(HPFConstants const&); // Don't Implement
  };

  class HalfPrecisionFloat {

  public:

  HalfPrecisionFloat(): constants(HPFConstants::getInstance()){}

  HalfPrecisionFloat(float number): constants(HPFConstants::getInstance()){
      setNumber(number);
    }
      
    static short floatToShortBits(const float number){
      ATS::HalfPrecisionFloat hpf(number);
      return hpf.compressedNumber;
    }

    static float shortBitsToFloat(const short compressed){
      ATS::HalfPrecisionFloat hpf;
      hpf.setCompressed(compressed);
      return hpf.getNumber();
    }

    std::string toString() {
      std::string str = "";
      for(int i=0; i<16; i++){
	str+=((compressedNumber) >> (15-i) & 1) == 1? "1":"0";
      }
      return str;
    }

    void fromBitString(const std::string bitString){
      compressedNumber = 0;
      for(int i=0; i<16; i++){
	if(bitString[i]=='1'){
	  compressedNumber = (short) (compressedNumber | 1 << (15-i)); 
	}
      }
      uncompress();
    }

    void numToBytes(char *bytes) {
      *(bytes) = (char)(compressedNumber & 0xff);
      *(bytes+1) = (char)(compressedNumber >> 8 & 0xff);
    }

    void bytesToNum(const char *bytes) {
      compressedNumber = (short) (*bytes & 0xff)|( (*(bytes+1) & 0xff) << 8);
      uncompress();
    }

    float getNumber(){
      return number;
    }

    void setNumber(float number) {
      if(number>constants.MAX_FLOAT_VALUE){
	this->number = constants.MAX_FLOAT_VALUE;
      }else if(number < constants.MIN_NORMAL_VALUE && number > 0){ 
	this->number = constants.MIN_NORMAL_VALUE;
      }else if (number<constants.MIN_FLOAT_VALUE){
	this->number = constants.MIN_FLOAT_VALUE;
      }else{
	this->number = number;
      }
      // compress it 
      compress();
    }

    short getCompressed(){
      return compressedNumber;
    }

    void setCompressed(short compressed ){
      compressedNumber = compressed;
      uncompress();
    }

  private:
    // STRUCTURE OF COMPRESSED NUMBER IS AS FOLLOWS
    // 0 00000 0000000000
    // ^   ^       ^
    // |   |       | mantissa/significand
    // |   | exponent   
    // | sign bit

    short compressedNumber;
    float number;
    HPFConstants& constants;
    
    void compress(){
      int sign = 0, exponent = 0, mantissa = 0; 
      float tempnumber = number;
      // get the sign bit
      if (tempnumber < 0 ) { sign = 1; tempnumber = -tempnumber; };
      if (tempnumber == 0) {
	// do nothing
      }else{
	float delta = (float) ceil(log10(tempnumber)-constants.LOG10_MAX_SIGNIFICAND);
	while(delta<-16){ delta++;}
	exponent = (int) (delta+constants.EXPONENT_BIAS);
	tempnumber = tempnumber*constants.POWER_OF_TENS[(int) (constants.EXPONENT_BIAS-delta)];
      }
      mantissa = (int) tempnumber;
      compressedNumber = (short) ((((sign << (constants.NUM_EXPONENT_BITS+constants.NUM_SIGNIFICAND_BITS)) & constants.SIGNBIT_MASK) 
				   | ((exponent << constants.NUM_SIGNIFICAND_BITS) & constants.EXPONENT_MASK)
				   | (mantissa & constants.SIGNIFICAND_MASK)));
    }

    void uncompress(){
      // convert compress form to float number
      float mantissa = (compressedNumber & constants.SIGNIFICAND_MASK); 
      float exponent = ((compressedNumber & constants.EXPONENT_MASK) >> constants.NUM_SIGNIFICAND_BITS) - constants.EXPONENT_BIAS;
      float sign     = ((compressedNumber & constants.SIGNBIT_MASK) >> (constants.NUM_EXPONENT_BITS+constants.NUM_SIGNIFICAND_BITS)) == 1? -1:1;   
      number = (float) (sign*mantissa*pow(constants.BASE, exponent));
    }
    
  };

} // namespace AVS

#ifdef TESTING_WITH_GTEST

TEST(HalfPrecisionFloat, compatibility)
{
  ATS::HalfPrecisionFloat hpf;
  std::string bitString = "0100011000011001";
  hpf.fromBitString(bitString);
  float number = 5370.0f;
  ASSERT_TRUE(abs(number - hpf.getNumber()) < 0.001);
  ASSERT_TRUE(bitString == hpf.toString());

  bitString = "0011111111111110";
  hpf.fromBitString(bitString);
  number = 102.2f;
  ASSERT_TRUE(abs(number - hpf.getNumber()) < 0.001);
  ASSERT_TRUE(bitString == hpf.toString());
}
#endif //TESTING_WITH_GTEST

#endif // HALFPRECISIONFLOAT_H
