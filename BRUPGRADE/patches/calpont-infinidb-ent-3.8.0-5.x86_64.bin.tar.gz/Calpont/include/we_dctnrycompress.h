/*

Copyright (C) 2009-2011 Calpont Corporation.

Use of and access to the Calpont InfiniDB Community software is subject to the
terms and conditions of the Calpont Open Source License Agreement. Use of and
access to the Calpont InfiniDB Enterprise software is subject to the terms and
conditions of the Calpont End User License Agreement.

This program is distributed in the hope that it will be useful, and unless
otherwise noted on your license agreement, WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Please refer to the Calpont Open Source License Agreement and the Calpont End
User License Agreement for more details.

You should have received a copy of either the Calpont Open Source License
Agreement or the Calpont End User License Agreement along with this program; if
not, it is your responsibility to review the terms and conditions of the proper
Calpont license agreement by visiting http://www.calpont.com for the Calpont
InfiniDB Enterprise End User License Agreement or http://www.infinidb.org for
the Calpont InfiniDB Community Calpont Open Source License Agreement.

Calpont may make changes to these license agreements from time to time. When
these changes are made, Calpont will make a new copy of the Calpont End User
License Agreement available at http://www.calpont.com and a new copy of the
Calpont Open Source License Agreement available at http:///www.infinidb.org.
You understand and agree that if you use the Program after the date on which
the license agreement authorizing your use has changed, Calpont will treat your
use as acceptance of the updated License.

*/

//  $Id: we_dctnrycompress.h 3052 2011-08-31 18:22:45Z chao $


/** @file */

#ifndef _WE_DCTNRY_COMPRESS_H_
#define _WE_DCTNRY_COMPRESS_H_

#include <stdlib.h>

#include "we_dctnry.h"
#include "we_chunkmanager.h"
#if defined(_MSC_VER) && defined(WRITEENGINEDCTNRYCOMPRESS_DLLEXPORT)
#define EXPORT __declspec(dllexport)
#else
#define EXPORT
#endif

/** Namespace WriteEngine */
namespace WriteEngine
{

/** Class DctnryCompress */
class DctnryCompress0 : public Dctnry
{
public:
   /**
   * @brief Constructor
   */
   EXPORT DctnryCompress0();
   EXPORT DctnryCompress0(Log* logger);

   /**
   * @brief Default Destructor
   */
   EXPORT virtual ~DctnryCompress0();
};



/** Class DctnryCompress1 */
class DctnryCompress1 : public Dctnry
{
public:
   /**
   * @brief Constructor
   */
   EXPORT DctnryCompress1(Log* logger=0);

   /**
   * @brief Default Destructor
   */
   EXPORT virtual ~DctnryCompress1();

   /**
   * @brief virtual method in FileOp
   */
   EXPORT int flushFile(int rc, std::map<FID,FID> & columnOids, bool truncateFile=false);

   /**
   * @brief virtual method in DBFileOp
   */
   EXPORT int readDBFile(FILE* pFile, unsigned char* readBuf, const i64 lbid,
                         const bool isFbo = false );

   /**
   * @brief virtual method in DBFileOp
   */
   EXPORT int writeDBFile(FILE* pFile, const unsigned char* writeBuf, const i64 lbid,
                          const int numOfBlock = 1);

	/**
   * @brief virtual method in DBFileOp
   */
   EXPORT int writeDBFileNoVBCache(FILE *pFile,
                                           const unsigned char * writeBuf, const int fbo,
                                           const int numOfBlock = 1);


   /**
   * @brief virtual method in Dctnry
   */
   FILE* createDctnryFile(const char *name, int width, const char *mode, int ioBuffSize);

   /**
   * @brief virtual method in Dctnry
   */
   FILE* openDctnryFile();

	/**
   * @brief virtual method in Dctnry
   */
   void closeDctnryFile(bool doFlush, std::map<FID,FID> & columnOids);
   
   /**
   * @brief virtual method in Dctnry
   */
   int numOfBlocksInFile();
   
   /**
   * @brief For bulkload to use
   */
   void setMaxActiveChunkNum(unsigned int maxActiveChunkNum) { fChunkManager->setMaxActiveChunkNum(maxActiveChunkNum); };
   void setBulkFlag(bool isBulkLoad) {fChunkManager->setBulkFlag(isBulkLoad);};
   void chunkManager(ChunkManager* cm);
   void setTransId(const TxnID& transId) {Dctnry::setTransId(transId); fChunkManager->setTransId(transId);}

protected:

   /**
   * @brief virtual method in FileOp
   */
   int updateDctnryExtent(FILE* pFile, int nBlocks);

   /**
   * @brief convert lbid to fbo
   */
   int lbidToFbo(const i64 lbid, int& fbo);

   ChunkManager* fChunkManager;
   bool fIsInsert;
};


} //end of namespace

#undef EXPORT

#endif // _WE_DCTNRY_COMPRESS_H_
