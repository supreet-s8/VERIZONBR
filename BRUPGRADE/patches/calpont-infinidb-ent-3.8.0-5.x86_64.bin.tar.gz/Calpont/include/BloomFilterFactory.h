#ifndef BLOOMFILTERFACTORY_H
#define BLOOMFILTERFACTORY_H

#include "BloomFilter.h"
#include "SimHashBloomFilter.h"

#ifdef TESTING_WITH_GTEST
#include "gtest/gtest.h"
#endif //TESTING_WITH_GTEST

namespace BloomFilter
{
	class BloomFilterFactory
	{
	public:
		static BloomFilter *create(char flavour)
		{
			return new SimHashBloomFilter(getCardinality(flavour), getFpRate(flavour));
		}

		static BloomFilter *create(std::string buffer)
		{
			return new SimHashBloomFilter(buffer);
		}
	};

	int main()
	{
		BloomFilter *b = BloomFilterFactory::create('A');
		b->insert(12345);
		std::cout<<b->checkPresence(12345);
		return 1;

	}
}




#ifdef TESTING_WITH_GTEST
TEST(BloomFilter, BloomFilterBasicTest)
{
	BloomFilter::BloomFilter *b = BloomFilter::BloomFilterFactory::create('A');
	b->insert(12345);
	ASSERT_TRUE(b->checkPresence(12345));
	ASSERT_FALSE(b->checkPresence(1234));
	b->insert("hi there");
	ASSERT_TRUE(b->checkPresence("hi there"));
	ASSERT_FALSE(b->checkPresence("amir"));

	std::string bbuffer = b->getBuffer();
	BloomFilter::BloomFilter *newB = BloomFilter::BloomFilterFactory::create(bbuffer);
	ASSERT_TRUE(newB->checkPresence(12345));
	ASSERT_FALSE(newB->checkPresence(1234));
	ASSERT_TRUE(newB->checkPresence("hi there"));
	ASSERT_FALSE(newB->checkPresence("amir"));

	// This should throw an insane buffer exception as we are passing any arbitrary string for bloom filter creation.
	EXPECT_THROW(BloomFilter::BloomFilterFactory::create("insane BloomFilter"), BloomFilter::BloomFilterException);
}

TEST(BloomFilter, BloomFilterGetPresentTest)
{
	BloomFilter::BloomFilter *bi = BloomFilter::BloomFilterFactory::create('D');
	BloomFilter::BloomFilter *bs = BloomFilter::BloomFilterFactory::create('D');
	int size = 1000000;
	std::vector<int> v1;
	std::vector<std::string> v2;

	for (int i = 0; i < size; i++) 
	{
		v1.push_back(i);
		std::stringstream s;
		s<<i;
		std::string si("Constants" + s.str());
		v2.push_back(si);
	}

	bi->insertBulk(v1);
	bs->insertBulk(v2);
	std::vector<int> pi = bi->getPresentElements(v1);
	std::vector<std::string> ps = bs->getPresentElements(v2);
	ASSERT_TRUE(pi.size() == size);
	ASSERT_TRUE(ps.size() == size);

	std::string bibuffer = bi->getBuffer();
	BloomFilter::BloomFilter *newbi = BloomFilter::BloomFilterFactory::create(bibuffer);
	std::vector<int> newpi = newbi->getPresentElements(v1);	
	ASSERT_TRUE(newpi.size() == size);

	std::string bsbuffer = bs->getBuffer();
	BloomFilter::BloomFilter *newbs = BloomFilter::BloomFilterFactory::create(bsbuffer);
	std::vector<std::string> newps = newbs->getPresentElements(v2);	
	ASSERT_TRUE(newps.size() == size);
}

TEST(BloomFilter, BloomFilterRegressionTest)
{
	char flavours[] = {'A', 'B', 'C', 'D'};
	for(int fi = 0; fi < 4; fi++)
	{
		char flavour = flavours[fi];
		BloomFilter::BloomFilter *bi = BloomFilter::BloomFilterFactory::create(flavour);
		BloomFilter::BloomFilter *bs = BloomFilter::BloomFilterFactory::create(flavour);
		int size = BloomFilter::getCardinality(flavour);
		float expectFPRate = BloomFilter::getFpRate(flavour);
		std::vector<int> v1;
		std::vector<std::string> v2;

		for (int i = 0; i < size/2; i++) 
		{
			v1.push_back(i);
			std::stringstream s;
			s<<i;
			std::string si("Constants" + s.str());
			v2.push_back(si);
		}

		bi->insertBulk(v1);
		bs->insertBulk(v2);
		for (int i = size/2; i < size; i++) 
		{
			v1.push_back(i);
			std::stringstream s;
			s<<i;
			std::string si("Constants" + s.str());
			v2.push_back(si);
		}

		std::vector<int> pi = bi->getPresentElements(v1);
		std::vector<std::string> ps = bs->getPresentElements(v2);
		float fpoi = pi.size() - size/2;	// fp observed for ints
		std::cout<<"FP: "<<fpoi<<". rate observed for integers: "<<fpoi/size<<std::endl;
		float fpos = ps.size() - size/2;	// fp observed for strings
		std::cout<<"FP: "<<fpos<<". rate observed for strings: "<<fpos/size<<std::endl;
		ASSERT_TRUE(fpoi >= 0);
		ASSERT_TRUE(fpos >= 0);
		ASSERT_TRUE(fpoi/size <= expectFPRate);
		ASSERT_TRUE(fpos/size <= expectFPRate);
		std::cout<<"Test done for flavour: "<<flavour<<std::endl;
	}
}

TEST(BloomFilter, BloomFilterAggregationTest)
{
	char flavours[] = {'A', 'B', 'C', 'D'};
	for(int fi = 0; fi < 4; fi++)
	{
		char flavour = flavours[fi];
		BloomFilter::BloomFilter *bi1 = BloomFilter::BloomFilterFactory::create(flavour);
		BloomFilter::BloomFilter *bi2 = BloomFilter::BloomFilterFactory::create(flavour);
		BloomFilter::BloomFilter *bi3 = BloomFilter::BloomFilterFactory::create(flavour);
		BloomFilter::BloomFilter *bi4 = BloomFilter::BloomFilterFactory::create(flavour);
		int size = BloomFilter::getCardinality(flavour);
		float expectFPRate = BloomFilter::getFpRate(flavour);
		std::vector<int> v1;

		for (int i = 0; i < size/2; i += 4) 
		{
			v1.push_back(i);
			bi1->insert(i);

			v1.push_back(i+1);
			bi2->insert(i+1);

			v1.push_back(i+2);
			bi3->insert(i+2);

			v1.push_back(i+3);
			bi4->insert(i+3);
		}

		for (int i = size/2; i < size; i++) 
		{
			v1.push_back(i);
		}


		std::vector<int> pi = bi1->getPresentElements(v1);
		int poi = pi.size() - size/8;	// fp observed for ints
		ASSERT_TRUE(poi >= 0);
		// std::cout<<"False Positives before aggregagation in bi1: "<<poi<<std::endl;

		pi = bi2->getPresentElements(v1);
		poi = pi.size() - size/8;	// fp observed for ints
		ASSERT_TRUE(poi >= 0);
		// std::cout<<"False Positives before aggregagation in bi2: "<<poi<<std::endl;

		pi = bi3->getPresentElements(v1);
		poi = pi.size() - size/8;	// fp observed for ints
		ASSERT_TRUE(poi >= 0);
		// std::cout<<"False Positives before aggregagation in bi3: "<<poi<<std::endl;

		pi = bi4->getPresentElements(v1);
		poi = pi.size() - size/8;	// fp observed for ints
		ASSERT_TRUE(poi >= 0);
		// std::cout<<"False Positives before aggregagation in bi4: "<<poi<<std::endl;

		bi1->aggregate(*bi2);
		bi1->aggregate(*bi3);
		bi1->aggregate(*bi4);

		pi = bi1->getPresentElements(v1);
		float fpoi = pi.size() - size/2;	// fp observed for ints
		std::cout<<"FP: "<<fpoi<<". rate observed after aggregagation: "<<fpoi/size<<std::endl;
		ASSERT_TRUE(fpoi >= 0);
		ASSERT_TRUE(fpoi/size <= expectFPRate);
		std::cout<<"Test done for flavour: "<<flavour<<std::endl;
		std::cout<<"\nBloomfilter info:\n"<<bi1->getInfo()<<std::endl<<std::endl;
	}
}

#endif //TESTING_WITH_GTEST

#endif //BLOOMFILTERFACTORY_H
