/*

Copyright (C) 2009-2011 Calpont Corporation.

Use of and access to the Calpont InfiniDB Community software is subject to the
terms and conditions of the Calpont Open Source License Agreement. Use of and
access to the Calpont InfiniDB Enterprise software is subject to the terms and
conditions of the Calpont End User License Agreement.

This program is distributed in the hope that it will be useful, and unless
otherwise noted on your license agreement, WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Please refer to the Calpont Open Source License Agreement and the Calpont End
User License Agreement for more details.

You should have received a copy of either the Calpont Open Source License
Agreement or the Calpont End User License Agreement along with this program; if
not, it is your responsibility to review the terms and conditions of the proper
Calpont license agreement by visiting http://www.calpont.com for the Calpont
InfiniDB Enterprise End User License Agreement or http://www.infinidb.org for
the Calpont InfiniDB Community Calpont Open Source License Agreement.

Calpont may make changes to these license agreements from time to time. When
these changes are made, Calpont will make a new copy of the Calpont End User
License Agreement available at http://www.calpont.com and a new copy of the
Calpont Open Source License Agreement available at http:///www.infinidb.org.
You understand and agree that if you use the Program after the date on which
the license agreement authorizing your use has changed, Calpont will treat your
use as acceptance of the updated License.

*/

/***********************************************************************
 *   $Id: altertableprocessor.h 7409 2011-02-08 14:38:50Z rdempsey $
 *
 *
 ***********************************************************************/
/** @file */
#ifndef ALTERTABLEPROCESSOR_H
#define ALTERTABLEPROCESSOR_H

#include "ddlpackageprocessor.h"

#if defined(_MSC_VER) && defined(ALTERTABLEPROC_DLLEXPORT)
#define EXPORT __declspec(dllexport)
#else
#define EXPORT
#endif

namespace ddlpackageprocessor
{
    /** @brief specialization of a DDLPackageProcessor
     * for interacting with the Write Engine
     * to process alter table ddl statements.
     */
    class AlterTableProcessor : public DDLPackageProcessor
    {
        public:
            /** @brief process an alter table statement
             *
             * @param alterTableStmt the AlterTableStatement
             */
            EXPORT DDLResult processPackage(ddlpackage::AlterTableStatement& alterTableStmt);
            /** @brief add a physical column file
             *
             * @param result the result of the operation
             * @param addColumn the AtaAddColumn object
             * @param fTableName the QualifiedName of the table
             */
            EXPORT void addColumn(u_int32_t sessionID, execplan::CalpontSystemCatalog::SCN txnID, DDLResult& result,
                ddlpackage::ColumnDef* columnDefPtr,
                ddlpackage::QualifiedName& fTableName, const std::string& copyFile = "", const std::string& copyColumn = "");

            /** @brief drop a column
             *
             * @param result the result of the operation
             * @param ataDropColumn the AtaDropColumn object
             * @param fTableName the QualifiedName for the table
             */
            EXPORT void dropColumn(u_int32_t sessionID, execplan::CalpontSystemCatalog::SCN txnID, DDLResult& result,
                ddlpackage::AtaDropColumn& ataDropColumn,
                ddlpackage::QualifiedName& fTableName );

            /** @brief drop columns
             *
             * @param result the result of the operation
             * @param ataDropColumns the AtaDropColumn object
             * @param fTableName the QualifiedName for the table
             */
            EXPORT void dropColumns(u_int32_t sessionID, execplan::CalpontSystemCatalog::SCN txnID, DDLResult& result,
                ddlpackage::AtaDropColumns& ataDropColumns,
                ddlpackage::QualifiedName& fTableName );

            /** @brief add table constraint
             *
             * @param result the result of the operation
             * @param ataAddTableConstraint the AtaDropColumn object
             * @param fTableName the QualifiedName for the table
             */
            EXPORT void addTableConstraint(u_int32_t sessionID, execplan::CalpontSystemCatalog::SCN txnID, DDLResult& result,
                ddlpackage::AtaAddTableConstraint& ataAddTableConstraint,
                ddlpackage::QualifiedName& fTableName );

            /** @brief set column default
             *
             * @param result the result of the operation
             * @param ataSetColumnDefault the AtaSetColumnDefault object
             * @param fTableName the QualifiedName for the table
             */
            EXPORT void setColumnDefault(u_int32_t sessionID, execplan::CalpontSystemCatalog::SCN txnID, DDLResult& result,
                ddlpackage::AtaSetColumnDefault& ataSetColumnDefault,
                ddlpackage::QualifiedName& fTableName );

            /** @brief drop column default
             *
             * @param result the result of the operation
             * @param ataDropColumnDefault the AtaDropColumnDefault object
             * @param fTableName the QualifiedName for the table
             */
            EXPORT void dropColumnDefault(u_int32_t sessionID, execplan::CalpontSystemCatalog::SCN txnID, DDLResult& result,
                ddlpackage::AtaDropColumnDefault& ataDropColumnDefault,
                ddlpackage::QualifiedName& fTableName );

            /** @brief drop table constraint
             *
             * @param result the result of the operation
             * @param ataDropTableConstraint the AtaDropTableConstraint object
             * @param fTableName the QualifiedName for the table
             */
            EXPORT void dropTableConstraint(u_int32_t sessionID, execplan::CalpontSystemCatalog::SCN txnID, DDLResult& result,
                ddlpackage::AtaDropTableConstraint& ataDropTableConstraint,
                ddlpackage::QualifiedName& fTableName );
            /** @brief rename a table
             *
             * @param result the result of the operation
             * @param ataRenameTable the AtaRenameTable object
             * @param fTableName the QualifiedName for the table
             */
            EXPORT void renameTable(u_int32_t sessionID, execplan::CalpontSystemCatalog::SCN txnID,
                DDLResult& result, ddlpackage::AtaRenameTable& ataRenameTable,
                ddlpackage::QualifiedName& fTableName );

            /** @brief rename a column
             *
             * @param result the result of the operation
             * @param ataRenameColumn the AtaRenameColumn object
             * @param fTableName the QualifiedName for the table
             */
            EXPORT void renameColumn(u_int32_t sessionID, execplan::CalpontSystemCatalog::SCN txnID, DDLResult& result,
                ddlpackage::AtaRenameColumn& ataRenameColumn,
                ddlpackage::QualifiedName& fTableName );

        protected:
	    void rollBackFiles(BRM::TxnID txnID);
	    void rollBackAlter(const std::string& error, BRM::TxnID txnID, int sessionId, DDLResult& result);

        private:

    };

}                                                 //namespace ddlpackageprocessor

#undef EXPORT

#endif                                            //ALTERTABLEPROCESSOR_H
