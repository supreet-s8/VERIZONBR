/*

Copyright (C) 2009-2011 Calpont Corporation.

Use of and access to the Calpont InfiniDB Community software is subject to the
terms and conditions of the Calpont Open Source License Agreement. Use of and
access to the Calpont InfiniDB Enterprise software is subject to the terms and
conditions of the Calpont End User License Agreement.

This program is distributed in the hope that it will be useful, and unless
otherwise noted on your license agreement, WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Please refer to the Calpont Open Source License Agreement and the Calpont End
User License Agreement for more details.

You should have received a copy of either the Calpont Open Source License
Agreement or the Calpont End User License Agreement along with this program; if
not, it is your responsibility to review the terms and conditions of the proper
Calpont license agreement by visiting http://www.calpont.com for the Calpont
InfiniDB Enterprise End User License Agreement or http://www.infinidb.org for
the Calpont InfiniDB Community Calpont Open Source License Agreement.

Calpont may make changes to these license agreements from time to time. When
these changes are made, Calpont will make a new copy of the Calpont End User
License Agreement available at http://www.calpont.com and a new copy of the
Calpont Open Source License Agreement available at http:///www.infinidb.org.
You understand and agree that if you use the Program after the date on which
the license agreement authorizing your use has changed, Calpont will treat your
use as acceptance of the updated License.

*/

/***********************************************************************
*   $Id: clientsocket.h 2394 2011-02-08 14:36:22Z rdempsey $
*
*
***********************************************************************/
/** @file */
#ifndef MESSAGEQCPP_CLIENTSOCKET_H
#define MESSAGEQCPP_CLIENTSOCKET_H

#include <ctime>
#ifdef _MSC_VER
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdio.h>
#else
#include <netinet/in.h>
#endif

#include "iosocket.h"

namespace messageqcpp {

/** an IOSocket that can be connected to a server
 *
 */
class ClientSocket : public IOSocket
{
public:

	/** ctor
	 *
	 */
	explicit ClientSocket(Socket* socket=0) : IOSocket(socket) {}

	/** dtor
	 *
	 */
	virtual ~ClientSocket() {}

	/** connect this IOSocket to a server
	 *
	 * connect this IOSocket to the server specified in serv_addr. Will throw a runtime_exception
	 * if the connection fails.
	 */
	inline virtual void connect(const struct sockaddr_in* serv_addr);

	/** set the connection timeout on a connect() call for this socket.
	 *
	 * set the connection timeout on a connect() call for this socket.
	 */
	inline virtual void connectionTimeout(const struct timespec* timeout);

	/** set the connection protocol to be synchronous
	 *
	 * set the connection protocol on a connect() call for this socket.
	 */
	inline virtual void syncProto(bool use);

private:
	ClientSocket(const ClientSocket& rhs);
	ClientSocket& operator=(const ClientSocket& rhs);
};

inline void ClientSocket::connect(const struct sockaddr_in* serv_addr) { connect_(serv_addr); }
inline void ClientSocket::connectionTimeout(const struct timespec* timeout) { connectionTimeout_(timeout); }
inline void ClientSocket::syncProto(bool use) { syncProto_(use); }

} //namespace messageqcpp

#endif //MESSAGEQCPP_CLIENTSOCKET_H

