// Concurrent Flows Library
// Nikhil S. Ketkar, nikhil.ketkar@guavus.com

#ifndef CONCURRENTFLOWEXCEPTION_H
#define CONCURRENTFLOWEXCEPTION_H

#include <exception>

namespace ConcurrentFlows
{

class ConcurrentFlowException: public std::exception
{
public:
	// exception with given message
	ConcurrentFlowException(){}

	// exception with given message
	ConcurrentFlowException(std::string msg):expmsg(msg){}
  
	~ConcurrentFlowException() throw(){}
	
	virtual const char* what() const throw(){
		if (expmsg.size()>0){
			return expmsg.c_str();
		}else{
			return "Concurrent Flow Exception";
		}
	}

private:
	std::string expmsg;
  
};

} // namespace ConcurrentFlows

#endif //CONCURRENTFLOWEXCEPTION_H
