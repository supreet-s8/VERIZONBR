/*

Copyright (C) 2009-2011 Calpont Corporation.

Use of and access to the Calpont InfiniDB Community software is subject to the
terms and conditions of the Calpont Open Source License Agreement. Use of and
access to the Calpont InfiniDB Enterprise software is subject to the terms and
conditions of the Calpont End User License Agreement.

This program is distributed in the hope that it will be useful, and unless
otherwise noted on your license agreement, WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Please refer to the Calpont Open Source License Agreement and the Calpont End
User License Agreement for more details.

You should have received a copy of either the Calpont Open Source License
Agreement or the Calpont End User License Agreement along with this program; if
not, it is your responsibility to review the terms and conditions of the proper
Calpont license agreement by visiting http://www.calpont.com for the Calpont
InfiniDB Enterprise End User License Agreement or http://www.infinidb.org for
the Calpont InfiniDB Community Calpont Open Source License Agreement.

Calpont may make changes to these license agreements from time to time. When
these changes are made, Calpont will make a new copy of the Calpont End User
License Agreement available at http://www.calpont.com and a new copy of the
Calpont Open Source License Agreement available at http:///www.infinidb.org.
You understand and agree that if you use the Program after the date on which
the license agreement authorizing your use has changed, Calpont will treat your
use as acceptance of the updated License.

*/

//
// $Id$
//
// Timer class used to spit out times and percentages.  Temporarily lives in joblist.
// This is strictly a debugging utility class that accumulates times between .start() and
// .stop() calls for a particular string.  It can be useful in tdrivers.
//
// It outputs a report when finish() is called with
// the total times by string and their percentage of the total.  The total is tracked from
// the first time start() is called until finish() is called.  You should always match your
// start and stop calls up.
//
// This works fine as long as you don't use it with huge numbers of calls.  If you call start 
// and stop too many times the overhead of the StopWatch class will start factoring in to your
// results.
//
// How to use:
// 
// 	StopWatch timer;
// 	timer.start("Loop only");
// 	for(int i = 0; i < 6999075; i++)
// 	{
// 	}
// 	timer.stop("Loop only");
// 
// 	timer.start("Loop Plus");
// 	for(int i = 0; i < 100000; i++)
// 	{
// 		timer.start("Inside loop");
// 		timer.stop("Inside loop");
// 	}
// 	timer.stop("Loop Plus");
// 	timer.finish();
//
// Produces this:
// 
// Seconds  Percentage  Calls      Description
// 0.02865  9.377%      1          Loop only
// 0.27680  90.59%      1          Loop Plus
// 0.12138  39.72%      100000     Inside loop
// 
// 0.30553  100  %      1          Total
// 
// Note that you can have overlapping timers which will make your percentages add up to more than 100%.
#ifndef STOPWATCH_H
#define STOPWATCH_H
#include <iostream>
#include <fstream>
#include <list>
#include <sstream>
#include <time.h>
#include <sys/time.h>
#include <vector>
#include <stdexcept>
#include <map>
#include <unistd.h>

namespace logging
{

class StopWatch {
	public:
		void start(const std::string& message);
		bool stop(const std::string& message, const int limit);
		void stop(const std::string& message);
		void finish();
		
		bool isActive() 
		{
			return fOpenCalls > 0;
		}
		StopWatch() : fStarted(false), fId(-1), fOpenCalls(0), fOutputToFile(false), fLogFile("") {};
		StopWatch(int id) : fStarted(false), fId(id), fOpenCalls(0), fOutputToFile(false), fLogFile("") {};
		StopWatch(const std::string& fileName) : fStarted(false), fId(-1), fOpenCalls(0), fOutputToFile(true), fLogFile(fileName) {}
		struct ::timeval fTvLast;
		int getId() { return fId; }

	private:
		class ProcessStats 
		{
			public:
			
			std::string fProcess;
			struct timeval fTvProcessStarted;
			double fTotalSeconds;
			int64_t fStartCount;
			int64_t fStopCount;

			ProcessStats() : fProcess(""), fTotalSeconds(0.0), fStartCount(0), fStopCount(0) {};

			void processStart() 
			{
				gettimeofday(&fTvProcessStarted, 0);
				fStartCount++;
			}

			void processStop()
			{
				struct timeval tvStop;
				gettimeofday(&tvStop, 0);
				fStopCount++;
				fTotalSeconds += 
					(tvStop.tv_sec + (tvStop.tv_usec / 1000000.0)) -
					(fTvProcessStarted.tv_sec + (fTvProcessStarted.tv_usec / 1000000.0));

			}
		};

 		struct timeval fTvStart;
		std::vector <ProcessStats> fProcessStats;
		bool fStarted;
		int fId;
		int fOpenCalls;
		bool fOutputToFile;
		std::string fLogFile;
};

} // end of logging namespace

#endif //  STOPWATCH_H
