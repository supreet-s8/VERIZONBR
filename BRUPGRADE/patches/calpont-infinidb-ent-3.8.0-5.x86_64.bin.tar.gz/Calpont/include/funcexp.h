/*

Copyright (C) 2009-2011 Calpont Corporation.

Use of and access to the Calpont InfiniDB Community software is subject to the
terms and conditions of the Calpont Open Source License Agreement. Use of and
access to the Calpont InfiniDB Enterprise software is subject to the terms and
conditions of the Calpont End User License Agreement.

This program is distributed in the hope that it will be useful, and unless
otherwise noted on your license agreement, WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Please refer to the Calpont Open Source License Agreement and the Calpont End
User License Agreement for more details.

You should have received a copy of either the Calpont Open Source License
Agreement or the Calpont End User License Agreement along with this program; if
not, it is your responsibility to review the terms and conditions of the proper
Calpont license agreement by visiting http://www.calpont.com for the Calpont
InfiniDB Enterprise End User License Agreement or http://www.infinidb.org for
the Calpont InfiniDB Community Calpont Open Source License Agreement.

Calpont may make changes to these license agreements from time to time. When
these changes are made, Calpont will make a new copy of the Calpont End User
License Agreement available at http://www.calpont.com and a new copy of the
Calpont Open Source License Agreement available at http:///www.infinidb.org.
You understand and agree that if you use the Program after the date on which
the license agreement authorizing your use has changed, Calpont will treat your
use as acceptance of the updated License.

*/

/****************************************************************************
* $Id: funcexp.h 2477 2011-04-01 16:07:35Z rdempsey $
*
*
****************************************************************************/
/** @file */

#ifndef FUNCEXP_H
#define FUNCEXP_H

#include <string>
#include <vector>
#ifdef _MSC_VER
#include <unordered_map>
#else
#include <tr1/unordered_map>
#endif
#include <boost/thread/mutex.hpp>

#include "rowgroup.h"
#include "returnedcolumn.h"
#include "parsetree.h"

namespace execplan
{
	class FunctionColumn;
	class ArithmeticColumn;
}

namespace funcexp
{
	class Func;
	
	typedef std::tr1::unordered_map<std::string, Func*> FuncMap;
	
/** @brief FuncExp is a component for evaluate function and expression filters
  */
class FuncExp {
public:		
	
	/** Singleton pattern */
	static FuncExp* instance();
	
	/********************************************************************
	* Row based evaluation APIs
	********************************************************************/
	
	/** @brief evaluate a filter stack on row. used for F&E on the where clause
	*
	* @param row input row that contains all the columns in the filter stack
	* @param filters parsetree of filters to evaluate
	* @return boolean of whether or not the row passed evaluation
	*/
	inline bool evaluate(rowgroup::Row& row, execplan::ParseTree* filters);
	
	/** @brief evaluate a filter stack on rowgroup
	 *
	 * @param row input rowgroup that contains all the columns in the filter stack
	 * @param filters parse tree of filters to evaluate. The failed rows are removed from the rowgroup  
	 */
	inline void evaluate(rowgroup::RowGroup& rowgroup, execplan::ParseTree* filters);
	
	/** @brief evaluate a F&E column on row. used for F&E on the select and group by clause
	*
	* @param row input row that contains all the columns in all the expressions
	* @param expressions vector of F&Es that needs evaluation. The results are filled on the row.
	*/
	void evaluate(rowgroup::Row& row, std::vector<execplan::SRCP>& expressions);
		
	/** @brief evaluate a F&E column on rowgroup. used for F&E on the select and group by clause
	*
	* @param row input rowgroup that contains all the columns in all the expressions
	* @param expressions vector of F&Es that needs evaluation. The results are filled on each row.
	*/
	inline void evaluate(rowgroup::RowGroup& rowgroup, std::vector<execplan::SRCP>& expressions);
				
	/** @brief get functor from functor map
	*
	* @param funcName function name
	* @return functor pointer. If non-support function, return NULL
	*/
	Func* getFunctor(std::string& funcName);

private:
	static FuncExp* fInstance;
	static boost::mutex fInstanceMutex;
	FuncMap fFuncMap;
	FuncExp();
};

inline bool FuncExp::evaluate( rowgroup::Row& row, execplan::ParseTree* filters )
{	
	bool isNull = false;
	return (filters->getBoolVal(row, isNull));
}

inline void FuncExp::evaluate( rowgroup::RowGroup& rowgroup, execplan::ParseTree* filters )
{	
}

}

#endif

