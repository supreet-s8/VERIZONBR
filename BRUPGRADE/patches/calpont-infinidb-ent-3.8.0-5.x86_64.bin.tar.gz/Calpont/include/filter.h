/*

Copyright (C) 2009-2011 Calpont Corporation.

Use of and access to the Calpont InfiniDB Community software is subject to the
terms and conditions of the Calpont Open Source License Agreement. Use of and
access to the Calpont InfiniDB Enterprise software is subject to the terms and
conditions of the Calpont End User License Agreement.

This program is distributed in the hope that it will be useful, and unless
otherwise noted on your license agreement, WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Please refer to the Calpont Open Source License Agreement and the Calpont End
User License Agreement for more details.

You should have received a copy of either the Calpont Open Source License
Agreement or the Calpont End User License Agreement along with this program; if
not, it is your responsibility to review the terms and conditions of the proper
Calpont license agreement by visiting http://www.calpont.com for the Calpont
InfiniDB Enterprise End User License Agreement or http://www.infinidb.org for
the Calpont InfiniDB Community Calpont Open Source License Agreement.

Calpont may make changes to these license agreements from time to time. When
these changes are made, Calpont will make a new copy of the Calpont End User
License Agreement available at http://www.calpont.com and a new copy of the
Calpont Open Source License Agreement available at http:///www.infinidb.org.
You understand and agree that if you use the Program after the date on which
the license agreement authorizing your use has changed, Calpont will treat your
use as acceptance of the updated License.

*/

/***********************************************************************
*   $Id: filter.h 7409 2011-02-08 14:38:50Z rdempsey $
*
*
***********************************************************************/
/** @file */

#ifndef EXECPLAN_FILTER_H
#define EXECPLAN_FILTER_H
#include <string>
#include <iosfwd>

#include "treenode.h"

namespace messageqcpp {
class ByteStream;
}

/**
 * Namespace
 */
namespace execplan { 

class Operator;

/** @brief A class to represent a generic filter predicate
 * 
 * ******************************* Abstract Class ****************************
 * Filter does not have any pure virtual methods, but its author
 *   defined it as an abstract class, so you should not use it directly.
 *   Inherit from it instead and create only objects from the derived classes
 * *****************************************************************************
 */
class Filter : public TreeNode {
//friend std::ostream &operator<< (std::ostream &, Filter &);

/**
 * Public stuff
 */
public:

	/**
	 * Constructors
	 */
	Filter();
	Filter(const std::string& sql);
	// not needed yet
	//Filter(const Filter& rhs);
	
	/**
	 * Destructors
	 */
	virtual ~Filter();
	/**
	 * Accessor Methods
	 */
	
	/**
	 * Operations
	 */
	virtual const std::string toString() const;

	virtual const std::string data() const { return fData; }
	virtual void data(const std::string data) { fData = data; }
	
    /** return a copy of this pointer
	 *
	 * deep copy of this pointer and return the copy
	 */	
	inline virtual Filter* clone() const
	{
	    return new Filter (*this);
	}	
	 
	 /**
	  * The serialization interface
	  */
	 virtual void serialize(messageqcpp::ByteStream&) const;
	 virtual void unserialize(messageqcpp::ByteStream&);

	/** @brief Do a deep, strict (as opposed to semantic) equivalence test
	  *
	  * Do a deep, strict (as opposed to semantic) equivalence test.
	  * @return true iff every member of t is a duplicate copy of every member of this; false otherwise
	  */
	 virtual bool operator==(const TreeNode* t) const;
	
	/** @brief Do a deep, strict (as opposed to semantic) equivalence test
	  *
	  * Do a deep, strict (as opposed to semantic) equivalence test.
	  * @return true iff every member of t is a duplicate copy of every member of this; false otherwise
	  */
	 bool operator==(const Filter& t) const;
	
	/** @brief Do a deep, strict (as opposed to semantic) equivalence test
	  *
	  * Do a deep, strict (as opposed to semantic) equivalence test.
	  * @return false iff every member of t is a duplicate copy of every member of this; true otherwise
	  */
	 virtual bool operator!=(const TreeNode* t) const;
	 
	/** @brief Do a deep, strict (as opposed to semantic) equivalence test
	  *
	  * Do a deep, strict (as opposed to semantic) equivalence test.
	  * @return false iff every member of t is a duplicate copy of every member of this; true otherwise
	  */
	 bool operator!=(const Filter& t) const;
	 
	 /** @brief test if this filter can be combined with the argument filter
	  *  This is for operation combine optimization
	  *  @param f the filter that this fiter tries to combine with
	  *  @param op the operator that connects the two filters. if one or both of the
	  *  two filters is constantFilter, need to make sure operator is consistant.
	  *  @return a filter(constantfilter) if sucessfully combined. otherwise return NULL
	  */
	 virtual Filter* combinable(Filter* f, Operator* op);
	 virtual uint64_t cardinality () const { return fCardinality; }
	 virtual void cardinality (const uint64_t cardinality) { fCardinality = cardinality;}
	 
protected:
    uint64_t fCardinality;
    	 
private:
	//default okay
	//Filter& operator=(const Filter& rhs);

	std::string fData;

};

std::ostream& operator<<(std::ostream& os, const Filter& rhs);

} 
#endif //EXECPLAN_FILTER_H

