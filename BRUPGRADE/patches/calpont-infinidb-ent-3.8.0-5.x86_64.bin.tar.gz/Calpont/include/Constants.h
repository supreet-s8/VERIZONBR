#ifdef TESTING_WITH_GTEST
#include "gtest/gtest.h"
#endif //TESTING_WITH_GTEST


namespace BloomFilter
{
#define TYPE               4

	/** The Measure buffer version. */
#define VERSION             41

	/** The Bloom Filter hashFamily. */
#define HASH_FAMILY         0

	/*
	 * As per the bloom filter buffer format, following are the indices of bloom
	 * filter header data.
	 */
#define VERSION_INDEX       0
#define TYPE_INDEX          1
#define SIZE_INDEX          2
#define HASH_FAMILY_INDEX   4
#define HASH_COUNT_INDEX    5
#define FPP_INDEX           6

	/*
	 * Number of bytes being used to represent size in the byte buffer.
	 */
#define SIZE_BYTECOUNT      2
#define EXT_SIZE_BYTECOUNT  2 /* Extended size byte count. */

#define HEADER_SIZE         7 /* Header size */
#define EXT_HEADER_SIZE     15 /* Extended header size. */
#define NULL_BUFFER_SIZE 8
#define NULL_VERSION 254	/* unsigned representation of -2 (standard for null buffer) */

#define INSANE_BYTE_BUFFER        "Byte buffer does not match any Bloom Filter format."
#define INCONSISTENT_BLOOMFILTERS "Aggregation not possible as buffer headers do not match."
#define NO_FLAVOUR_FOUND          "Flavour for the given values of FPP and Cardinality not found."

#define UNSUPPORTED_TYPE          "The type of element passed is not supported."

}
