/*

Copyright (C) 2009-2011 Calpont Corporation.

Use of and access to the Calpont InfiniDB Community software is subject to the
terms and conditions of the Calpont Open Source License Agreement. Use of and
access to the Calpont InfiniDB Enterprise software is subject to the terms and
conditions of the Calpont End User License Agreement.

This program is distributed in the hope that it will be useful, and unless
otherwise noted on your license agreement, WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Please refer to the Calpont Open Source License Agreement and the Calpont End
User License Agreement for more details.

You should have received a copy of either the Calpont Open Source License
Agreement or the Calpont End User License Agreement along with this program; if
not, it is your responsibility to review the terms and conditions of the proper
Calpont license agreement by visiting http://www.calpont.com for the Calpont
InfiniDB Enterprise End User License Agreement or http://www.infinidb.org for
the Calpont InfiniDB Community Calpont Open Source License Agreement.

Calpont may make changes to these license agreements from time to time. When
these changes are made, Calpont will make a new copy of the Calpont End User
License Agreement available at http://www.calpont.com and a new copy of the
Calpont Open Source License Agreement available at http:///www.infinidb.org.
You understand and agree that if you use the Program after the date on which
the license agreement authorizing your use has changed, Calpont will treat your
use as acceptance of the updated License.

*/

/******************************************************************************************
* $Id: loggingid.h 2926 2011-11-10 15:18:28Z rdempsey $
*
******************************************************************************************/
/**
 * @file
 */
#ifndef LOGGING_LOGGINGID_H
#define LOGGING_LOGGINGID_H

#include <string>

namespace logging {

/** @brief SubSystem IDs
  * This list matches SubsystemIDs.txt, but has names matching Process Config DB
  */
extern const std::string SubsystemID[];

/** @brief max index into SubsystemID[]
  * Range of index into SubsystemID is 0 <= index <= MAXSUBSYSTEMID.
  */
extern const unsigned MAXSUBSYSTEMID;

/** @brief a logging context structure
 *
 */
struct LoggingID
{
	/** @brief LoggingID ctor
	 *
	 */
	explicit LoggingID(unsigned subsysID=0, unsigned sessionID=0, unsigned txnID=0, unsigned ThdID=0)
		: fSubsysID(subsysID), fSessionID(sessionID), fTxnID(txnID), fThdID(ThdID)
		{}

	unsigned fSubsysID;	/// subsystem ID
	unsigned fSessionID;	/// session ID
	unsigned fTxnID;	/// transaction ID
	unsigned fThdID;	/// thread ID
};

}

#endif
