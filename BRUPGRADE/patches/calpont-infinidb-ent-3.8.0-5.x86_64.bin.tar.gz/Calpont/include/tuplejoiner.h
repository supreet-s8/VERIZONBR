/*

Copyright (C) 2009-2011 Calpont Corporation.

Use of and access to the Calpont InfiniDB Community software is subject to the
terms and conditions of the Calpont Open Source License Agreement. Use of and
access to the Calpont InfiniDB Enterprise software is subject to the terms and
conditions of the Calpont End User License Agreement.

This program is distributed in the hope that it will be useful, and unless
otherwise noted on your license agreement, WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Please refer to the Calpont Open Source License Agreement and the Calpont End
User License Agreement for more details.

You should have received a copy of either the Calpont Open Source License
Agreement or the Calpont End User License Agreement along with this program; if
not, it is your responsibility to review the terms and conditions of the proper
Calpont license agreement by visiting http://www.calpont.com for the Calpont
InfiniDB Enterprise End User License Agreement or http://www.infinidb.org for
the Calpont InfiniDB Community Calpont Open Source License Agreement.

Calpont may make changes to these license agreements from time to time. When
these changes are made, Calpont will make a new copy of the Calpont End User
License Agreement available at http://www.calpont.com and a new copy of the
Calpont Open Source License Agreement available at http:///www.infinidb.org.
You understand and agree that if you use the Program after the date on which
the license agreement authorizing your use has changed, Calpont will treat your
use as acceptance of the updated License.

*/

//
// C++ Interface: joiner
//
// Description: 
//
//
// Author: Patrick <pleblanc@localhost.localdomain>, (C) 2008
//
// Copyright: See COPYING file that comes with this distribution
//
//

#ifndef TJOINER_H_
#define TJOINER_H_

#include <iostream>
#include <vector>
#include <boost/shared_ptr.hpp>
#include <boost/scoped_ptr.hpp>
#include <boost/shared_array.hpp>
#include <boost/scoped_array.hpp>
#ifdef _MSC_VER
#include <unordered_map>
#else
#include <tr1/unordered_map>
#endif

#include "rowgroup.h"
#include "joiner.h"
#include "fixedallocator.h"
#include "joblisttypes.h"
#include "funcexpwrapper.h"
#include "stlpoolallocator.h"

namespace joiner
{

inline uint64_t order_swap(uint64_t x)
{
    return (x>>56) |
        ((x<<40) & 0x00FF000000000000ULL) |
        ((x<<24) & 0x0000FF0000000000ULL) |
        ((x<<8)  & 0x000000FF00000000ULL) |
        ((x>>8)  & 0x00000000FF000000ULL) |
        ((x>>24) & 0x0000000000FF0000ULL) |
        ((x>>40) & 0x000000000000FF00ULL) |
        (x<<56);
}
	
class TypelessData
{
public:
	uint8_t *data;
	uint len;

	TypelessData();
	bool operator==(const TypelessData &) const;
	void serialize(messageqcpp::ByteStream &) const;
	void deserialize(messageqcpp::ByteStream &, utils::FixedAllocator &);
	std::string toString() const;
};

/* This function makes the keys for string & compound joins.  The length of the
 * key is limited by keylen.  Keys that are longer are assigned a length of 0 on return,
 * signifying that it shouldn't match anything.
 */
extern TypelessData makeTypelessKey(const rowgroup::Row &,
	const std::vector<uint> &, uint keylen, utils::FixedAllocator *fa);

class TupleJoiner
{
public:
	struct hasher {
		std::size_t operator()(int64_t val) const
		{ return static_cast<std::size_t>(val); }
		std::size_t operator()(const TypelessData &) const;
		std::size_t operator()(const std::string &) const;
	};

	/* ctor to use for numeric join */
	TupleJoiner(
		const rowgroup::RowGroup &smallInput,
		const rowgroup::RowGroup &largeInput,
		uint smallJoinColumn,
		uint largeJoinColumn,
		joblist::JoinType jt);

	/* ctor to use for string & compound join */
	TupleJoiner(
		const rowgroup::RowGroup &smallInput,
		const rowgroup::RowGroup &largeInput,
		const std::vector<uint> &smallJoinColumns,
		const std::vector<uint> &largeJoinColumns,
		joblist::JoinType jt);

	~TupleJoiner();

	size_t inline size() const { return (joinAlg == UM || joinAlg == INSERTING ?
		(typelessJoin ? ht->size() : h->size()) : rows.size()); }

	void insert(rowgroup::Row &r);
	void doneInserting();

	/* match() returns the small-side rows that match the large-side row.
		On a UM join, it uses largeSideRow,
		on a PM join, it uses index and threadID.
	*/
	void match(rowgroup::Row &largeSideRow, uint index, uint threadID,
		std::vector<uint8_t *> *matches);

	/* On a PM left outer join + aggregation, the result is already complete.
		No need to match, just mark.
	*/
	void markMatches(uint threadID, uint rowCount);

	/* For small outer joins, this is how matches are marked now. */
	void markMatches(uint threadID, const std::vector<uint8_t *> &matches);

	/* Some accessors */
	inline bool inPM() const { return joinAlg == PM; }
	inline bool inUM() const { return joinAlg == UM; }
	void setInPM();
	void setInUM();
	void setThreadCount(uint cnt);
	void setPMJoinResults(boost::shared_array<std::vector<uint32_t> >,
		uint threadID);
	boost::shared_array<std::vector<uint32_t> > getPMJoinArrays(uint threadID);
	std::vector<uint8_t *> *getSmallSide() { return &rows; }
	inline bool smallOuterJoin() { return ((joinType & joblist::SMALLOUTER) != 0); }
	inline bool largeOuterJoin() { return ((joinType & joblist::LARGEOUTER) != 0); }
	inline bool innerJoin() { return joinType == joblist::INNER; }
	inline bool fullOuterJoin() { return (smallOuterJoin() && largeOuterJoin()); }
	inline joblist::JoinType getJoinType() { return joinType; }
	inline const rowgroup::RowGroup &getSmallRG() { return smallRG; }
	inline const rowgroup::RowGroup &getLargeRG() { return largeRG; }
	inline uint getSmallKeyColumn() { return smallKeyColumns[0]; }
	inline uint getLargeKeyColumn() { return largeKeyColumns[0]; }
	bool hasNullJoinColumn(const rowgroup::Row &largeRow) const;
	void getUnmarkedRows(std::vector<uint8_t *> *out);
	std::string getTableName() const;
	void setTableName(const std::string &tname);

	/* To allow sorting */
	bool operator<(const TupleJoiner &) const;

	uint64_t getMemUsage() const;

	/* Typeless join interface */
	inline bool isTypelessJoin() { return typelessJoin; }
	inline const std::vector<uint> & getSmallKeyColumns() { return smallKeyColumns; }
	inline const std::vector<uint> & getLargeKeyColumns() { return largeKeyColumns; }
	inline uint getKeyLength() { return keyLength; }
	
	/* Runtime casual partitioning support */
	inline const boost::scoped_array<bool> &discreteCPValues() { return discreteValues; }
	inline const boost::scoped_array<std::vector<int64_t> > &getCPData() { return cpValues; }
	inline void setUniqueLimit(uint limit) { uniqueLimit = limit; }

	/* Semi-join interface */
	inline bool semiJoin() { return ((joinType & joblist::SEMI) != 0); }
	inline bool antiJoin() { return ((joinType & joblist::ANTI) != 0); }
	inline bool scalar() { return ((joinType & joblist::SCALAR) != 0); }
	inline bool matchnulls() { return ((joinType & joblist::MATCHNULLS) != 0); }
	inline bool hasFEFilter() { return fe; }
	inline boost::shared_ptr<funcexp::FuncExpWrapper> getFcnExpFilter() { return fe; }
	void setFcnExpFilter(boost::shared_ptr<funcexp::FuncExpWrapper> fe);
	inline bool evaluateFilter(rowgroup::Row &r, uint index) { return fes[index].evaluate(&r); }
	inline uint64_t getJoinNullValue() { return joblist::BIGINTNULL; }   // a normalized NULL value
	inline uint64_t smallNullValue() { return nullValueForJoinColumn; }

private:
	typedef std::tr1::unordered_multimap<int64_t, uint8_t *, hasher, std::equal_to<int64_t>,
	  utils::STLPoolAllocator<std::pair<const int64_t, uint8_t *> > > hash_t;
	typedef std::tr1::unordered_multimap<TypelessData, uint8_t *, hasher, std::equal_to<TypelessData>,
	  utils::STLPoolAllocator<std::pair<const TypelessData, uint8_t *> > > typelesshash_t;

	typedef hash_t::iterator iterator;
	typedef typelesshash_t::iterator thIterator;

	TupleJoiner();
	TupleJoiner(const TupleJoiner &);
	TupleJoiner & operator=(const TupleJoiner &);

	iterator begin() { return h->begin(); }
	iterator end() { return h->end(); }

	boost::scoped_ptr<hash_t> h;  // used for UM join on ints
	std::vector<uint8_t *> rows;   // used for PM join

	/* This struct is rough.  The BPP-JL stores the parsed results for
	the logical block being processed.  There are X threads at once, so
	up to X logical blocks being processed.  For each of those there's a vector
	of matches.  Each match is an index into 'rows'. */
	boost::shared_array<boost::shared_array<std::vector<uint32_t> > > pmJoinResults;
	rowgroup::RowGroup smallRG, largeRG;
	boost::scoped_array<rowgroup::Row> smallRow;
	boost::shared_array<uint8_t> smallNullMemory;

	enum JoinAlg {
		INSERTING,
		PM,
		UM,
		LARGE
	};
	JoinAlg joinAlg;
	joblist::JoinType joinType;
	boost::shared_ptr<utils::PoolAllocator> _pool;	// pool for the table and nodes
	uint threadCount;
	std::string tableName;

	/* vars, & fcns for typeless join */
	bool typelessJoin;
	std::vector<uint> smallKeyColumns, largeKeyColumns;
	boost::scoped_ptr<typelesshash_t> ht;  // used for UM join on strings
	uint keyLength;
	utils::FixedAllocator storedKeyAlloc;
	boost::scoped_array<utils::FixedAllocator> tmpKeyAlloc;
	
	/* semi-join vars & fcns */
	boost::shared_ptr<funcexp::FuncExpWrapper> fe;
	boost::scoped_array<funcexp::FuncExpWrapper> fes;  // holds X copies of fe, one per thread
	// this var is only used to normalize the NULL values for single-column joins,
	// will have to change when/if we need to support that for compound or string joins
	int64_t nullValueForJoinColumn;
	
	/* Runtime casual partitioning support */
	void updateCPData(const rowgroup::Row &r);
	boost::scoped_array<bool> discreteValues;
	boost::scoped_array<std::vector<int64_t> > cpValues;    // if !discreteValues, [0] has min, [1] has max
	uint uniqueLimit;
};

}

#endif

