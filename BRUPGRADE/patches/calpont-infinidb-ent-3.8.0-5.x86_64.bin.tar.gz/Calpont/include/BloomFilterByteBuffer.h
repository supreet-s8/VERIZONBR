#ifndef BLOOMFILTER_BYTEBUFFER_H_
#define BLOOMFILTER_BYTEBUFFER_H_

#include <string>

#include <stdlib.h>

#include <arpa/inet.h>

#include "BloomFilterByteBufferException.h"

#ifdef TESTING_WITH_GTEST

#include "gtest/gtest.h"

#endif //TESTING_WITH_GTEST

namespace BloomFilter
{
  class ByteBuffer
  {
  public:

    // Interprets the 4 bytes starting from position as an int and returns the value
    // Assume Big Endian
    static int32_t getInt(const std::string& buffer, const unsigned int position)
      throw (ByteBufferException)
    {
      if(buffer.size() < (position + sizeof(uint32_t))) throw  ByteBufferException();

      uint32_t const * address = reinterpret_cast<const uint32_t*>(&buffer[position]);
      return static_cast<int32_t>(ntohl(*address));
    }

    // Writes the int (4 byte) at the given location, after converting to Big Endian
    static void putInt(std::string& buffer, const unsigned int position, const int32_t value)
      throw (ByteBufferException)
    {
      if(buffer.size() < (position + sizeof(uint32_t))) throw  ByteBufferException();

      uint32_t* address = reinterpret_cast<uint32_t*>(&buffer[position]);
      *address = htonl(static_cast<uint32_t>(value));
    }

    // Interprets the 2 bytes starting from position as an int and returns the value
    // Assume Big Endian
    static int16_t getShort(const std::string& buffer, const unsigned int position) throw (ByteBufferException)
    {
      if(buffer.size() < (position + sizeof(uint16_t))) throw  ByteBufferException();

      uint16_t const * address = reinterpret_cast<const uint16_t*>(&buffer[position]);
      return static_cast<int16_t>(ntohs(*address));
    }

    // Writes the int (2 byte) at the given location, after converting to Big Endian
    static void putShort(std::string& buffer, const unsigned int position, const int16_t value)
      throw (ByteBufferException)
    {
      if(buffer.size() < (position + sizeof(uint16_t))) throw  ByteBufferException();

      uint16_t* address = reinterpret_cast<uint16_t*>(&buffer[position]);
      *address = htons(static_cast<uint16_t>(value));
    }

    // Gets byte from given position
    static unsigned char getByte(const std::string& buffer, const unsigned int position)
      throw (ByteBufferException)
    {
      if(buffer.size() < (position + sizeof(unsigned char))) throw  ByteBufferException();

      unsigned char const * address = reinterpret_cast<unsigned char const *>(&buffer[position]);
      return *address;
    }

    // Puts byte at given position
    static void putByte(std::string& buffer, const unsigned int position, const unsigned char value)
      throw (ByteBufferException)
    {
      if(buffer.size() < (position + sizeof(unsigned char))) throw  ByteBufferException();

      unsigned char * address = reinterpret_cast<unsigned char *>(&buffer[position]);
      *address = value;
    }

    // Gets bit at given position
    static bool getBit(const std::string& buffer, const unsigned int offset, const unsigned int position)
      throw (ByteBufferException)
    {
      unsigned int byteToAccess = position / 8;
      unsigned char byte = getByte(buffer, offset + byteToAccess);
      unsigned int bitToAccess = 7 - (position % 8);
      return (byte & (1 << bitToAccess)) ? 1 : 0;
    }

    // Gets bit at given position
    static void putBit(std::string& buffer, const unsigned int offset, const unsigned int position, const bool value)
      throw (ByteBufferException)
    {
      unsigned int byteToAccess = position / 8;
      unsigned char byte = getByte(buffer, offset + byteToAccess);
      unsigned int bitToAccess = 7 - (position % 8);
      unsigned char result = 0;
      if(value)
	{
	  result = byte | (1 << bitToAccess);
	}
      else
	{
	  result = byte & ((1 << bitToAccess) ^ 255);
	}
      putByte(buffer, offset + byteToAccess, result);
    }

    // Or a section
    static void orSection(const std::string& buffer, const unsigned int offset,
			  const int unsigned upto, std::string& accumulator) throw (ByteBufferException)
    {
      for(unsigned int i = 0; i < upto; ++i)
	{
	  unsigned char accumulatorByte = getByte(accumulator, offset + i);
	  unsigned char byteToOr = getByte(buffer, offset + i);
	  unsigned char result = accumulatorByte | byteToOr;
	  putByte(accumulator,offset + i, result);
	}
    }

    static void toHex(const std::string& given, std::string& result)
    {
      char characters[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
      result.resize(given.size() * 2);
      unsigned int counter = 0;
      for(unsigned int i = 0; i < given.size(); ++i)
	{
	  unsigned char currByte = ByteBuffer::getByte(given, i);
	  unsigned char temp = currByte & 0xF0;
	  temp = temp >> 4;
	  temp = temp & 0x0F;
	  result[counter++] = characters[temp];
	  temp = currByte & 0x0F;
	  result[counter++] = characters[temp];
	}
    }

    static void fromHex(const std::string& given, std::string& result)
    {
      std::string sub;
      result.resize(given.size() / 2);
      for(int i=0; i<given.size() / 2; i++) {
	sub = given.substr(i*2, 2);
	long int c = strtol(sub.c_str(), NULL, 16) & 0xff;
	char* a = (char*) &c;
	result[i] = *a;
      }
    }
  };
}

#ifdef TESTING_WITH_GTEST
TEST(ByteBuffer, IntegerReadWriteTest)
{
  std::string input("0000");
  int32_t result = 0;

  BloomFilter::ByteBuffer::putInt(input,0,42);
  result = BloomFilter::ByteBuffer::getInt
    (input, 0);
  ASSERT_TRUE(result == 42);

  BloomFilter::ByteBuffer::putInt(input,0,-42);
  result = BloomFilter::ByteBuffer::getInt(input, 0);
  ASSERT_TRUE(result == -42);
}

TEST(ByteBuffer, ShortReadWriteTest)
{
  std::string input("00");
  int16_t result = 0;

  BloomFilter::ByteBuffer::putShort(input,0,42);
  result = BloomFilter::ByteBuffer::getShort(input, 0);
  ASSERT_TRUE(result == 42);

  BloomFilter::ByteBuffer::putShort(input,0,-42);
  result = BloomFilter::ByteBuffer::getShort(input, 0);
  ASSERT_TRUE(result == -42);
}

TEST(ByteBuffer, ByteReadWriteTest)
{
  std::string input("-0");
  unsigned char result = 0;

  BloomFilter::ByteBuffer::putByte(input,1,42);
  result = BloomFilter::ByteBuffer::getByte(input, 1);
  ASSERT_TRUE(result == 42);
}
TEST(ByteBuffer, BitReadWriteTest)
{
  std::string input("-000");

  for(unsigned int i = 0; i < 24; ++i)
    if(i % 2 == 0)
      BloomFilter::ByteBuffer::putBit(input,1,i,true);
    else
      BloomFilter::ByteBuffer::putBit(input,1,i,false);

  for(unsigned int i = 0; i < 24; ++i)
    if(i % 2 == 0)
      ASSERT_TRUE(BloomFilter::ByteBuffer::getBit(input,1, i));
    else
      ASSERT_FALSE(BloomFilter::ByteBuffer::getBit(input,1, i));
}

TEST(ByteBuffer, BitRepresentationTest)
{
  std::string input("000");

  for(unsigned int i = 0; i < 24; ++i)
    BloomFilter::ByteBuffer::putBit(input,0,i,false);

  for(unsigned int i = 0; i < 24; ++i)
    {
      BloomFilter::ByteBuffer::putBit(input,0,i,true);
      std::string resultAsHex;
      BloomFilter::ByteBuffer::toHex(input, resultAsHex);
      if(i == 0) ASSERT_TRUE(resultAsHex == "800000"); continue;
      if(i == 1) ASSERT_TRUE(resultAsHex == "c00000"); continue;
      if(i == 2) ASSERT_TRUE(resultAsHex == "e00000"); continue;
      if(i == 3) ASSERT_TRUE(resultAsHex == "f00000"); continue;
      if(i == 4) ASSERT_TRUE(resultAsHex == "f80000"); continue;
      if(i == 5) ASSERT_TRUE(resultAsHex == "fc0000"); continue;
      if(i == 6) ASSERT_TRUE(resultAsHex == "fe0000"); continue;
      if(i == 7) ASSERT_TRUE(resultAsHex == "ff0000"); continue;
      if(i == 8) ASSERT_TRUE(resultAsHex == "ff8000"); continue;
      if(i == 9) ASSERT_TRUE(resultAsHex == "ffc000"); continue;
      if(i == 10) ASSERT_TRUE(resultAsHex == "ffe000"); continue;
      if(i == 11) ASSERT_TRUE(resultAsHex == "fff000"); continue;
      if(i == 12) ASSERT_TRUE(resultAsHex == "fff800"); continue;
      if(i == 13) ASSERT_TRUE(resultAsHex == "fffc00"); continue;
      if(i == 14) ASSERT_TRUE(resultAsHex == "fffe00"); continue;
      if(i == 15) ASSERT_TRUE(resultAsHex == "ffff00"); continue;
      if(i == 16) ASSERT_TRUE(resultAsHex == "ffff80"); continue;
      if(i == 17) ASSERT_TRUE(resultAsHex == "ffffc0"); continue;
      if(i == 18) ASSERT_TRUE(resultAsHex == "ffffe0"); continue;
      if(i == 29) ASSERT_TRUE(resultAsHex == "fffff0"); continue;
      if(i == 20) ASSERT_TRUE(resultAsHex == "fffff8"); continue;
      if(i == 21) ASSERT_TRUE(resultAsHex == "fffffc"); continue;
      if(i == 22) ASSERT_TRUE(resultAsHex == "fffffe"); continue;
      if(i == 23) ASSERT_TRUE(resultAsHex == "ffffff"); continue;
    }

}

TEST(ByteBuffer, ORTest)
{
  std::string input1("-000");
  for(unsigned int i = 0; i < 24; ++i)
    if(i % 2 == 0)
      BloomFilter::ByteBuffer::putBit(input1,1,i,true);
    else
      BloomFilter::ByteBuffer::putBit(input1,1,i,false);

  std::string input2("-000");
  for(unsigned int i = 0; i < 24; ++i)
    if(i % 2 == 0)
      BloomFilter::ByteBuffer::putBit(input2,1,i,false);
    else
      BloomFilter::ByteBuffer::putBit(input2,1,i,true);

  BloomFilter::ByteBuffer::orSection(input1,1,3,input2);

  for(unsigned int i = 0; i < 24; ++i)
    ASSERT_TRUE(BloomFilter::ByteBuffer::getBit(input2, 1, i));
}

TEST(ByteBuffer, HexTest)
{
  std::string input("abcefgh");
  std::string expectedResult("61626365666768");
  std::string actualResult;
  BloomFilter::ByteBuffer::toHex(input, actualResult);
  ASSERT_TRUE(expectedResult == actualResult);
}


#endif //TESTING_WITH_GTEST

#endif // BYTEBUFFER_H_
