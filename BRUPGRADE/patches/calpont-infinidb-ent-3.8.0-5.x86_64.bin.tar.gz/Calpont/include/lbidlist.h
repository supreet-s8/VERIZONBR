/*

Copyright (C) 2009-2011 Calpont Corporation.

Use of and access to the Calpont InfiniDB Community software is subject to the
terms and conditions of the Calpont Open Source License Agreement. Use of and
access to the Calpont InfiniDB Enterprise software is subject to the terms and
conditions of the Calpont End User License Agreement.

This program is distributed in the hope that it will be useful, and unless
otherwise noted on your license agreement, WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Please refer to the Calpont Open Source License Agreement and the Calpont End
User License Agreement for more details.

You should have received a copy of either the Calpont Open Source License
Agreement or the Calpont End User License Agreement along with this program; if
not, it is your responsibility to review the terms and conditions of the proper
Calpont license agreement by visiting http://www.calpont.com for the Calpont
InfiniDB Enterprise End User License Agreement or http://www.infinidb.org for
the Calpont InfiniDB Community Calpont Open Source License Agreement.

Calpont may make changes to these license agreements from time to time. When
these changes are made, Calpont will make a new copy of the Calpont End User
License Agreement available at http://www.calpont.com and a new copy of the
Calpont Open Source License Agreement available at http:///www.infinidb.org.
You understand and agree that if you use the Program after the date on which
the license agreement authorizing your use has changed, Calpont will treat your
use as acceptance of the updated License.

*/

/***********************************************************************
*   $Id: lbidlist.h 8240 2012-01-10 00:10:15Z pleblanc $
*
*
***********************************************************************/
/** @file */

#ifndef JOBLIST_LBIDLIST_H
#define JOBLIST_LBIDLIST_H

#include <boost/shared_ptr.hpp>
#include "joblisttypes.h"
#include "calpontsystemcatalog.h"
#include "brmtypes.h"
#include "bytestream.h"
#include <iostream>
#include "brm.h"
#ifdef _MSC_VER
#include <unordered_map>
#else
#include <tr1/unordered_map>
#endif

namespace joblist 
{ 

typedef BRM::LBIDRange_v LBIDRangeVector;

/** @brief struct MinMaxPartition
 *
 */
struct MinMaxPartition
{
	int64_t lbid;
	int64_t lbidmax;
	int64_t min;
	int64_t max;
	int64_t seq;
	int     isValid;
};

/** @brief class LBIDList
 *
 */
class LBIDList
{
public:

	explicit LBIDList(const execplan::CalpontSystemCatalog::OID oid,
					const int debug);

	explicit LBIDList(const int debug);

	void init(const execplan::CalpontSystemCatalog::OID oid,
			const int debug);

	virtual ~LBIDList();

	void Dump(long Index, int Count) const;
	u_int32_t GetRangeSize() const { return LBIDRanges.size() ? LBIDRanges.at(0).size : 0; }

	// New functions to handle min/max values per lbid for casual partitioning;
	// If pEMEntries is provided, then min/max will be extracted from that
	// vector, else extents in BRM will be searched.
	bool GetMinMax(int64_t& min, int64_t& max, int64_t& seq, int64_t lbid,
			const std::vector<struct BRM::EMEntry>* pEMEntries);

	bool GetMinMax(int64_t *min, int64_t *max, int64_t *seq, int64_t lbid,
			const std::tr1::unordered_map<int64_t, BRM::EMEntry> &entries);

	void UpdateMinMax(int64_t min, int64_t max, int64_t lbid,
	  execplan::CalpontSystemCatalog::ColDataType type, bool validData = true);

	void UpdateAllPartitionInfo();

	bool IsRangeBoundary(uint64_t lbid);

	bool CasualPartitionPredicate(const int64_t Min, 
				const int64_t Max, 
				const messageqcpp::ByteStream* MsgDataPtr,
				const uint16_t NOPS, 
				const execplan::CalpontSystemCatalog::ColType& ct, 
				const uint8_t BOP);

	bool checkSingleValue(int64_t min, int64_t max, int64_t value, bool isCharColumn);
	
	bool checkRangeOverlap(int64_t min, int64_t max, int64_t tmin, int64_t tmax, bool isCharColumn);

	// check the column data type and the column size to determine if it
	// is a data type  to apply casual paritioning.
	bool CasualPartitionDataType(const uint8_t type, const uint8_t size) const;

	LBIDList(const LBIDList& rhs) { copyLbidList(rhs); }

	LBIDList& operator=(const LBIDList& rhs) { copyLbidList(rhs); return *this;}

private:
	LBIDList();

	void copyLbidList(const LBIDList& rhs);

	template<class T>
	inline bool compareVal(const T& Min, const T& Max, const T& value, char op, uint8_t lcf);

	inline bool isChar(execplan::CalpontSystemCatalog::ColDataType type)
	{
		return (execplan::CalpontSystemCatalog::VARCHAR == type || execplan::CalpontSystemCatalog::CHAR == type);
	}

	template <class T>
	inline bool checkNull(execplan::CalpontSystemCatalog::ColDataType type, T val, T nullVal, T nullCharVal);

	inline bool checkNull32(execplan::CalpontSystemCatalog::ColDataType type, int32_t val);
	inline bool checkNull64(execplan::CalpontSystemCatalog::ColDataType type, int64_t val);

	int  getMinMaxFromEntries(int64_t& min, int64_t& max, int32_t& seq,
			int64_t lbid, const std::vector<struct BRM::EMEntry>& EMEntries);

	boost::shared_ptr<BRM::DBRM> em;
	std::vector<MinMaxPartition*> lbidPartitionVector;
	LBIDRangeVector LBIDRanges;
	int fDebug;

}; // LBIDList


} // joblist
#endif
