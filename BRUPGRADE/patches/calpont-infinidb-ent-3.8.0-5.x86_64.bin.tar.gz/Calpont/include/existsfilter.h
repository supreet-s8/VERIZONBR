/*

Copyright (C) 2009-2011 Calpont Corporation.

Use of and access to the Calpont InfiniDB Community software is subject to the
terms and conditions of the Calpont Open Source License Agreement. Use of and
access to the Calpont InfiniDB Enterprise software is subject to the terms and
conditions of the Calpont End User License Agreement.

This program is distributed in the hope that it will be useful, and unless
otherwise noted on your license agreement, WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Please refer to the Calpont Open Source License Agreement and the Calpont End
User License Agreement for more details.

You should have received a copy of either the Calpont Open Source License
Agreement or the Calpont End User License Agreement along with this program; if
not, it is your responsibility to review the terms and conditions of the proper
Calpont license agreement by visiting http://www.calpont.com for the Calpont
InfiniDB Enterprise End User License Agreement or http://www.infinidb.org for
the Calpont InfiniDB Community Calpont Open Source License Agreement.

Calpont may make changes to these license agreements from time to time. When
these changes are made, Calpont will make a new copy of the Calpont End User
License Agreement available at http://www.calpont.com and a new copy of the
Calpont Open Source License Agreement available at http:///www.infinidb.org.
You understand and agree that if you use the Program after the date on which
the license agreement authorizing your use has changed, Calpont will treat your
use as acceptance of the updated License.

*/

/***********************************************************************
*   $Id: existsfilter.h 7409 2011-02-08 14:38:50Z rdempsey $
*
*
***********************************************************************/
/** @file */

#ifndef EXISTSFILTER_H
#define EXISTSFILTER_H
#include <string>

#include "filter.h"
#include "calpontselectexecutionplan.h"

/**
 * Namespace
 */
namespace execplan { 
/**
 * @brief A class to represent a exists predicate
 *
 * This class is a specialization of class Filter that handles a
 * exists predicate like "exists (select col2 from table2)"
 */
class ExistsFilter : public Filter {
/**
 * Public stuff
 */
public:
	/**
	 * Constructors
	 */
	ExistsFilter();
	ExistsFilter( const SCSEP& sub, const bool existsFlag = false, const bool correlated = false);
	ExistsFilter(const ExistsFilter& rhs);
	virtual ~ExistsFilter();
	
	/**
	 * Accessor Methods
	 */
	const SCSEP& sub() const { return fSub; }	
	void sub (SCSEP& sub) { fSub = sub; }
	
	const bool notExists() const { return fNotExists; }
	void notExists (const bool notExists) { fNotExists = notExists; }		
	
	const bool correlated() const { return fCorrelated; }
	void correlated(const bool correlated) { fCorrelated = correlated; }
	   
	/**
	 * Overloaded stream operator
	 */
	//virtual std::ostream& operator<< (std::ostream& output);
	virtual const std::string toString() const;
	
	/**
	 * The serialization interface
	 */
	virtual void serialize(messageqcpp::ByteStream&) const;
	virtual void unserialize(messageqcpp::ByteStream&);
	
	/** return a copy of this pointer
	 *
	 * deep copy of this pointer and return the copy
	 */	
	inline virtual ExistsFilter* clone() const
	{
	    return new ExistsFilter (*this);
	}	
	
	/** @brief Do a deep, strict (as opposed to semantic) equivalence test
	 *
	 * Do a deep, strict (as opposed to semantic) equivalence test.
	 * @return true iff every member of t is a duplicate copy of every member of this; false otherwise
	 */
	virtual bool operator==(const TreeNode* t) const;
	
	/** @brief Do a deep, strict (as opposed to semantic) equivalence test
	 *
	 * Do a deep, strict (as opposed to semantic) equivalence test.
	 * @return true iff every member of t is a duplicate copy of every member of this; false otherwise
	 */
	bool operator==(const ExistsFilter& t) const;
	
	/** @brief Do a deep, strict (as opposed to semantic) equivalence test
	 *
	 * Do a deep, strict (as opposed to semantic) equivalence test.
	 * @return false iff every member of t is a duplicate copy of every member of this; true otherwise
	 */
	virtual bool operator!=(const TreeNode* t) const;
	 
	/** @brief Do a deep, strict (as opposed to semantic) equivalence test
	 *
	 * Do a deep, strict (as opposed to semantic) equivalence test.
	 * @return false iff every member of t is a duplicate copy of every member of this; true otherwise
	 */
	bool operator!=(const ExistsFilter& t) const;

private:
	//default okay?
	//ExistsFilter& operator=(const ExistsFilter& rhs);
        
	 SCSEP fSub;
	 bool fNotExists;     /// if this is not exist?
	 bool fCorrelated;
	 std::string fData;
};

std::ostream& operator<<(std::ostream& output, const ExistsFilter& rhs);

} 
#endif //EXISTSFILTER_H

