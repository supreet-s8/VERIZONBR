#! /bin/sh
#
#/***************************************************************************
#*  Script Name:    getmodules.sh
#*  Date Created:   2009.03.09
#*  Author:         Calpont Corp.
#*  Purpose:        Retrieve the host names of the servers in this stack
#*
#*  Parameters:     None
#*
#***************************************************************************/

controllertype=`ps -ef | grep -c "controllernode"`
hostdir=`date +%Y%m%d%H%M%S`

# Module check
if [ $controllertype = "1" ]; then
   echo -e "\n\nThe PRAT utility can only be run from the Parent module" 1>&2
   exit 1
fi

# clean up previous data files if necessary
if  [ -f /dev/shm/hostlist.txt ]; then
    rm -rf /dev/shm/hostlist.txt
fi

if  [ -f /dev/shm/serverlist.txt ]; then
    rm -rf /dev/shm/serverlist.txt
fi

# issue Calpont console command and send the output to a file
/usr/local/Calpont/bin/calpontConsole getsystemnetworkconfig ACK_YES |
egrep -w 'Director|User|Performance' | 
awk -F" " '{print $1"\t" $2"\t" $3"\t" $4"\t" $6}' > /dev/shm/modulelist.txt

# Add the timestamped directory name to each line
cat /dev/shm/modulelist.txt |
while read modulename moduletype module modulenumber host  ; do
    echo $modulename $host "$host"_prat_"$hostdir" >> /dev/shm/hostlist.txt
    echo $host >> /dev/shm/serverlist.txt
done

rm -rf /dev/shm/modulelist.txt

# End of Script
