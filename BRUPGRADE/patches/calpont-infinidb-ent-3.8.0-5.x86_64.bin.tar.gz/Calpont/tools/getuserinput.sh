#!/bin/sh
#
#/*******************************************************************************
#*  Script Name:    getuserinput.sh
#*  Date Created:   2009.05.20
#*  Author:         Calpont Corp.
#*  Purpose:        Collect data on all hosts in a stack
#*  Parameter:      None
#******************************************************************************/

CTOOLS=/usr/local/Calpont/tools

getuserinput ()
{
  echo -n "Enter the two digit day of the month for the desired timeframe  > "
  read date
  echo -n "Enter the starting hour and minute (hh:mm) for the desired timeframe  > "
  read starttime
  echo -n "Enter the ending hour and minute (hh:mm) for the desired timeframe  > "
  read endtime
  echo $date $starttime $endtime > /dev/shm/pratinput.txt
}

getpwds ()
{
  # Get the password for the Calpont stack
  echo -n -e "\nEnter the password for the Calpont stack > "
  read -s password
  for hostname in `cat /dev/shm/serverlist.txt`; do
    hostdir=`grep "$hostname" /dev/shm/hostlist.txt | awk -F" " '{print $3}'`
    echo $hostname $password $hostdir >> /dev/shm/.prat/.hostlist2.txt
  done
}

# clean up previous data files if necessary
if  [ ! -d /dev/shm/.prat ]; then
    cd /dev/shm
    mkdir -p /dev/shm/.prat
elif [ -f /dev/shm/.prat/.hostlist2.txt ]; then
    rm -rf /dev/shm/.prat/.hostlist2.txt
    touch /dev/shm/.prat/.hostlist2.txt
fi

if  [ -f /dev/shm/pratinput.txt ]; then
    rm -rf /dev/shm/pratinput.txt
fi

getuserinput
getpwds

# End of script
